"""E10: preprocessing control for the 1/f-noise and nonstationarity axes.

Refits all four methods on high-pass-filtered observations of the saved
held-out cells (results/shplrnn_axis_heldout/cells); architectures, epochs and
scoring are shplrnn_axis_heldout's.  Filter: zero-phase 4th-order Butterworth
high-pass at --mult x the segment rate (N_SEG / T cycles per sample, 0.01 for
the paper's 20 segments of 100 samples), applied to the train and test
trajectories separately; --mult 0 removes each segment's per-channel mean
instead (piecewise-constant detrend).  Primary score: against the unfiltered
sources.  Secondary: against the identically filtered sources.  The saved
cell's own score is the paired unfiltered baseline.

    python scripts/ar_highpass.py --mult 2 --axes 1f_snr ns m_vs_d --device cuda
"""
import os
import sys
import time
import argparse
import numpy as np
import torch
from scipy.signal import butter, sosfiltfilt

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.dirname(HERE))
import shplrnn_axis_heldout as hb


def preprocess(x, labels, mult):
    if mult == 0:
        out = x.astype(np.float32).copy()
        for s in np.unique(labels):
            out[labels == s] -= out[labels == s].mean(0)
        return out
    fc = mult * (int(labels.max()) + 1) / len(x)          # cycles per sample
    sos = butter(4, fc / 0.5, btype="highpass", output="sos")
    return sosfiltfilt(sos, x.astype(np.float64), axis=0).astype(np.float32)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cells", default="results/shplrnn_axis_heldout/cells")
    ap.add_argument("--out", default="results/ar_night/highpass")
    ap.add_argument("--mult", type=float, default=2.0)
    ap.add_argument("--axes", nargs="*", default=["1f_snr", "ns", "m_vs_d"])
    ap.add_argument("--seeds", type=int, nargs="*", default=hb.SEEDS)
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--limit", type=int, default=0, help="smoke: stop after this many cells")
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)
    tag = "segdemean" if args.mult == 0 else f"hp{args.mult:g}x"
    path = f"{args.out}/{tag}.npy"
    res = np.load(path, allow_pickle=True).item() if os.path.exists(path) else {}
    t0, n = time.time(), 0
    for ax in args.axes:
        for cfg in hb.AXES[ax]:
            for seed in args.seeds:
                key = (ax, cfg, seed)
                if key in res or (args.limit and n >= args.limit):
                    continue
                c = dict(np.load(f"{args.cells}/{ax}_{cfg}_seed{seed}.npz"))
                z_tr, z_te, labels = c["z_tr"], c["z_te"], c["labels"]
                xf_tr, xf_te = preprocess(c["x_tr"], labels, args.mult), preprocess(c["x_te"], labels, args.mult)
                zf_tr, zf_te = preprocess(z_tr, labels, args.mult), preprocess(z_te, labels, args.mult)
                torch.manual_seed(seed)
                c2, _, _ = hb.run_methods(z_tr, z_te, xf_tr, xf_te, labels, args.device)
                ho, ins = hb.score_cell(c2)
                hof, _ = hb.score_cell(dict(c2, z_tr=zf_tr, z_te=zf_te))
                base, _ = hb.score_cell(c)
                res[key] = dict(base=base, filtered=ho, filtered_vs_filtered_z=hof, insample=ins,
                                tcl_acc_base=float(c["TCL_acc_te"]), tcl_acc=float(c2["TCL_acc_te"]),
                                z_power_kept=float(np.mean(zf_tr ** 2) / np.mean(z_tr ** 2)),
                                x_power_kept=float(np.mean(xf_tr ** 2) / np.mean(c["x_tr"] ** 2)))
                np.save(path, res)
                n += 1
            done = [res[(ax, cfg, s)] for s in args.seeds if (ax, cfg, s) in res]
            if done:
                line = " | ".join(f"{m} {np.nanmean([d['base'][m] for d in done]):.2f}->"
                                  f"{np.nanmean([d['filtered'][m] for d in done]):.2f}" for m in hb.METHODS)
                print(f"{tag} {ax:>7} {str(cfg):>18}: {line}  z-power kept "
                      f"{np.mean([d['z_power_kept'] for d in done]):.2f}  [{time.time() - t0:.0f}s]", flush=True)
    lines = [f"# {tag}: held-out scores, mean over seeds: unfiltered -> filtered (filtered vs filtered sources)",
             "| axis | cfg | " + " | ".join(hb.METHODS) + " | TCL seg. acc | z power kept | x power kept |",
             "|---|---|" + "---|" * (len(hb.METHODS) + 3)]
    for ax in args.axes:
        for cfg in hb.AXES[ax]:
            done = [res[(ax, cfg, s)] for s in args.seeds if (ax, cfg, s) in res]
            if not done:
                continue
            cells = [f"{np.nanmean([d['base'][m] for d in done]):.2f} -> {np.nanmean([d['filtered'][m] for d in done]):.2f}"
                     f" ({np.nanmean([d['filtered_vs_filtered_z'][m] for d in done]):.2f})" for m in hb.METHODS]
            lines.append(f"| {ax} | {cfg} | " + " | ".join(cells)
                         + f" | {np.mean([d['tcl_acc_base'] for d in done]):.2f} -> {np.mean([d['tcl_acc'] for d in done]):.2f}"
                         + f" | {np.mean([d['z_power_kept'] for d in done]):.2f} | {np.mean([d['x_power_kept'] for d in done]):.2f} |")
    with open(f"{args.out}/{tag}.md", "w") as f:
        f.write("\n".join(lines) + "\n")


if __name__ == "__main__":
    main()
