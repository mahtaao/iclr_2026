"""D1: observational diagnostics versus true recovery, on the saved held-out cells.

For every cell, next to the true held-out score, everything a practitioner could
compute WITHOUT the sources:
  TCL   : held-out segment accuracy (saved), train accuracy (reloaded classifier),
          run-to-run consistency (second fitting seed; CCA-MCC between the two
          feature sets on x_test), split-half consistency (fit on each half of
          x_train; CCA-MCC on x_test), agreement with FastICA (CCA on x_test)
  iVAE  : test nELBO (sigma = 1), mean posterior KL per latent, recon R^2,
          run-to-run (perm-MCC), split-half (perm-MCC), agreement with FastICA
  FastICA: mean |excess kurtosis| of test components, dependence of squares
          (mean |corr(h_i^2, h_j^2)|), run-to-run (random_state 0 vs 1),
          split-half, n_iter / convergence
  PCA   : explained-variance share of the M components, eigengap, split-half
Writes diagnostics.npy (per cell) and diagnostics.md (Spearman rho of each
diagnostic with the true score, pooled over cells and within each axis; and a
"practitioner's pick" table: per cell, the method ranked first by split-half
consistency vs the truly best method).
"""
import os, sys, time, argparse, warnings, numpy as np, torch
from scipy.stats import spearmanr, kurtosis
from sklearn.decomposition import PCA, FastICA
warnings.filterwarnings("ignore")
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE); sys.path.insert(0, os.path.dirname(HERE))
import shplrnn_axis_heldout as hb, failure_axis_sweep as fas
torch.set_num_threads(2)
CELLS = "results/shplrnn_axis_heldout/cells"; OUT = "results/autoresearch_oct7/diagnostics"; os.makedirs(OUT, exist_ok=True)
ap = argparse.ArgumentParser(); ap.add_argument("--device", default="cpu"); ap.add_argument("--seeds", type=int, nargs="*", default=hb.SEEDS)
args = ap.parse_args()
METHODS = hb.METHODS

def agree(m, a_te, b_te, a_tr=None, b_tr=None):
    """consistency score between two outputs: CCA for TCL (linear-invariant), perm-MCC otherwise; fit on train pair if given"""
    if a_tr is None: a_tr, b_tr = a_te, b_te
    return hb.weak_heldout(a_tr, b_tr, a_te, b_te) if m == "TCL" else hb.strong_heldout(a_tr, b_tr, a_te, b_te)

def ivae_eval(state, x_tr, x_te, labels, n, device):
    n_seg = int(labels.max()) + 1
    model = fas.iVAENet(x_tr.shape[1], n, n_seg, 64).to(device); model.load_state_dict(state); model.eval()
    u = torch.zeros(len(x_tr), n_seg); u[torch.arange(len(x_tr)), torch.tensor(labels)] = 1.0
    with torch.no_grad():
        X = torch.tensor(x_te); x_hat, z, z_mu, z_lv, p_mu, p_lv = model(X, u)
        kl = -0.5 * (1 + z_lv - p_lv - (z_mu - p_mu).pow(2) / p_lv.exp() - z_lv.exp() / p_lv.exp())
        se = (x_hat - X) ** 2
        nelbo = float((0.5 * se.sum(-1) + kl.sum(-1)).mean())
        r2 = float(1 - se.sum() / ((X - X.mean(0)) ** 2).sum())
        return nelbo, float(kl.mean()), r2

def tcl_train_acc(state, x_tr, labels, n, device):
    model = fas.TCLNet(x_tr.shape[1], 64, n, int(labels.max()) + 1).to(device); model.load_state_dict(state); model.eval()
    with torch.no_grad():
        return float((model(torch.tensor(x_tr))[0].argmax(1).numpy() == labels).mean())

path = f"{OUT}/diagnostics.npy"
res = np.load(path, allow_pickle=True).item() if os.path.exists(path) else {}
t0 = time.time()
for ax, cfgs in hb.AXES.items():
    for cfg in cfgs:
        for seed in args.seeds:
            key = (ax, cfg, seed)
            if key in res: continue
            c = dict(np.load(f"{CELLS}/{ax}_{cfg}_seed{seed}.npz"))
            st = torch.load(f"{CELLS}/{ax}_{cfg}_seed{seed}.pt")
            z_tr, z_te, x_tr, x_te, lab = c["z_tr"], c["z_te"], c["x_tr"], c["x_te"], c["labels"]; n = z_tr.shape[1]
            truth, _ = hb.score_cell(c)
            d = {m: {"truth": truth[m]} for m in METHODS}
            # split halves: two disjoint random 50% subsamples of the training points (every segment present in both),
            # so each half-model is evaluated on the full test trajectory
            prm = np.random.default_rng(seed + 3000).permutation(len(x_tr)); h = len(x_tr) // 2
            halves = [np.sort(prm[:h]), np.sort(prm[h:])]
            n_seg = int(lab.max()) + 1
            u_te = torch.zeros(len(x_te), n_seg); u_te[torch.arange(len(x_te)), torch.tensor(lab)] = 1.0
            def tcl_half(idx):
                torch.manual_seed(seed + 2000); model, _, _, _ = hb.fit_tcl(x_tr[idx], x_tr[idx], lab[idx], n, args.device)
                with torch.no_grad(): return model(torch.tensor(x_te))[1].numpy()
            def ivae_half(idx):
                torch.manual_seed(seed + 2000); model, _, _ = hb.fit_ivae(x_tr[idx], x_tr[idx], lab[idx], n, args.device)
                with torch.no_grad(): return model(torch.tensor(x_te), u_te)[2].numpy()
            # --- TCL
            d["TCL"]["seg_acc_test"] = float(c["TCL_acc_te"]); d["TCL"]["seg_acc_train"] = tcl_train_acc(st["tcl"], x_tr, lab, n, args.device)
            torch.manual_seed(seed + 1000); _, h2_tr, h2_te, _ = hb.fit_tcl(x_tr, x_te, lab, n, args.device)
            d["TCL"]["run2run"] = agree("TCL", c["TCL_te"], h2_te, c["TCL_tr"], h2_tr)
            hh = [tcl_half(s_) for s_ in halves]
            d["TCL"]["splithalf"] = agree("TCL", hh[0], hh[1])
            d["TCL"]["agree_fastica"] = hb.weak_heldout(c["FastICA_tr"], c["TCL_tr"], c["FastICA_te"], c["TCL_te"])
            # --- iVAE
            d["iVAE"]["nelbo_test"], d["iVAE"]["kl_per_dim"], d["iVAE"]["recon_r2"] = ivae_eval(st["ivae"], x_tr, x_te, lab, n, args.device)
            torch.manual_seed(seed + 1000); _, v2_tr, v2_te = hb.fit_ivae(x_tr, x_te, lab, n, args.device)
            d["iVAE"]["run2run"] = agree("iVAE", c["iVAE_te"], v2_te, c["iVAE_tr"], v2_tr)
            vv = [ivae_half(s_) for s_ in halves]
            d["iVAE"]["splithalf"] = agree("iVAE", vv[0], vv[1])
            d["iVAE"]["agree_fastica"] = hb.strong_heldout(c["FastICA_tr"], c["iVAE_tr"], c["FastICA_te"], c["iVAE_te"])
            # --- FastICA
            f_te = c["FastICA_te"]
            d["FastICA"]["abs_kurtosis"] = float(np.nanmean(np.abs(kurtosis(f_te, axis=0))))
            C2 = np.abs(np.corrcoef((f_te ** 2).T)); d["FastICA"]["sq_dependence"] = float((C2.sum() - n) / (n * n - n)) if n > 1 else 0.0
            try:
                ica1 = FastICA(n_components=n, max_iter=500, random_state=1).fit(x_tr)
                d["FastICA"]["run2run"] = agree("FastICA", f_te, ica1.transform(x_te), c["FastICA_tr"], ica1.transform(x_tr))
                d["FastICA"]["n_iter"] = int(ica1.n_iter_)
                ff = [FastICA(n_components=n, max_iter=500, random_state=0).fit(x_tr[s_]).transform(x_te) for s_ in halves]
                d["FastICA"]["splithalf"] = agree("FastICA", ff[0], ff[1])
            except Exception:
                d["FastICA"]["run2run"] = d["FastICA"]["splithalf"] = np.nan; d["FastICA"]["n_iter"] = -1
            d["FastICA"]["agree_pca"] = hb.strong_heldout(c["PCA_tr"], c["FastICA_tr"], c["PCA_te"], c["FastICA_te"])
            # --- PCA
            pca_full = PCA().fit(x_tr); ev = pca_full.explained_variance_
            d["PCA"]["explained_share"] = float(ev[:n].sum() / ev.sum()); d["PCA"]["eigengap"] = float(ev[n - 1] / ev[n]) if n < len(ev) else np.nan
            pp = [PCA(n_components=n).fit(x_tr[s_]).transform(x_te) for s_ in halves]
            d["PCA"]["splithalf"] = agree("PCA", pp[0], pp[1])
            d["PCA"]["agree_fastica"] = d["FastICA"]["agree_pca"]
            res[key] = d; np.save(path, res)
        g = lambda m, k: np.nanmean([res[(ax, cfg, s)][m].get(k, np.nan) for s in args.seeds])
        print(f"{ax:>8} {str(cfg):>18}: TCL truth {g('TCL','truth'):.2f} acc {g('TCL','seg_acc_test'):.2f} r2r {g('TCL','run2run'):.2f} sh {g('TCL','splithalf'):.2f} | "
              f"iVAE truth {g('iVAE','truth'):.2f} nelbo {g('iVAE','nelbo_test'):.1f} r2r {g('iVAE','run2run'):.2f} sh {g('iVAE','splithalf'):.2f} | "
              f"ICA truth {g('FastICA','truth'):.2f} kurt {g('FastICA','abs_kurtosis'):.2f} sh {g('FastICA','splithalf'):.2f} | PCA truth {g('PCA','truth'):.2f} sh {g('PCA','splithalf'):.2f}  [{time.time()-t0:.0f}s]", flush=True)

# ---- analysis
keys = sorted(res)
lines = ["# D1: Spearman rho between observational diagnostics and true held-out recovery (pooled over all cells; n = %d per method)" % len(keys), "",
         "| method | diagnostic | rho (pooled) | " + " | ".join(hb.AXES) + " |", "|---|---|---|" + "---|" * len(hb.AXES)]
for m in METHODS:
    diags = [k for k in res[keys[0]][m] if k != "truth"]
    for dg in diags:
        t = np.array([res[k][m]["truth"] for k in keys]); v = np.array([res[k][m].get(dg, np.nan) for k in keys], float)
        ok = np.isfinite(t) & np.isfinite(v)
        row = f"| {m} | {dg} | {spearmanr(t[ok], v[ok])[0]:+.2f} |"
        for ax in hb.AXES:
            idx = [i for i, k in enumerate(keys) if k[0] == ax]
            tt, vv_ = t[idx], v[idx]; o = np.isfinite(tt) & np.isfinite(vv_)
            row += f" {spearmanr(tt[o], vv_[o])[0]:+.2f} |" if o.sum() > 3 and np.std(vv_[o]) > 0 else " n/a |"
        lines.append(row)
# practitioner's pick: methods comparable on split-half (all four) -> pick best split-half, compare truth
pick_ok = 0; regret = []
for k in keys:
    sh = {m: res[k][m].get("splithalf", np.nan) for m in METHODS}; tr = {m: res[k][m]["truth"] for m in METHODS}
    pick = max(sh, key=lambda m: np.nan_to_num(sh[m], nan=-1)); best = max(tr, key=tr.get)
    pick_ok += pick == best; regret.append(tr[best] - tr[pick])
lines += ["", f"Practitioner's pick by split-half consistency: picks the truly best method in {pick_ok}/{len(keys)} cells; mean regret (true best - true picked) {np.mean(regret):.2f}, max {np.max(regret):.2f}.",
          "Note: TCL's truth is a CCA score vs |s| and the others' a permutation MCC vs s, so 'best' across methods is only indicative."]
open(f"{OUT}/diagnostics.md", "w").write("\n".join(lines) + "\n"); print("\n".join(lines))
