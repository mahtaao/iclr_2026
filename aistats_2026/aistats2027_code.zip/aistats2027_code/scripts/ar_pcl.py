"""D3: permutation-contrastive learning (PCL; Hyvarinen & Morioka, AISTATS 2017)
on every saved held-out cell.

PCL is the temporal-dependence counterpart of TCL: no segment labels; a feature
extractor h(x) is trained with a logistic discriminator to tell true consecutive
pairs (x_t, x_{t-1}) from permuted pairs (x_t, x_{t*}), t* random.  The
regression function must have the feature-wise form r = sum_i B_i(h_i(x_t),
h_i(x_{t-1})); the theorem (uniformly dependent, non-Gaussian-innovation
stationary sources) then identifies the sources up to permutation and
component-wise invertible transforms.  Here B_i is a per-component learned
function (2 -> 16 -> 1 MLP), which contains the paper's quadratic / absolute
forms.  Same encoder architecture, epochs, batch and optimiser as the TCL
baseline.  Scores on the test trajectory: permutation MCC vs signed s (matching
fit on train) and, since the indeterminacy is component-wise, Spearman-based
permutation MCC; also CCA-MCC vs s for a linear-invariant view, and vs |s| to
read it on TCL's scale.  Writes pcl.npy, pcl.md, and per-cell outputs.
"""
import os, sys, time, argparse, warnings, numpy as np, torch, torch.nn as nn
from scipy.stats import spearmanr
from scipy.optimize import linear_sum_assignment
warnings.filterwarnings("ignore")
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE); sys.path.insert(0, os.path.dirname(HERE))
import shplrnn_axis_heldout as hb, failure_axis_sweep as fas
torch.set_num_threads(2)
CELLS = "results/shplrnn_axis_heldout/cells"; OUT = "results/autoresearch_oct7/pcl"; os.makedirs(f"{OUT}/cells", exist_ok=True)

class PCLNet(nn.Module):
    def __init__(self, d, hidden, n):
        super().__init__()
        self.encoder = nn.Sequential(nn.Linear(d, hidden), nn.LeakyReLU(0.1), nn.Linear(hidden, hidden), nn.LeakyReLU(0.1), nn.Linear(hidden, n))
        self.B1 = nn.Parameter(torch.randn(n, 2, 16) * 0.3); self.b1 = nn.Parameter(torch.zeros(n, 16))
        self.B2 = nn.Parameter(torch.randn(n, 16) * 0.3); self.b2 = nn.Parameter(torch.zeros(n)); self.bias = nn.Parameter(torch.zeros(1))
    def feat(self, x): return self.encoder(x)
    def logit(self, h, hp):  # h, hp: (B, n); per-component B_i(h_i, hp_i), summed
        pair = torch.stack([h, hp], -1)                      # (B, n, 2)
        u = torch.tanh(torch.einsum("bni,nij->bnj", pair, self.B1) + self.b1)
        return (u * self.B2).sum(-1).add(self.b2).sum(-1) + self.bias

def fit_pcl(x_tr, x_te, n, device, epochs, lr=1e-3, hidden=64, batch=256):
    X = torch.tensor(x_tr); T = len(X)
    model = PCLNet(X.shape[1], hidden, n).to(device); opt = torch.optim.Adam(model.parameters(), lr=lr); lf = nn.BCEWithLogitsLoss()
    g = torch.Generator().manual_seed(0)
    for _ in range(epochs):
        perm = torch.randperm(T - 1, generator=g) + 1
        for i in range(0, T - 1, batch):
            t = perm[i:i + batch]; tstar = torch.randint(0, T, (len(t),), generator=g)
            h = model.feat(X[t]); hprev = model.feat(X[t - 1]); hstar = model.feat(X[tstar])
            logits = torch.cat([model.logit(h, hprev), model.logit(h, hstar)]); y = torch.cat([torch.ones(len(t)), torch.zeros(len(t))])
            loss = lf(logits, y); opt.zero_grad(); loss.backward(); opt.step()
    model.eval()
    with torch.no_grad():
        h_tr = model.feat(X).numpy(); Xte = torch.tensor(x_te); h_te = model.feat(Xte).numpy()
        t = torch.arange(1, len(Xte)); tstar = torch.randint(0, len(Xte), (len(t),), generator=g)
        acc = float(((model.logit(model.feat(Xte[t]), model.feat(Xte[t - 1])) > 0).float().mean() + (model.logit(model.feat(Xte[t]), model.feat(Xte[tstar])) <= 0).float().mean()) / 2)
    return h_tr, h_te, acc

def spearman_perm(z_tr, h_tr, z_te, h_te):
    M_ = z_tr.shape[1]; C = np.abs(spearmanr(z_tr, h_tr)[0][:M_, M_:]); r, c = linear_sum_assignment(-np.nan_to_num(C))
    Ct = np.abs(spearmanr(z_te, h_te)[0][:M_, M_:]); return float(np.nanmean(Ct[r, c]))


if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--device", default="cpu"); ap.add_argument("--seeds", type=int, nargs="*", default=hb.SEEDS)
    ap.add_argument("--epochs", type=int, default=200); args = ap.parse_args()
    path = f"{OUT}/pcl.npy"; res = np.load(path, allow_pickle=True).item() if os.path.exists(path) else {}
    t0 = time.time()
    for ax, cfgs in hb.AXES.items():
        for cfg in cfgs:
            for seed in args.seeds:
                key = (ax, cfg, seed)
                if key in res: continue
                c = dict(np.load(f"{CELLS}/{ax}_{cfg}_seed{seed}.npz")); z_tr, z_te = c["z_tr"], c["z_te"]; n = z_tr.shape[1]
                torch.manual_seed(seed); h_tr, h_te, acc = fit_pcl(c["x_tr"], c["x_te"], n, args.device, args.epochs)
                np.savez(f"{OUT}/cells/{ax}_{cfg}_seed{seed}.npz", PCL_tr=h_tr, PCL_te=h_te)
                res[key] = dict(perm_s=hb.strong_heldout(z_tr, h_tr, z_te, h_te), spearman_s=spearman_perm(z_tr, h_tr, z_te, h_te),
                                cca_s=hb.weak_heldout(z_tr, h_tr, z_te, h_te), cca_abs=hb.weak_heldout(np.abs(z_tr), h_tr, np.abs(z_te), h_te),
                                pair_acc=acc, TCL=hb.weak_heldout(np.abs(z_tr), c["TCL_tr"], np.abs(z_te), c["TCL_te"]),
                                FastICA=hb.strong_heldout(z_tr, c["FastICA_tr"], z_te, c["FastICA_te"]))
                np.save(path, res)
            g = lambda q: np.nanmean([res[(ax, cfg, s)][q] for s in args.seeds])
            print(f"{ax:>8} {str(cfg):>18}: PCL perm-s {g('perm_s'):.2f} spearman {g('spearman_s'):.2f} cca-s {g('cca_s'):.2f} cca-abs {g('cca_abs'):.2f} pair-acc {g('pair_acc'):.2f} | FastICA {g('FastICA'):.2f} TCL {g('TCL'):.2f}  [{time.time()-t0:.0f}s]", flush=True)
    lines = ["# D3: PCL on the held-out cells (mean over seeds)", "| axis | cfg | PCL perm-MCC vs s | PCL Spearman perm-MCC | PCL CCA vs s | PCL CCA vs abs s | pair acc (test) | FastICA perm-MCC | TCL CCA vs abs s |", "|---|---|---|---|---|---|---|---|---|"]
    for ax, cfgs in hb.AXES.items():
        for cfg in cfgs:
            g = lambda q: np.nanmean([res[(ax, cfg, s)][q] for s in args.seeds])
            lines.append(f"| {ax} | {cfg} | {g('perm_s'):.2f} | {g('spearman_s'):.2f} | {g('cca_s'):.2f} | {g('cca_abs'):.2f} | {g('pair_acc'):.2f} | {g('FastICA'):.2f} | {g('TCL'):.2f} |")
    open(f"{OUT}/pcl.md", "w").write("\n".join(lines) + "\n"); print("\n".join(lines))
