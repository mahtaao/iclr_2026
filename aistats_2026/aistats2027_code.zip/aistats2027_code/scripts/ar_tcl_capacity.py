"""E15: is TCL's failure in the stressed cells a capacity / training-length issue?

Refits TCL on saved held-out cells with hidden width in {64, 256} and epochs in
{200, 1000} (the sweep uses 64 / 200), same data, same held-out CCA-MCC vs |s|.
Cells: nonlin linear (clean control), m_vs_d 16 and 22, 1f_snr 5, ns
confounder_aligned (global scale) and stationary.

    python scripts/ar_tcl_capacity.py --device cuda
"""
import os
import sys
import time
import argparse
import numpy as np
import torch

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.dirname(HERE))
import shplrnn_axis_heldout as hb
import failure_axis_sweep as fas

CELLS = ["nonlin:linear", "m_vs_d:16", "m_vs_d:22", "1f_snr:5", "ns:confounder_aligned", "ns:stationary"]
CONFIGS = [(64, 200), (256, 200), (64, 1000), (256, 1000)]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cells", default="results/shplrnn_axis_heldout/cells")
    ap.add_argument("--out", default="results/ar_night/tcl_capacity")
    ap.add_argument("--seeds", type=int, nargs="*", default=hb.SEEDS)
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--limit", type=int, default=0)
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)
    path = f"{args.out}/scores.npy"
    res = np.load(path, allow_pickle=True).item() if os.path.exists(path) else {}
    t0, n = time.time(), 0
    for cell in CELLS:
        ax, cfg = cell.split(":")
        for hidden, epochs in CONFIGS:
            for seed in args.seeds:
                key = (cell, hidden, epochs, seed)
                if key in res or (args.limit and n >= args.limit):
                    continue
                c = dict(np.load(f"{args.cells}/{ax}_{cfg}_seed{seed}.npz"))
                z_tr, z_te, labels = c["z_tr"], c["z_te"], c["labels"]
                torch.manual_seed(seed)
                _, h_tr, h_te, acc = hb.fit_tcl(c["x_tr"], c["x_te"], labels, z_tr.shape[1], args.device,
                                                epochs=epochs, hidden=hidden)
                res[key] = dict(base=hb.weak_heldout(np.abs(z_tr), c["TCL_tr"], np.abs(z_te), c["TCL_te"]),
                                score=hb.weak_heldout(np.abs(z_tr), h_tr, np.abs(z_te), h_te),
                                insample=fas.weak_mcc(np.abs(z_tr), h_tr), tcl_acc=acc,
                                tcl_acc_base=float(c["TCL_acc_te"]))
                np.save(path, res)
                n += 1
            done = [res[(cell, hidden, epochs, s)] for s in args.seeds if (cell, hidden, epochs, s) in res]
            if done:
                print(f"{cell:>22} hidden={hidden:<4} epochs={epochs:<5}: base {np.nanmean([d['base'] for d in done]):.3f}"
                      f" -> {np.nanmean([d['score'] for d in done]):.3f} [in-sample {np.nanmean([d['insample'] for d in done]):.2f}]"
                      f"  acc {np.mean([d['tcl_acc'] for d in done]):.2f}  [{time.time() - t0:.0f}s]", flush=True)
    lines = ["# E15: TCL held-out CCA-MCC vs |s| by capacity / epochs (mean over seeds; in-sample in brackets; sweep setting = 64 / 200)",
             "| cell | sweep (64/200, saved) | " + " | ".join(f"{h}/{e}" for h, e in CONFIGS) + " |",
             "|---|---|" + "---|" * len(CONFIGS)]
    for cell in CELLS:
        row, base = [], np.nan
        for hidden, epochs in CONFIGS:
            done = [res[(cell, hidden, epochs, s)] for s in args.seeds if (cell, hidden, epochs, s) in res]
            if not done:
                row.append("")
                continue
            base = np.nanmean([d["base"] for d in done])
            row.append(f"{np.nanmean([d['score'] for d in done]):.2f} [{np.nanmean([d['insample'] for d in done]):.2f}]"
                       f" acc {np.mean([d['tcl_acc'] for d in done]):.2f}")
        lines.append(f"| {cell} | {base:.2f} | " + " | ".join(row) + " |")
    with open(f"{args.out}/tcl_capacity.md", "w") as f:
        f.write("\n".join(lines) + "\n")


if __name__ == "__main__":
    main()
