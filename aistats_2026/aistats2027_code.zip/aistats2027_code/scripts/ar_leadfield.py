"""E13: leadfield mixing under the held-out shPLRNN-source protocol (REVIEW_TODO 2.10).

For every cell of the five axes the learned observation matrix W (M x 22) is
replaced by a physics leadfield L: M current dipoles at random positions and
orientations in an MNE three-layer sphere model fitted to the 22 BCI IV-2a
electrodes (forward_model_generator.build_leadfield, no training), drawn with
the cell's seed and rescaled to the learned W's mean row norm so that the
observation scale matches the main sweep (the iVAE baseline is scale-sensitive,
results/autoresearch_oct6 E7/E8).  Sources, modulation gains, coupling matrix
and noise realisations are shared with a learned-W run made in the same job, so
the paired difference isolates the mixing geometry.  Methods, epochs and
held-out scoring are shplrnn_axis_heldout's; generators run on CPU.

    python scripts/ar_leadfield.py --seeds 0 --device cuda
"""
import os
import sys
import time
import argparse
import numpy as np
import torch

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.dirname(HERE))
import shplrnn_axis_heldout as hb
import forward_model_generator as fmg


class LeadfieldGenerators(hb.Generators):
    """hb.Generators whose W(M) returns the seed's leadfield when use_leadfield is set."""

    def __init__(self, device, out, seed):
        super().__init__(device, out)
        self.seed, self.use_leadfield, self.L = seed, False, {}

    def W(self, M):
        W = super().W(M)
        if not self.use_leadfield:
            return W
        if M not in self.L:
            L = fmg.build_leadfield(M, seed=self.seed)                 # (M, D), mean row norm 1
            self.L[M] = (L * np.linalg.norm(W, axis=1).mean()).astype(np.float32)
            np.save(f"{self.out}/leadfield_M{M}.npy", self.L[M])
        return self.L[M]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", type=int, nargs="*", default=hb.SEEDS)
    ap.add_argument("--axes", nargs="*", default=list(hb.AXES))
    ap.add_argument("--out", default="results/ar_night/leadfield")
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--limit", type=int, default=0)
    args = ap.parse_args()
    for seed in args.seeds:
        outdir = f"{args.out}/seed{seed}"
        os.makedirs(outdir, exist_ok=True)
        path = f"{outdir}/scores.npy"
        res = np.load(path, allow_pickle=True).item() if os.path.exists(path) else {}
        gens = LeadfieldGenerators("cpu", outdir, seed)
        n = 0
        for ax in args.axes:
            for cfg in hb.AXES[ax]:
                key = (ax, cfg, seed)
                if key in res or (args.limit and n >= args.limit):
                    continue
                t1 = time.time()
                M = cfg if ax == "m_vs_d" else 4
                r = {}
                for kind in ("learned", "leadfield"):
                    gens.use_leadfield = kind == "leadfield"
                    torch.manual_seed(seed)
                    z_tr, z_te, x_tr, x_te, labels = hb.make_data(ax, cfg, seed, gens)
                    c, _, _ = hb.run_methods(z_tr, z_te, x_tr, x_te, labels, args.device)
                    ho, ins = hb.score_cell(c)
                    r[kind] = dict(heldout=ho, insample=ins, tcl_acc=float(c["TCL_acc_te"]),
                                   x_std=float(x_tr.std()), cond=float(np.linalg.cond(gens.W(M))))
                res[key] = r
                np.save(path, res)
                n += 1
                print(f"seed={seed} {ax}={cfg}: " + "  ||  ".join(
                    f"{k} (cond {r[k]['cond']:.1f}, x std {r[k]['x_std']:.2f}): "
                    + " ".join(f"{m}={r[k]['heldout'][m]:.3f}" for m in hb.METHODS) for k in r)
                    + f"  [{time.time() - t1:.0f}s]", flush=True)


if __name__ == "__main__":
    main()
