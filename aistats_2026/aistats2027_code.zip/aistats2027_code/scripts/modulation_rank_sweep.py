"""Amount versus diversity of nonstationarity for TCL.

Holds the source count M, the mixing W (the trained M-source shPLRNN's learned
W), T, the number of segments, the noise (20 dB Gaussian) and the per-source
modulation law fixed, and varies only how many distinct segment-wise
modulation profiles the sources share, i.e. the rank (and, on a second axis,
the conditioning) of the natural-parameter modulation matrix L that TCL's
identifiability theorem (Hyvarinen & Morioka 2016, Theorem 1, assumption A3)
requires to have full column rank.

Design.  Every source is rescaled per segment by an Exp(1) variance, exactly
the paper's source-aligned law.  On the rank axis the M sources are split into
r groups and all sources of a group share one Exp(1) variance profile, so the
M columns of L take r distinct values: rank(L) = min(r, n_seg - 1).  r = M is
the paper's source-aligned schedule, r = 1 is its global-scale schedule with
the source-aligned gain law.  On the conditioning axis every source's
log-variance profile is (1 - a) g0 + a g_i, rescaled to the Exp(1) log-variance
spread, with g0 shared and g_i independent: a = 0 is rank one, a = 1 is the
source-aligned schedule, and 0 < a < 1 is full rank with one dominant shared
direction (cond(L) is measured and reported).  The paper's global-scale
schedule proper (one shared Exp(1) *amplitude*, variance Exp(1)^2) is kept as
a reference to separate the gain law from the rank.

Exact generator.  s_i(t) ~ N(0, sigma_i^2(tau(t))) independently over t: the
conditionally exponential family log p_tau(s_i) = lambda_i(tau) s_i^2 + const
with lambda_i(tau) = -1/(2 sigma_i^2(tau)) and sufficient statistic q(s) = s^2,
so the theorem applies verbatim and s^2 is the theorem-matched target.

Learned generator.  The standardised stochastic shPLRNN latents of
shplrnn_axis_sweep.Generators multiplied segment-wise by the same sigma_i(tau).
Scale modulation of a non-Gaussian, autocorrelated source is not an
exponential-family modulation, so no target is theorem-matched there; s^2, |s|
and s are all reported.

Scoring.  The last 20% of every segment is held out.  TCL (fas.TCLNet, default
architecture, 200 epochs) is trained on the rest; we report its held-out
segment accuracy and cross-entropy (chance: 1/n_seg and log n_seg), and the
recovery of its features on the held-out block by a CCA fitted on the training
block, against s^2, |s| and s.  FastICA (fit on the training block) is the
segment-free reference, scored by permutation MCC against s on the held-out
block.  Chance for each recovery score is the same procedure against a
circularly time-shifted target.

Usage:
    python scripts/modulation_rank_sweep.py --device cpu
    python scripts/modulation_rank_sweep.py --M 22 --n_seg 40 --ranks 1 22 --alphas \
        --out results/modulation_rank_M22_S40
"""
import os
import sys
import time
import argparse
import numpy as np
import torch
import torch.nn as nn
from sklearn.cross_decomposition import CCA
from sklearn.decomposition import FastICA

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
sys.path.insert(0, HERE)
import failure_axis_sweep as fas
from shplrnn_axis_sweep import Generators

T, D = fas.T, fas.D
ALPHAS = [0.0, 0.1, 0.2, 0.35, 0.5, 0.75, 1.0]
REFS = ["shared_exp_amp"]
GENS = ["exact", "shplrnn"]
SEEDS = list(range(10))
TEST_FRAC = 0.2
SNR_DB = 20
SCORES = ["acc_tr", "acc_te", "nll_te", "tcl_s2", "tcl_abs", "tcl_s",
          "null_s2", "null_abs", "null_s", "ica", "null_ica",
          "logvar_std", "frob", "rank_L", "cond_L"]


# ── design ───────────────────────────────────────────────────────────────────

def segments(n_seg):
    labels = fas.make_segment_labels(T, n_seg)
    test = np.zeros(T, bool)
    for seg in range(n_seg):
        idx = np.where(labels == seg)[0]
        test[idx[int(len(idx) * (1 - TEST_FRAC)):]] = True
    return labels, test


def sigma2_for(cond_key, n_seg, M, rng):
    """Per-segment variances (n_seg, M) for one condition."""
    kind, val = cond_key
    g = np.log(rng.exponential(1.0, (n_seg, M)))      # independent log-variance profiles
    g0 = np.log(rng.exponential(1.0, (n_seg, 1)))     # one shared profile
    if kind == "rank":
        groups = np.arange(M) % int(val)
        return np.exp(g[:, :int(val)][:, groups])
    if kind == "alpha":
        a = float(val)
        return np.exp(((1 - a) * g0 + a * g) / np.sqrt((1 - a) ** 2 + a ** 2))
    if val == "shared_exp_amp":
        return np.repeat(rng.exponential(1.0, (n_seg, 1)) ** 2, M, 1)
    raise ValueError(cond_key)


def strength(sigma2):
    """Realised modulation: mean over sources of the std over segments of
    log sigma^2; Frobenius norm, numerical rank and condition number of the
    theorem's matrix L = lambda(tau) - lambda(1)."""
    lam = -1.0 / (2.0 * sigma2)
    L = lam[1:] - lam[:1]
    sv = np.linalg.svd(L, compute_uv=False)
    rank = int((sv > sv[0] * 1e-8).sum())
    cond = float(sv[0] / sv[-1]) if rank == len(sv) else np.inf
    return dict(logvar_std=float(np.log(sigma2).std(0).mean()),
                frob=float(np.linalg.norm(L)), rank_L=rank, cond_L=cond)


# ── methods ──────────────────────────────────────────────────────────────────

def fit_tcl(x, labels, test, latent_dim, device, epochs=200, lr=1e-3, hidden=64):
    """fas.fit_tcl with a held-out block: returns features (T, latent_dim), the
    train and held-out segment accuracies and the held-out cross-entropy."""
    n_seg = int(labels.max()) + 1
    X = torch.tensor(x, dtype=torch.float32, device=device)
    Y = torch.tensor(labels, dtype=torch.long, device=device)
    tr = torch.tensor(np.where(~test)[0], device=device)
    te = torch.tensor(np.where(test)[0], device=device)
    model = fas.TCLNet(x.shape[1], hidden, latent_dim, n_seg).to(device)
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.CrossEntropyLoss()
    model.train()
    for _ in range(epochs):
        perm = tr[torch.randperm(len(tr), device=device)]
        for i in range(0, len(perm), 256):
            idx = perm[i:i + 256]
            logits, _ = model(X[idx])
            loss = loss_fn(logits, Y[idx])
            opt.zero_grad()
            loss.backward()
            opt.step()
    model.eval()
    with torch.no_grad():
        logits, h = model(X)
        nll_te = float(loss_fn(logits[te], Y[te]))
    pred = logits.argmax(1).cpu().numpy()
    return (h.cpu().numpy(), float((pred[~test] == labels[~test]).mean()),
            float((pred[test] == labels[test]).mean()), nll_te)


def cca_mcc(h, target, test):
    """Mean |canonical correlation| on the held-out block, CCA fitted on the
    training block (the paper's weak_mcc, out of sample)."""
    n = min(h.shape[1], target.shape[1])
    try:
        cca = CCA(n_components=n, max_iter=2000).fit(h[~test], target[~test])
        a, b = cca.transform(h[test], target[test])
        return float(np.nanmean([abs(np.corrcoef(a[:, i], b[:, i])[0, 1]) for i in range(n)]))
    except Exception:
        return np.nan


def run_cell(s, x, labels, test, device, epochs):
    shift = np.roll(s, T // 3, axis=0)
    h, acc_tr, acc_te, nll_te = fit_tcl(x, labels, test, s.shape[1], device, epochs=epochs)
    out = dict(acc_tr=acc_tr, acc_te=acc_te, nll_te=nll_te,
               tcl_s2=cca_mcc(h, s ** 2, test), tcl_abs=cca_mcc(h, np.abs(s), test),
               tcl_s=cca_mcc(h, s, test),
               null_s2=cca_mcc(h, shift ** 2, test), null_abs=cca_mcc(h, np.abs(shift), test),
               null_s=cca_mcc(h, shift, test))
    try:
        ica = FastICA(n_components=s.shape[1], max_iter=500, random_state=0).fit(x[~test])
        s_hat = ica.transform(x[test])
        out["ica"] = fas.mcc(s[test], s_hat)
        out["null_ica"] = fas.mcc(shift[test], s_hat)
    except Exception:
        out["ica"] = out["null_ica"] = np.nan
    return out


# ── main ─────────────────────────────────────────────────────────────────────

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--out", default="results/modulation_rank")
    ap.add_argument("--M", type=int, default=4)
    ap.add_argument("--n_seg", type=int, default=fas.N_SEG)
    ap.add_argument("--ranks", type=int, nargs="*", default=None,
                    help="numbers of distinct modulation profiles (default 1..M)")
    ap.add_argument("--alphas", type=float, nargs="*", default=ALPHAS,
                    help="shared-to-independent mixing weights (pass none to skip)")
    ap.add_argument("--gens", nargs="*", default=GENS)
    ap.add_argument("--seeds", type=int, nargs="*", default=SEEDS)
    ap.add_argument("--epochs", type=int, default=200)
    ap.add_argument("--plot_only", action="store_true")
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)
    M, n_seg = args.M, args.n_seg
    ranks = args.ranks if args.ranks is not None else list(range(1, M + 1))
    keys = ([("rank", r) for r in ranks] + [("alpha", a) for a in args.alphas]
            + [("ref", r) for r in REFS])

    if args.plot_only:
        plot(np.load(f"{args.out}/all_results.npy", allow_pickle=True).item(), args.out, n_seg)
        return

    labels, test = segments(n_seg)
    gens = Generators(args.device)
    W = gens.W(M)
    print(f"M={M}  D={D}  T={T}  n_seg={n_seg}  held-out {int(test.sum())} samples  "
          f"SNR={SNR_DB} dB  epochs={args.epochs}  seeds={args.seeds}")

    results = {g: {k: [] for k in keys} for g in args.gens}
    t0 = time.time()
    for gen in args.gens:
        print(f"\n{'=' * 60}\nGenerator: {gen}")
        for key in keys:
            for seed in args.seeds:
                sigma2 = sigma2_for(key, n_seg, M, np.random.default_rng(seed))
                rng = np.random.default_rng(1000 + seed)            # base sources + noise
                base = (rng.standard_normal((T, M)) if gen == "exact"
                        else gens.sources(M, seed).astype(np.float64))
                s = (base * np.sqrt(sigma2)[labels]).astype(np.float32)
                x = fas.add_noise(fas.mix(s, W, "linear"), SNR_DB, "gaussian", rng)
                torch.manual_seed(seed)
                cell = run_cell(s, x, labels, test, args.device, args.epochs)
                cell.update(strength(sigma2))
                results[gen][key].append(cell)
            mean = {k: np.nanmean([c[k] for c in results[gen][key]]) for k in SCORES}
            print(f"  {key[0]:>5}={str(key[1]):<15} acc_te={mean['acc_te']:.2f} "
                  f"nll_te={mean['nll_te']:.2f}  TCL s2={mean['tcl_s2']:.3f} "
                  f"|s|={mean['tcl_abs']:.3f} s={mean['tcl_s']:.3f}  ICA={mean['ica']:.3f}  "
                  f"null={mean['null_s2']:.2f}  logvar_std={mean['logvar_std']:.2f} "
                  f"rank(L)={mean['rank_L']:.0f} cond(L)={np.nanmedian([c['cond_L'] for c in results[gen][key]]):.3g}"
                  f"   [{time.time() - t0:.0f}s]")
            np.save(f"{args.out}/all_results.npy", results)

    lines = [f"modulation-rank sweep  M={M} n_seg={n_seg} SNR={SNR_DB} dB  "
             f"(mean +- std over {len(args.seeds)} seeds, held-out block; cond_L is the median)",
             f"{'gen':<8}{'cond':<22}" + "".join(f"{k:>14}" for k in SCORES)]
    for gen in args.gens:
        for key in keys:
            vals = {k: [c[k] for c in results[gen][key]] for k in SCORES}
            row = "".join(f"{np.nanmean(vals[k]):>8.3f}+-{np.nanstd(vals[k]):<4.2f}"
                          for k in SCORES[:-1])
            lines.append(f"{gen:<8}{key[0] + '=' + str(key[1]):<22}{row}"
                         f"{np.nanmedian(vals['cond_L']):>14.3g}")
    summary = "\n".join(lines)
    print("\n" + summary)
    with open(f"{args.out}/summary.txt", "w") as f:
        f.write(summary + "\n")
    plot(results, args.out, n_seg)
    print(f"\nSaved to {args.out}/  ({time.time() - t0:.0f}s)")


# ── figure ───────────────────────────────────────────────────────────────────

def plot(results, out, n_seg):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({"font.size": 8, "axes.spines.top": False, "axes.spines.right": False,
                         "pdf.fonttype": 42})
    ORANGE, BLUE = "#E69F00", "#0072B2"
    series = [("tcl_s2", ORANGE, "-", r"TCL vs $s^2$"), ("tcl_abs", ORANGE, "--", r"TCL vs $|s|$"),
              ("tcl_s", ORANGE, ":", r"TCL vs $s$"), ("ica", BLUE, "-", "FastICA vs $s$"),
              ("acc_te", "k", "--", "TCL held-out segment acc.")]
    gens = list(results)
    fig, axes = plt.subplots(len(gens), 3, figsize=(7.0, 2.3 * len(gens)), squeeze=False,
                             gridspec_kw=dict(width_ratios=[3, 3, 1.2]))
    for i, gen in enumerate(gens):
        res = results[gen]
        groups = [("rank", [k for k in res if k[0] == "rank"], "distinct modulation profiles (rank of $L$)"),
                  ("alpha", [k for k in res if k[0] == "alpha"], r"source-specific weight $a$ (0: shared, 1: independent)"),
                  ("ref", [k for k in res if k[0] == "ref"], "")]
        for j, (kind, keys, xlabel) in enumerate(groups):
            ax = axes[i, j]
            if not keys:
                ax.axis("off")
                continue
            xs = np.arange(len(keys)) if kind == "ref" else np.array([k[1] for k in keys], float)
            for score, color, ls, label in series:
                mu = np.array([np.nanmean([c[score] for c in res[k]]) for k in keys])
                sd = np.array([np.nanstd([c[score] for c in res[k]]) for k in keys])
                if kind == "ref":      # single x: band has no width, use error bars
                    ax.errorbar(xs, mu, yerr=sd, fmt="o", color=color, ms=3, lw=1.2,
                                capsize=2, label=label)
                else:
                    ax.plot(xs, mu, ls, color=color, marker="o", ms=3, lw=1.2, label=label)
                    ax.fill_between(xs, mu - sd, mu + sd, color=color, alpha=0.12, lw=0)
            null = np.nanmean([np.nanmean([c["null_s2"] for c in res[k]]) for k in keys])
            ax.axhline(null, color="grey", lw=0.8, alpha=0.6)
            ax.axhline(1.0 / n_seg, color="grey", lw=0.8, ls=":", alpha=0.6)
            if kind == "rank":
                ax.set_xticks(xs)
            if kind == "ref":
                ax.set_xticks(xs)
                ax.set_xticklabels(["shared\nExp(1)\namplitude"], fontsize=7)
                ax.set_xlim(-0.7, 0.7)
            ax.set_ylim(-0.02, 1.02)
            ax.set_xlabel(xlabel)
            if j == 0:
                ax.set_ylabel(f"{gen} sources\nheld-out score")
            ax.text(0.02, 0.98, "abcdefghi"[i * 3 + j], transform=ax.transAxes,
                    fontweight="bold", va="top")
    handles, labels_ = axes[0, 1].get_legend_handles_labels()
    fig.legend(handles, labels_, fontsize=7, ncol=5, loc="lower center", frameon=False,
               bbox_to_anchor=(0.5, -0.01))
    fig.tight_layout(rect=(0, 0.04, 1, 1))
    for ext in ("pdf", "png"):
        fig.savefig(f"{out}/fig_modulation_rank.{ext}", dpi=200, bbox_inches="tight")
    plt.close(fig)


if __name__ == "__main__":
    main()
