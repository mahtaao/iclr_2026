"""D10: the whole held-out benchmark on generators with EEG-like free-run dynamics.

Recipe from D9: run_bci_mps.sh with --tf_alpha_end 0.2 --hidden_size 64 (GTF floor
0.2 instead of 0), one generator per M in {2, 4, 8, 16, 22}, names
trained_models/bci/bci/g_tf02_h64_M{M}/001.  Then shplrnn_axis_heldout.main with
GEN_DIR pointed at them (same grid, seeds, methods, nulls, rotation reference),
output results/autoresearch_oct7/heldout_realistic/, then PCL and fixed-scale
iVAE on the new cells."""
import os, sys, time, subprocess, warnings, numpy as np, torch
warnings.filterwarnings("ignore")
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE); sys.path.insert(0, os.path.dirname(HERE))
OUT = "results/autoresearch_oct7/heldout_realistic"; os.makedirs(OUT, exist_ok=True)
for M in [2, 4, 8, 16, 22]:
    name = f"g_tf02_h64_M{M}"; path = f"trained_models/bci/bci/{name}/001"
    if not os.path.exists(f"{path}/model_500.pt"):
        t0 = time.time()
        subprocess.run(["bash", "scripts/run_bci_mps.sh", "--name", name, "--latent_size", str(M), "--tf_alpha_end", "0.2", "--hidden_size", "64"],
                       stdout=open(f"{OUT}/train_{name}.log", "w"), stderr=subprocess.STDOUT, env={**os.environ, "RUN": "1"})
        print(f"trained {name} in {time.time()-t0:.0f}s", flush=True)
import shplrnn_axis_heldout as hb
hb.GEN_DIR = "trained_models/bci/bci/g_tf02_h64_M{M}/001"
torch.set_num_threads(4)
sys.argv = ["shplrnn_axis_heldout.py", "--device", "cpu", "--out", OUT]
hb.main()
# PCL and fixed-scale iVAE on the new cells
from ar_pcl import fit_pcl
from ar_fill_cells import fit_ivae_fixed   # module-level code of ar_fill_cells is guarded below
res = {}
t0 = time.time()
for ax, cfgs in hb.AXES.items():
    for cfg in cfgs:
        for seed in hb.SEEDS:
            c = dict(np.load(f"{OUT}/cells/{ax}_{cfg}_seed{seed}.npz")); z_tr, z_te = c["z_tr"], c["z_te"]; n = z_tr.shape[1]
            torch.manual_seed(seed); h_tr, h_te, _ = fit_pcl(c["x_tr"], c["x_te"], n, "cpu", 200)
            torch.manual_seed(seed); v_tr, v_te = fit_ivae_fixed(c["x_tr"], c["x_te"], c["labels"], n, "cpu")
            res[(ax, cfg, seed)] = dict(PCL=hb.strong_heldout(z_tr, h_tr, z_te, h_te), iVAEfix=hb.strong_heldout(z_tr, v_tr, z_te, v_te))
            np.save(f"{OUT}/pcl_ivaefix.npy", res)
        print(f"{ax} {cfg}: PCL {np.mean([res[(ax,cfg,s)]['PCL'] for s in hb.SEEDS]):.2f} iVAEfix {np.mean([res[(ax,cfg,s)]['iVAEfix'] for s in hb.SEEDS]):.2f} [{time.time()-t0:.0f}s]", flush=True)
old = np.load("results/shplrnn_axis_heldout/all_results.npy", allow_pickle=True).item(); new = np.load(f"{OUT}/all_results.npy", allow_pickle=True).item()
lines = ["# D10: held-out benchmark on EEG-like generators (tf floor 0.2, hidden 64); original generator in parentheses", "| axis | cfg | PCA | FastICA | TCL | iVAE shipped | iVAE fixed | PCL |", "|---|---|---|---|---|---|---|---|"]
for ax, cfgs in hb.AXES.items():
    for cfg in cfgs:
        f = lambda m: f"{np.nanmean(new[ax][m][cfg]):.2f} ({np.nanmean(old[ax][m][cfg]):.2f})"
        lines.append(f"| {ax} | {cfg} | {f('PCA')} | {f('FastICA')} | {f('TCL')} | {f('iVAE')} | {np.mean([res[(ax,cfg,s)]['iVAEfix'] for s in hb.SEEDS]):.2f} | {np.mean([res[(ax,cfg,s)]['PCL'] for s in hb.SEEDS]):.2f} |")
open(f"{OUT}/summary_vs_original.md", "w").write("\n".join(lines) + "\n"); print("\n".join(lines))
