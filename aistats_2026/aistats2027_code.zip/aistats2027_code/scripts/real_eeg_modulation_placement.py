"""Where does real scalp EEG sit on the modulation-diversity axis?

The modulation-rank sweep (scripts/modulation_rank_sweep.py, results/modulation_rank)
shows that TCL's recovery is set by how many distinct segment-wise modulation
profiles the sources have (rank and conditioning of the theorem's L), not by how
much the variance changes. Recovery can only be scored on synthetic data, but the
modulation itself can be measured on any recording. This script computes one
observational statistic, with an identical pipeline, on (i) the sweep's synthetic
conditions and (ii) real BCI IV-2a EEG, so that real EEG can be placed on the
sweep's axis.

Statistic.  Cut the recording into the 20 contiguous segments TCL uses; take each
segment's channel covariance C_tau, whiten by the mean covariance and take the
matrix log, L_tau = logm(Cbar^-1/2 C_tau Cbar^-1/2) (a gain shared by every
source is one fixed direction, independent source-wise changes are different
directions); centre over segments and take the singular values of the stack.
  pc1_share   fraction of the segment-to-segment change that follows the single
              dominant pattern, after subtracting the mean spectrum of stationary
              surrogates (multivariate phase randomisation of the whole recording:
              same auto- and cross-spectra, no nonstationarity). Near 1 means one
              shared profile (rank-one L).
  n_patterns  leading singular values above the 95th percentile of the surrogates
              (parallel analysis): distinct modulation patterns detectable.
  iso_share   fraction of the modulation energy in the identity direction (a gain
              common to every channel), raw.
  excess      modulation energy / mean surrogate energy.

Synthetic.  Exact Gaussian sources with the sweep's per-seed variance profiles
(modulation_rank_sweep.sigma2_for, same seeds), the learned M = 4 W, 20 dB
Gaussian noise. Computed on the sweep's own T = 2000 data (the data TCL was scored
on) and on 5000 samples per segment (population value, comparable to the ~29,000
samples per segment of the real recordings). Paired with the sweep's held-out TCL
recovery (vs s^2) per seed.

Real.  BCI IV-2a training sessions, 9 subjects, the 6 motor-imagery runs
concatenated (A04T has one calibration run, the others three), 22 EEG channels,
1-40 Hz (8-30 Hz as a check).

Usage:
    python scripts/real_eeg_modulation_placement.py
"""
import os
import sys
import argparse
import numpy as np
import scipy.io as sio
from scipy.signal import butter, sosfiltfilt

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
sys.path.insert(0, HERE)
import failure_axis_sweep as fas
import modulation_rank_sweep as mrs
from simulate_generator import load_generator

M, N_SEG = 4, fas.N_SEG
N_SURR = 20
LONG = 5000
GEN_DIR = "trained_models/bci/bci/linear_M{M}/001"
DATA = "data/bci/data.pt"
BCI = "data/bci/A0{}T.mat"
FS = 250
BANDS = {"1-40Hz": (1, 40), "8-30Hz": (8, 30)}
STATS = ["pc1_share", "pc1_raw", "n_patterns", "iso_share", "excess"]


# ── observational statistic ──────────────────────────────────────────────────

def seg_covs(x, labels):
    Cs = []
    for g in range(int(labels.max()) + 1):
        C = np.cov(x[labels == g].T)
        Cs.append(C + 1e-6 * np.trace(C) / len(C) * np.eye(len(C)))
    return np.array(Cs)


def tangent(Cs):
    """Centred affine-invariant tangent vectors logm(Cbar^-1/2 C Cbar^-1/2)."""
    w, U = np.linalg.eigh(Cs.mean(0))
    P = (U * w ** -0.5) @ U.T
    Ls = []
    for C in Cs:
        lw, lU = np.linalg.eigh(P @ C @ P)
        Ls.append((lU * np.log(lw)) @ lU.T)
    Ls = np.array(Ls)
    return Ls - Ls.mean(0)


def spectrum(Ls):
    """Squared singular values of the stack, Frobenius-preserving vectorisation."""
    iu = np.triu_indices(Ls.shape[1])
    wgt = np.where(iu[0] == iu[1], 1.0, np.sqrt(2))
    return np.linalg.svd(Ls[:, iu[0], iu[1]] * wgt, compute_uv=False) ** 2


def phase_surrogate(x, rng):
    """Same random phase for every channel: keeps auto- and cross-spectra."""
    F = np.fft.rfft(x, axis=0)
    ph = np.exp(1j * rng.uniform(0, 2 * np.pi, len(F)))
    ph[0] = 1.0
    if len(x) % 2 == 0:
        ph[-1] = 1.0
    return np.fft.irfft(F * ph[:, None], n=len(x), axis=0)


def modulation_stats(x, labels, rng):
    Ls = tangent(seg_covs(x, labels))
    ev = spectrum(Ls)
    sur = np.array([spectrum(tangent(seg_covs(phase_surrogate(x, rng), labels)))
                    for _ in range(N_SURR)])
    mu, q95 = sur.mean(0), np.percentile(sur, 95, axis=0)
    ex = np.clip(ev - mu, 0.0, None)
    above = ev > q95
    tr = np.trace(Ls, axis1=1, axis2=2)
    return dict(pc1_share=float(ex[0] / ex.sum()) if ex.sum() > 0 else np.nan,
                pc1_raw=float(ev[0] / ev.sum()),
                n_patterns=int(len(ev) if above.all() else np.argmin(above)),
                iso_share=float(np.sum(tr ** 2) / Ls.shape[1] / np.sum(Ls ** 2)),
                excess=float(ev.sum() / mu.sum()))


# ── data ─────────────────────────────────────────────────────────────────────

def synthetic(key, seed, W, n_per_seg):
    """The sweep's exact-generator data for (key, seed); n_per_seg = 100
    reproduces the sweep's T = 2000 sample exactly, larger values draw new
    sources with the same variance profiles."""
    sigma2 = mrs.sigma2_for(key, N_SEG, M, np.random.default_rng(seed))
    labels = np.repeat(np.arange(N_SEG), n_per_seg)
    rng = np.random.default_rng(1000 + seed if n_per_seg * N_SEG == fas.T else 50_000 + seed)
    base = rng.standard_normal((len(labels), M))
    s = (base * np.sqrt(sigma2)[labels]).astype(np.float32)
    x = fas.add_noise(fas.mix(s, W, "linear"), mrs.SNR_DB, "gaussian", rng)
    return x.astype(np.float64), labels


def real_eeg(subject, band):
    runs = sio.loadmat(BCI.format(subject), struct_as_record=False, squeeze_me=True)["data"]
    sos = butter(4, band, btype="band", fs=FS, output="sos")
    xs = [sosfiltfilt(sos, r.X[:, :fas.D] - r.X[:, :fas.D].mean(0), axis=0)
          for r in runs if np.atleast_1d(r.trial).size > 0]            # motor-imagery runs
    x = np.concatenate(xs)
    labels = np.minimum(np.arange(len(x)) * N_SEG // len(x), N_SEG - 1)
    return x, labels, len(xs)


# ── main ─────────────────────────────────────────────────────────────────────

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="results/real_eeg_placement")
    ap.add_argument("--sweep", default="results/modulation_rank/all_results.npy")
    ap.add_argument("--plot_only", action="store_true")
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)
    if args.plot_only:
        plot(np.load(f"{args.out}/all_results.npy", allow_pickle=True).item(), args.out)
        return

    sweep = np.load(args.sweep, allow_pickle=True).item()["exact"]
    W = load_generator(GEN_DIR.format(M=M), DATA, "cpu").obs_matrix.detach().cpu().numpy()
    rng = np.random.default_rng(0)
    res = {"synthetic": {}, "real": {}}

    for key, cells in sweep.items():
        rows = []
        for seed, cell in enumerate(cells):
            row = dict(tcl_s2=cell["tcl_s2"], tcl_abs=cell["tcl_abs"], ica=cell["ica"],
                       cond_L=cell["cond_L"])
            for tag, n in (("T2000", fas.T // N_SEG), ("long", LONG)):
                x, labels = synthetic(key, seed, W, n)
                row.update({f"{k}_{tag}": v for k, v in modulation_stats(x, labels, rng).items()})
            rows.append(row)
        res["synthetic"][key] = rows
        print(f"{key[0]}={str(key[1]):<15} TCL s2={np.mean([r['tcl_s2'] for r in rows]):.2f}  "
              f"pc1_share long={np.mean([r['pc1_share_long'] for r in rows]):.2f} "
              f"T2000={np.mean([r['pc1_share_T2000'] for r in rows]):.2f}  "
              f"n_patterns long={np.mean([r['n_patterns_long'] for r in rows]):.1f}", flush=True)

    for band, lims in BANDS.items():
        res["real"][band] = {}
        for s in range(1, 10):
            x, labels, n_runs = real_eeg(s, lims)
            st = modulation_stats(x, labels, rng)
            st.update(n_runs=n_runs, samples_per_segment=len(x) // N_SEG)
            res["real"][band][s] = st
            print(f"real {band} A0{s}: " + "  ".join(f"{k}={st[k]:.2f}" for k in STATS), flush=True)

    np.save(f"{args.out}/all_results.npy", res)
    write_summary(res, args.out)
    plot(res, args.out)


def write_summary(res, out):
    L = ["Observational modulation statistics (see script docstring). Synthetic: mean +- std "
         "over 10 seeds; TCL recovery = held-out CCA vs s^2 from results/modulation_rank.",
         f"{'condition':<24}{'TCL_s2':>12}{'pc1_long':>12}{'pc1_T2000':>12}"
         f"{'npat_long':>11}{'npat_T2000':>11}{'iso_long':>10}{'cond_L':>9}"]
    for key, rows in res["synthetic"].items():
        f = lambda k: np.array([r[k] for r in rows], float)
        L.append(f"{key[0] + '=' + str(key[1]):<24}"
                 + "".join(f"{f(k).mean():>7.2f}+-{f(k).std():<4.2f}"
                           for k in ("tcl_s2", "pc1_share_long", "pc1_share_T2000"))
                 + f"{f('n_patterns_long').mean():>11.1f}{f('n_patterns_T2000').mean():>11.1f}"
                 + f"{f('iso_share_long').mean():>10.2f}{np.median(f('cond_L')):>9.3g}")
    for band, subj in res["real"].items():
        L.append(f"\nReal BCI IV-2a, {band}: " + "  ".join(STATS))
        for s, st in subj.items():
            L.append(f"  A0{s} ({st['n_runs']} runs, {st['samples_per_segment']} samples/segment): "
                     + "  ".join(f"{st[k]:.2f}" for k in STATS))
        arr = {k: np.array([st[k] for st in subj.values()], float) for k in STATS}
        L.append("  median: " + "  ".join(f"{k}={np.median(v):.2f}" for k, v in arr.items())
                 + "   range pc1_share: "
                 + f"{arr['pc1_share'].min():.2f}-{arr['pc1_share'].max():.2f}")
    text = "\n".join(L)
    print("\n" + text)
    with open(f"{out}/summary.txt", "w") as fh:
        fh.write(text + "\n")


# ── figure ───────────────────────────────────────────────────────────────────

def plot(res, out):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({"font.size": 8, "axes.spines.top": False, "axes.spines.right": False,
                         "pdf.fonttype": 42})
    ORANGE, GREY = "#E69F00", "#555555"
    fig, ax = plt.subplots(figsize=(3.4, 2.6))

    real = np.array([st["pc1_share"] for st in res["real"]["1-40Hz"].values()])
    ax.axvspan(real.min(), real.max(), color=GREY, alpha=0.15, lw=0)
    ax.axvline(np.median(real), color=GREY, lw=1.0)
    ax.plot(real, np.full_like(real, 0.03), "|", color=GREY, ms=8, mew=1.2)
    ax.text(np.median(real), 0.08, " real EEG\n (9 subjects)", color=GREY, fontsize=7, va="bottom")

    syn = res["synthetic"]
    for kind, marker, ls, label in (("alpha", "o", "-", "shared + source-specific (weight $a$)"),
                                    ("rank", "s", "--", "distinct profiles (rank of $L$)")):
        keys = [k for k in syn if k[0] == kind]
        x = np.array([[r["pc1_share_long"] for r in syn[k]] for k in keys])
        y = np.array([[r["tcl_s2"] for r in syn[k]] for k in keys])
        ax.errorbar(x.mean(1), y.mean(1), xerr=x.std(1), yerr=y.std(1), fmt=marker, ls=ls,
                    color=ORANGE, ms=3.5, lw=1.0, capsize=1.5, label=label)
        for k, xi, yi in zip(keys, x.mean(1), y.mean(1)):
            if (kind == "alpha" and k[1] in (0.75, 1.0)) or (kind == "rank" and k[1] == 4):
                continue                      # same cluster as the source-aligned label below
            txt = f"a={k[1]:g}" if kind == "alpha" else f"r={k[1]}"
            ax.annotate(txt, (xi, yi), textcoords="offset points",
                        xytext=(4, -9) if kind == "rank" else (4, 3), fontsize=6, color=ORANGE)
    sa = [r["pc1_share_long"] for r in syn[("alpha", 1.0)]], [r["tcl_s2"] for r in syn[("alpha", 1.0)]]
    ax.annotate("source-aligned\n(a=1, r=4)", (np.mean(sa[0]), np.mean(sa[1])), textcoords="offset points",
                xytext=(-2, 8), fontsize=6, color=ORANGE, ha="center")
    ref = [k for k in syn if k[0] == "ref"]
    if ref:
        xr = [r["pc1_share_long"] for r in syn[ref[0]]]
        yr = [r["tcl_s2"] for r in syn[ref[0]]]
        ax.errorbar(np.mean(xr), np.mean(yr), xerr=np.std(xr), yerr=np.std(yr), fmt="x",
                    color="k", ms=4, lw=1.0, capsize=1.5, label="paper's global-scale cell")

    ax.set_xlim(0, 1.02)
    ax.set_ylim(0, 1.0)
    ax.set_xlabel("one-pattern share of segment-wise modulation\n(observable without ground truth)")
    ax.set_ylabel(r"TCL recovery (held-out CCA vs $s^2$)")
    ax.legend(fontsize=6.5, frameon=False, loc="lower left", bbox_to_anchor=(0.0, 0.16))
    fig.tight_layout()
    for ext in ("pdf", "png"):
        fig.savefig(f"{out}/fig_real_eeg_placement.{ext}", dpi=200, bbox_inches="tight")
    plt.close(fig)


if __name__ == "__main__":
    main()
