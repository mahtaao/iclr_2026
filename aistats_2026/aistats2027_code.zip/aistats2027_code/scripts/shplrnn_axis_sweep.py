"""Failure-axis sweep with the trained shPLRNN's own latent trajectories as the
ground-truth sources (what Sec. 4 / App. A of the paper state), in place of the
synthetic white-noise/AR sources of failure_axis_sweep.py.

Sources. Stochastic free-run of the trained generator,
    z_t = f_subject(z_{t-1}) + eps_t,   eps_t ~ N(0, diag(sigma^2)),
with sigma the per-dimension std of the generator's one-step prediction residual
on its real training EEG (simulate_generator.calibrate_process_noise). The
deterministic free-run contracts to a fixed point within ~10-50 steps for every
subject and therefore carries no source signal; the stochastic PLRNN is the
standard generative form of the model. Each seed draws one subject (its own
hierarchical parameters), free-runs from that subject's first real frame,
discards BURN_IN steps, keeps T, and standardises each latent to unit variance
(MCC is invariant to this; it puts the axes at the same operating point as the
synthetic sweep).

Everything downstream of the sources is failure_axis_sweep.py's: the five axes
and their configurations, the segment construction (N_SEG = 20 over T = 2000),
the segment-wise variance modulation (source-aligned by default, varied on axis
(d)), the AR(1) coupling, the mixing nonlinearities, the noise models, the four
methods, and the CORRECTED scoring (strong MCC for PCA/FastICA/iVAE; CCA MCC
against |s| for TCL). Mixing uses each generator's learned W. Axis (e) uses a
generator trained with the corresponding latent size M (same training recipe as
the M = 4 generator, scripts/run_bci_mps.sh) and that generator's own W, where
the synthetic sweep used a random W.

Also measures the per-condition chance level on these sources (independent
draw and circular time shift, as scripts/failure_axis_null.py does for the
synthetic sources), so plot_failure_sweep.py can draw the band.

Writes <out>/all_results.npy, <out>/null_levels.npy and <out>/summary.txt in
the formats plot_failure_sweep.py reads (set SWEEP_RESULTS / NULL_LEVELS /
FIG_OUTDIR).

Usage:
    python scripts/shplrnn_axis_sweep.py --device cpu
"""
import os
import sys
import time
import argparse
import numpy as np
import torch

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
sys.path.insert(0, HERE)
import failure_axis_sweep as fas
from simulate_generator import load_generator, simulate, calibrate_process_noise

METHODS = fas.METHODS
SEEDS = fas.SEEDS
T, D, N_SEG = fas.T, fas.D, fas.N_SEG
BURN_IN = 500
DATA = "data/bci/data.pt"
GEN_DIR = "trained_models/bci/bci/linear_M{M}/001"
M_CONFIGS = [2, 4, 8, 16, 22]
N_NULL = 20
NULL_SEED = 10_000

AXES = {
    "1f_snr":   [30, 15, 10, 5, 0],
    "nonlin":   ["linear", "cube", "tanh"],
    "coupling": [0.0, 0.1, 0.3, 0.6, 0.9],
    "ns":       ["stationary", "source_aligned", "confounder_aligned"],
    "m_vs_d":   M_CONFIGS,
}


# ── generator sources ────────────────────────────────────────────────────────

class Generators:
    """Lazy per-M generator loading, noise calibration and source caching."""

    def __init__(self, device):
        self.device = device
        self.models, self.sigmas, self.cache = {}, {}, {}

    def load(self, M):
        if M not in self.models:
            path = GEN_DIR.format(M=M)
            model = load_generator(path, DATA, self.device)
            assert model.dz == M and model.dx == D, (model.dz, model.dx)
            self.models[M] = model
            self.sigmas[M] = calibrate_process_noise(model, DATA, self.device)
            print(f"[gen M={M}] {path}  process-noise std per dim: "
                  f"{np.round(self.sigmas[M].cpu().numpy(), 3)}")
        return self.models[M]

    def W(self, M):
        return self.load(M).obs_matrix.detach().cpu().numpy().astype(np.float32)   # (M, D)

    def sources(self, M, seed):
        """Standardised shPLRNN latents (T, M) for one seed."""
        key = (M, seed)
        if key not in self.cache:
            model = self.load(M)
            z, _ = simulate(model, DATA, n_trials=1, T=T, device=self.device, seed=seed,
                            process_noise=self.sigmas[M], burn_in=BURN_IN)
            z = z[0].astype(np.float64)
            z = (z - z.mean(0)) / z.std(0)
            self.cache[key] = z.astype(np.float32)
        return self.cache[key]


# ── the same per-source transforms as failure_axis_sweep.make_sources ────────

def modulate(z0, ns_mode, rng):
    """Segment-wise variance modulation, exactly as make_sources applies it to
    its white-noise base: per-source Exp(1) variances (source_aligned), one
    Exp(1) amplitude shared by all sources (confounder_aligned), or none."""
    z = z0.copy()
    if ns_mode == "stationary":
        return z
    T_, M_ = z.shape
    seg_len = T_ // N_SEG
    for seg in range(N_SEG):
        t0, t1 = seg * seg_len, min((seg + 1) * seg_len, T_)
        if ns_mode == "source_aligned":
            z[t0:t1] *= np.sqrt(rng.exponential(1.0, M_)).astype(np.float32)
        elif ns_mode == "confounder_aligned":
            z[t0:t1] *= np.float32(rng.exponential(1.0))
        else:
            raise ValueError(ns_mode)
    return z


def couple(z, coupling, rng):
    """Coupled AR(1), as in make_sources: z_t <- (1-c) z_t + c A z_{t-1}."""
    if coupling <= 0.0:
        return z
    z = z.copy()
    M_ = z.shape[1]
    A = rng.standard_normal((M_, M_)).astype(np.float32)
    A /= (np.linalg.norm(A, 2) + 1e-6)
    for t in range(1, len(z)):
        z[t] = (1 - coupling) * z[t] + coupling * (A @ z[t - 1])
    return z


def make_sources(gens, M, seed, coupling=0.0, ns_mode="source_aligned", rng=None):
    z = modulate(gens.sources(M, seed), ns_mode, rng)
    return couple(z, coupling, rng)


# ── per-axis data construction (mirrors failure_axis_sweep.main) ─────────────

def make_data(axis, cfg, seed, gens):
    rng = np.random.default_rng(seed)
    labels = fas.make_segment_labels(T, N_SEG)
    if axis == "1f_snr":
        z = make_sources(gens, 4, seed, rng=rng)
        x = fas.add_noise(fas.mix(z, gens.W(4), "linear"), cfg, "pink", rng)
    elif axis == "nonlin":
        z = make_sources(gens, 4, seed, rng=rng)
        x = fas.add_noise(fas.mix(z, gens.W(4), cfg), 20, "gaussian", rng)
    elif axis == "coupling":
        z = make_sources(gens, 4, seed, coupling=cfg, rng=rng)
        x = fas.add_noise(fas.mix(z, gens.W(4), "linear"), 20, "gaussian", rng)
    elif axis == "ns":
        z = make_sources(gens, 4, seed, ns_mode=cfg, rng=rng)
        x = fas.add_noise(fas.mix(z, gens.W(4), "linear"), 15, "pink", rng)
    elif axis == "m_vs_d":
        z = make_sources(gens, cfg, seed, rng=rng)
        x = fas.add_noise(fas.mix(z, gens.W(cfg), "linear"), 20, "gaussian", rng)
    else:
        raise ValueError(axis)
    return z, x, labels


def null_kwargs(axis, cfg):
    """Only the source distribution matters for the null (as in failure_axis_null)."""
    if axis == "coupling":
        return dict(M=4, coupling=cfg, ns_mode="source_aligned")
    if axis == "ns":
        return dict(M=4, coupling=0.0, ns_mode=cfg)
    if axis == "m_vs_d":
        return dict(M=cfg, coupling=0.0, ns_mode="source_aligned")
    return dict(M=4, coupling=0.0, ns_mode="source_aligned")


def null_cell(gens, M, coupling, ns_mode):
    out = {k: [] for k in ("strong_independent", "strong_timeshift",
                           "weak_independent", "weak_timeshift")}
    for r in range(N_NULL):
        z = make_sources(gens, M, NULL_SEED + r, coupling, ns_mode,
                         rng=np.random.default_rng(NULL_SEED + r))
        indep = make_sources(gens, M, NULL_SEED + 500 + r, coupling, ns_mode,
                             rng=np.random.default_rng(NULL_SEED + 500 + r))
        shifted = np.roll(z, T // 3 + 7 * r, axis=0)
        out["strong_independent"].append(fas.mcc(z, indep))
        out["strong_timeshift"].append(fas.mcc(z, shifted))
        out["weak_independent"].append(fas.weak_mcc(np.abs(z), indep))
        out["weak_timeshift"].append(fas.weak_mcc(np.abs(z), shifted))
    return {k: (float(np.nanmean(v)), float(np.nanstd(v)), float(np.nanpercentile(v, 95)))
            for k, v in out.items()}


# ── main ─────────────────────────────────────────────────────────────────────

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--out", default="results/shplrnn_axis")
    ap.add_argument("--axes", nargs="*", default=list(AXES),
                    help="subset of axes to run (default: all five)")
    ap.add_argument("--skip_null", action="store_true")
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)

    fas.CORRECTED = True
    print("Scoring: CORRECTED (strong MCC for PCA/FastICA/iVAE; CCA MCC vs |s| for TCL)")
    print(f"Sources: stochastic shPLRNN free-run, burn-in {BURN_IN}, T={T}, N_SEG={N_SEG}, "
          f"seeds={SEEDS}, device={args.device}")
    gens = Generators(args.device)

    results = {}
    t_start = time.time()
    for axis in args.axes:
        cfgs = AXES[axis]
        results[axis] = {m: {c: [] for c in cfgs} for m in METHODS}
        print(f"\n{'=' * 60}\nAxis: {axis}")
        for cfg in cfgs:
            for seed in SEEDS:
                torch.manual_seed(seed)
                z, x, labels = make_data(axis, cfg, seed, gens)
                cell = fas.run_cell(z, x, labels, device=args.device, n_comp=z.shape[1])
                for m in METHODS:
                    results[axis][m][cfg].append(cell.get(m, np.nan))
            line = " | ".join(f"{m}={np.nanmean(results[axis][m][cfg]):.3f}" for m in METHODS)
            print(f"  {axis}={cfg}: {line}   [{time.time() - t_start:.0f}s]")
        np.save(f"{args.out}/all_results.npy", results)   # checkpoint after each axis

    if not args.skip_null:
        nulls = {}
        print(f"\n{'=' * 60}\nNull (chance) levels, {N_NULL} surrogate repeats per cell")
        for axis in args.axes:
            nulls[axis] = {}
            for cfg in AXES[axis]:
                nulls[axis][cfg] = null_cell(gens, **null_kwargs(axis, cfg))
                s = nulls[axis][cfg]
                print(f"  {axis:>8} {str(cfg):>18}  strong {s['strong_independent'][0]:.3f}/"
                      f"{s['strong_timeshift'][0]:.3f}  weak {s['weak_independent'][0]:.3f}/"
                      f"{s['weak_timeshift'][0]:.3f}  (indep/timeshift)")
        np.save(f"{args.out}/null_levels.npy", nulls)

    # summary table
    lines = [f"shPLRNN-source failure-axis sweep  (mean +- std over {len(SEEDS)} seeds)",
             f"{'axis':<10}{'config':<20}" + "".join(f"{m:>16}" for m in METHODS)]
    for axis in args.axes:
        for cfg in AXES[axis]:
            row = "".join(f"{np.nanmean(results[axis][m][cfg]):>9.3f}+-"
                          f"{np.nanstd(results[axis][m][cfg]):<5.3f}" for m in METHODS)
            lines.append(f"{axis:<10}{str(cfg):<20}{row}")
    summary = "\n".join(lines)
    print("\n" + summary)
    with open(f"{args.out}/summary.txt", "w") as f:
        f.write(summary + "\n")
    print(f"\nSaved to {args.out}/  ({time.time() - t_start:.0f}s)")


if __name__ == "__main__":
    main()
