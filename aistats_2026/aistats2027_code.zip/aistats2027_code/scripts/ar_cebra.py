"""D6: CEBRA (Schneider, Lee & Mathis 2023) on every saved held-out cell.

Two variants.  Model: per-timestep MLP with non-normalised output
(offset1-model-mse, Euclidean distance; the package default offset10-model with
cosine distance puts the embedding on a sphere and loses amplitude, giving
permutation MCC at the null in every cell),
temperature 1, lr 3e-4, batch 256, 500 iterations, output dimension M:
  time      CEBRA-Time, no labels, positive pairs at time offsets <= 10
  segment   CEBRA with the 20 segment labels as a discrete auxiliary variable
            (conditional='time_delta'), i.e. the label-conditioned contrastive
            counterpart of TCL
CEBRA's consistency claim is up to a linear transform; on this benchmark its
features are energy-like (CCA vs s <= 0.18, CCA vs |s| ~0.8 on the clean cell), so
the comparable score is TCL's, CCA-MCC vs |s|; permutation MCC and CCA vs s are
also written.  Fit on x_train, embedding of x_test scored held-out
(CCA / matching fit on train).  Needs the scratch install:
    PYTHONPATH=<scratch>/cebra_site python scripts/ar_cebra.py
"""
import os, sys, time, argparse, warnings, numpy as np, torch
warnings.filterwarnings("ignore")
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE); sys.path.insert(0, os.path.dirname(HERE))
import shplrnn_axis_heldout as hb
import cebra
torch.set_num_threads(2)
CELLS = "results/shplrnn_axis_heldout/cells"; OUT = "results/autoresearch_oct7/cebra"; os.makedirs(f"{OUT}/cells", exist_ok=True)
ap = argparse.ArgumentParser(); ap.add_argument("--iters", type=int, default=500); ap.add_argument("--seeds", type=int, nargs="*", default=hb.SEEDS); args = ap.parse_args()

def fit(x_tr, x_te, labels, n, variant):
    kw = dict(model_architecture="offset1-model-mse", batch_size=256, learning_rate=3e-4, temperature=1, output_dimension=n, max_iterations=args.iters, distance="euclidean", device="cpu", verbose=False, time_offsets=10)
    if variant == "time":
        m = cebra.CEBRA(conditional="time", **kw); m.fit(x_tr)
    else:
        m = cebra.CEBRA(conditional="time_delta", **kw); m.fit(x_tr, labels.astype(int))
    return m.transform(x_tr), m.transform(x_te)

path = f"{OUT}/cebra.npy"; res = np.load(path, allow_pickle=True).item() if os.path.exists(path) else {}
t0 = time.time()
for ax, cfgs in hb.AXES.items():
    for cfg in cfgs:
        for seed in args.seeds:
            key = (ax, cfg, seed)
            if key in res: continue
            c = dict(np.load(f"{CELLS}/{ax}_{cfg}_seed{seed}.npz")); z_tr, z_te = c["z_tr"], c["z_te"]; n = z_tr.shape[1]
            r = {}
            for v in ("time", "segment"):
                torch.manual_seed(seed); np.random.seed(seed)
                h_tr, h_te = fit(c["x_tr"], c["x_te"], c["labels"], n, v)
                np.savez(f"{OUT}/cells/{ax}_{cfg}_seed{seed}_{v}.npz", tr=h_tr, te=h_te)
                r[f"{v}_perm_s"] = hb.strong_heldout(z_tr, h_tr, z_te, h_te); r[f"{v}_cca_s"] = hb.weak_heldout(z_tr, h_tr, z_te, h_te); r[f"{v}_cca_abs"] = hb.weak_heldout(np.abs(z_tr), h_tr, np.abs(z_te), h_te)
            res[key] = r; np.save(path, res)
        g = lambda q: np.nanmean([res[(ax, cfg, s)][q] for s in args.seeds])
        print(f"{ax:>8} {str(cfg):>18}: time perm {g('time_perm_s'):.2f} cca {g('time_cca_s'):.2f} cca|s| {g('time_cca_abs'):.2f} | segment perm {g('segment_perm_s'):.2f} cca {g('segment_cca_s'):.2f} cca|s| {g('segment_cca_abs'):.2f}  [{time.time()-t0:.0f}s]", flush=True)
lines = ["# D6: CEBRA on the held-out cells (mean over seeds)", "| axis | cfg | CEBRA-Time perm-MCC | CEBRA-Time CCA vs s | CEBRA-Time CCA vs abs s | CEBRA-segment perm-MCC | CEBRA-segment CCA vs s | CEBRA-segment CCA vs abs s |", "|---|---|---|---|---|---|---|---|"]
for ax, cfgs in hb.AXES.items():
    for cfg in cfgs:
        g = lambda q: np.nanmean([res[(ax, cfg, s)][q] for s in args.seeds])
        lines.append(f"| {ax} | {cfg} | {g('time_perm_s'):.2f} | {g('time_cca_s'):.2f} | {g('time_cca_abs'):.2f} | {g('segment_perm_s'):.2f} | {g('segment_cca_s'):.2f} | {g('segment_cca_abs'):.2f} |")
open(f"{OUT}/cebra.md", "w").write("\n".join(lines) + "\n"); print("\n".join(lines))
