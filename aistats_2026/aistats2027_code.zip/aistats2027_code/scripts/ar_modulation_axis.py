"""D2: modulation-diversity axis for all methods on shPLRNN sources, held-out.

Replaces the three categorical NS cells with a continuous, placeable axis.  Clean
operating point (M = 4, learned W, 20 dB Gaussian noise), 20 segments.  Per-source
log-variance profile = ((1 - a) g0 + a g_i) / sqrt((1-a)^2 + a^2), g0 shared
Exp(1)-log profile, g_i independent (modulation_rank_sweep.sigma2_for, "alpha");
a = 0 is a pure shared gain (rank-one L), a = 1 the paper's source-aligned law.
Rank cells r = 1..4 (sources in r groups sharing a profile) as a second set.
The same gains are applied to the train and test trajectories.

Per cell: PCA, FastICA, TCL (CCA vs |s| and vs s^2), shipped iVAE (raw x),
fixed-scale iVAE (standardised x, beta = 0.1; the ar_night E11 choice), and the
observational statistic one-pattern share (real_eeg_modulation_placement.
modulation_stats on x_train, 20 surrogates) so the cell can be placed against
real EEG (results/real_eeg_placement/summary.txt).  Held-out nulls per cell.
"""
import os, sys, time, argparse, warnings, numpy as np, torch
warnings.filterwarnings("ignore")
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE); sys.path.insert(0, os.path.dirname(HERE))
import shplrnn_axis_heldout as hb, failure_axis_sweep as fas, modulation_rank_sweep as mrs, real_eeg_modulation_placement as rep
torch.set_num_threads(2)
ap = argparse.ArgumentParser(); ap.add_argument("--device", default="cpu"); ap.add_argument("--seeds", type=int, nargs="*", default=hb.SEEDS)
ap.add_argument("--alphas", type=float, nargs="*", default=mrs.ALPHAS); ap.add_argument("--ranks", type=int, nargs="*", default=[1, 2, 3, 4])
ap.add_argument("--scale", type=float, default=1.0, help="multiply log-variance profiles (1 = paper)"); ap.add_argument("--out", default="results/autoresearch_oct7/modulation_axis")
args = ap.parse_args()
OUT = args.out; os.makedirs(f"{OUT}/cells", exist_ok=True)
M, SNR = 4, 20
gens = hb.Generators(args.device, OUT)
rep.N_SURR = 20

def fit_ivae_fixed(x_tr, x_te, labels, n, device, beta=0.1, epochs=200):
    mu, sd = x_tr.mean(0), x_tr.std(0) + 1e-8
    xs_tr, xs_te = ((x_tr - mu) / sd).astype(np.float32), ((x_te - mu) / sd).astype(np.float32)
    n_seg = int(labels.max()) + 1
    X = torch.tensor(xs_tr); u = torch.zeros(len(x_tr), n_seg); u[torch.arange(len(x_tr)), torch.tensor(labels)] = 1.0
    model = fas.iVAENet(x_tr.shape[1], n, n_seg, 64).to(device); opt = torch.optim.Adam(model.parameters(), lr=1e-3)
    for _ in range(epochs):
        perm = torch.randperm(len(X))
        for i in range(0, len(X), 256):
            idx = perm[i:i + 256]; x_hat, z, z_mu, z_lv, p_mu, p_lv = model(X[idx], u[idx])
            kl = -0.5 * (1 + z_lv - p_lv - (z_mu - p_mu).pow(2) / p_lv.exp() - z_lv.exp() / p_lv.exp()).sum(-1)
            loss = ((x_hat - X[idx]) ** 2).mean() + beta * kl.mean(); opt.zero_grad(); loss.backward(); opt.step()
    model.eval()
    with torch.no_grad():
        return model(X, u)[2].numpy(), model(torch.tensor(xs_te), u)[2].numpy()

def make_cell(key, seed):
    rng = np.random.default_rng(seed)
    z_tr, z_te = gens.pair(M, seed)
    labels = fas.make_segment_labels(hb.T, hb.N_SEG)
    sig2 = np.exp(args.scale * np.log(mrs.sigma2_for(key, hb.N_SEG, M, rng))).astype(np.float32)
    gains = np.sqrt(sig2)
    s_tr, s_te = z_tr * gains[labels], z_te * gains[labels]
    W = gens.W(M)
    xc_tr, xc_te = fas.mix(s_tr, W), fas.mix(s_te, W)
    npow = float(np.mean(xc_tr ** 2)) * 10 ** (-SNR / 10.0)
    x_tr = hb.add_noise_pow(xc_tr, npow, "gaussian", rng); x_te = hb.add_noise_pow(xc_te, npow, "gaussian", np.random.default_rng(seed + hb.TEST_OFFSET))
    return s_tr, s_te, x_tr, x_te, labels, sig2

conds = [("alpha", a) for a in args.alphas] + [("rank", r) for r in args.ranks]
path = f"{OUT}/results.npy"; res = np.load(path, allow_pickle=True).item() if os.path.exists(path) else {}
t0 = time.time()
for key in conds:
    for seed in args.seeds:
        k = (key, seed)
        if k in res: continue
        cp = f"{OUT}/cells/{key[0]}{key[1]}_seed{seed}.npz"
        if os.path.exists(cp):
            c = dict(np.load(cp, allow_pickle=True))
        else:
            torch.manual_seed(seed)
            s_tr, s_te, x_tr, x_te, labels, sig2 = make_cell(key, seed)
            c, _, _ = hb.run_methods(s_tr, s_te, x_tr, x_te, labels, args.device)
            torch.manual_seed(seed); c["iVAEfix_tr"], c["iVAEfix_te"] = fit_ivae_fixed(x_tr, x_te, labels, M, args.device)
            c["sig2"] = sig2; np.savez(cp, **c)
        ho, _ = hb.score_cell(c)
        ho["iVAEfix"] = hb.strong_heldout(c["z_tr"], c["iVAEfix_tr"], c["z_te"], c["iVAEfix_te"])
        ho["TCL_s2"] = hb.weak_heldout(c["z_tr"] ** 2, c["TCL_tr"], c["z_te"] ** 2, c["TCL_te"])
        st = rep.modulation_stats(c["x_tr"].astype(np.float64), c["labels"], np.random.default_rng(seed))
        ho.update({f"obs_{a}": b for a, b in st.items()})
        L = np.log(c["sig2"]); L = L - L.mean(0); ho["rankL"] = int(np.linalg.matrix_rank(L, tol=1e-6)); sv = np.linalg.svd(L, compute_uv=False); ho["condL"] = float(sv[0] / max(sv[-1], 1e-12))
        # held-out nulls (time shift) for the two scores
        zs_tr, zs_te = np.roll(c["z_tr"], hb.T // 3, 0), np.roll(c["z_te"], hb.T // 3, 0)
        ho["null_strong"] = hb.strong_heldout(c["z_tr"], zs_tr, c["z_te"], zs_te); ho["null_weak"] = hb.weak_heldout(np.abs(c["z_tr"]), zs_tr, np.abs(c["z_te"]), zs_te)
        res[k] = ho; np.save(path, res)
    g = lambda q: np.nanmean([res[(key, s)][q] for s in args.seeds])
    print(f"{key[0]}={key[1]:<5}: pc1_share {g('obs_pc1_share'):.2f} rankL {g('rankL'):.0f} | PCA {g('PCA'):.2f} FastICA {g('FastICA'):.2f} TCL|s| {g('TCL'):.2f} TCLs2 {g('TCL_s2'):.2f} iVAE {g('iVAE'):.2f} iVAEfix {g('iVAEfix'):.2f} | null {g('null_strong'):.2f}/{g('null_weak'):.2f}  [{time.time()-t0:.0f}s]", flush=True)
lines = ["# D2: modulation-diversity axis, held-out, mean over seeds", "| cond | one-pattern share (obs) | rank L | PCA | FastICA | TCL vs abs s | TCL vs s^2 | iVAE shipped | iVAE fixed-scale | null strong/weak |", "|---|---|---|---|---|---|---|---|---|---|"]
for key in conds:
    g = lambda q: np.nanmean([res[(key, s)][q] for s in args.seeds]); sd = lambda q: np.nanstd([res[(key, s)][q] for s in args.seeds])
    lines.append(f"| {key[0]}={key[1]} | {g('obs_pc1_share'):.2f} +- {sd('obs_pc1_share'):.2f} | {g('rankL'):.0f} | {g('PCA'):.2f} | {g('FastICA'):.2f} | {g('TCL'):.2f} | {g('TCL_s2'):.2f} | {g('iVAE'):.2f} | {g('iVAEfix'):.2f} | {g('null_strong'):.2f}/{g('null_weak'):.2f} |")
open(f"{OUT}/summary.md", "w").write("\n".join(lines) + "\n"); print("\n".join(lines))
