"""Window continuous EEG recordings (HBN / TUEG) into fixed-length trials for
shPLRNN generator training, mirroring the (n_trials, T, C) format of
prepare_bci_data.py's data.pt.

Input npy layout: each file is (C, L) float32 = channels x time (continuous).
Output: data.pt of shape (N, win_len, C), globally standardized (single global
mean/std, preserving relative channel amplitudes as in the paper's protocol).

Example:
  python scripts/prepare_generator_data.py \
      --npy_dir <HBN_NPY_DIR> \
      --out data/hbn/data.pt --win_len 500 --windows_per_file 10 --max_windows 2000
"""
import os
import glob
import argparse
import numpy as np
import torch


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--npy_dir", required=True, help="dir of (C, L) npy recordings")
    ap.add_argument("--out", required=True, help="output .pt path")
    ap.add_argument("--win_len", type=int, default=500, help="samples per window")
    ap.add_argument("--windows_per_file", type=int, default=10,
                    help="max non-overlapping windows taken per recording (for diversity)")
    ap.add_argument("--max_windows", type=int, default=2000, help="total window cap")
    ap.add_argument("--max_files", type=int, default=None, help="cap files scanned (smoke test)")
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    rng = np.random.default_rng(args.seed)
    files = sorted(glob.glob(os.path.join(args.npy_dir, "*.npy")))
    if args.max_files:
        files = files[: args.max_files]
    print(f"{len(files)} recordings in {args.npy_dir}")

    windows = []
    for f in files:
        if len(windows) >= args.max_windows:
            break
        a = np.load(f, mmap_mode="r")          # (C, L)
        if a.ndim != 2:
            continue
        C, L = a.shape
        n_full = L // args.win_len
        if n_full == 0:
            continue
        take = min(n_full, args.windows_per_file, args.max_windows - len(windows))
        # evenly spaced window starts across the recording
        starts = np.linspace(0, (n_full - 1) * args.win_len, take).astype(int)
        for s in starts:
            w = np.asarray(a[:, s: s + args.win_len]).T   # (win_len, C)
            windows.append(w.astype(np.float32))

    X = np.stack(windows, axis=0)              # (N, win_len, C)
    mu, sd = float(X.mean()), float(X.std())
    X = (X - mu) / (sd + 1e-8)                 # single global scale (paper protocol)
    X_t = torch.from_numpy(X)

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    torch.save(X_t, args.out)
    print(f"Saved {args.out}  shape={tuple(X_t.shape)}  dtype={X_t.dtype}")
    print(f"  global mean/std used: {mu:.4g} / {sd:.4g}")
    print(f"  finite: {bool(torch.isfinite(X_t).all())}  per-channel std range: "
          f"{X_t.std(dim=(0,1)).min():.3f}..{X_t.std(dim=(0,1)).max():.3f}")


if __name__ == "__main__":
    main()
