"""D8: fill the panels.  PCL and fixed-scale iVAE (standardised x, beta 0.1) on the
M = 32 learned-W cells (results/autoresearch_oct6/mixing_cells), and PCL on the
modulation-axis cells (D2).  Writes results/autoresearch_oct7/fill/{m32,modulation_pcl}.npy."""
import os, sys, glob, time, warnings, numpy as np, torch
warnings.filterwarnings("ignore")
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE); sys.path.insert(0, os.path.dirname(HERE))
import shplrnn_axis_heldout as hb
from ar_pcl import fit_pcl
import failure_axis_sweep as fas

def fit_ivae_fixed(x_tr, x_te, labels, n, device, beta=0.1, epochs=200):   # same as ar_modulation_axis.fit_ivae_fixed (that module is not import-safe)
    mu, sd = x_tr.mean(0), x_tr.std(0) + 1e-8
    xs_tr, xs_te = ((x_tr - mu) / sd).astype(np.float32), ((x_te - mu) / sd).astype(np.float32)
    n_seg = int(labels.max()) + 1
    X = torch.tensor(xs_tr); u = torch.zeros(len(x_tr), n_seg); u[torch.arange(len(x_tr)), torch.tensor(labels)] = 1.0
    model = fas.iVAENet(x_tr.shape[1], n, n_seg, 64).to(device); opt = torch.optim.Adam(model.parameters(), lr=1e-3)
    for _ in range(epochs):
        perm = torch.randperm(len(X))
        for i in range(0, len(X), 256):
            idx = perm[i:i + 256]; x_hat, z, z_mu, z_lv, p_mu, p_lv = model(X[idx], u[idx])
            kl = -0.5 * (1 + z_lv - p_lv - (z_mu - p_mu).pow(2) / p_lv.exp() - z_lv.exp() / p_lv.exp()).sum(-1)
            loss = ((x_hat - X[idx]) ** 2).mean() + beta * kl.mean(); opt.zero_grad(); loss.backward(); opt.step()
    model.eval()
    with torch.no_grad():
        return model(X, u)[2].numpy(), model(torch.tensor(xs_te), u)[2].numpy()
torch.set_num_threads(2)
if __name__ == "__main__":
    OUT = "results/autoresearch_oct7/fill"; os.makedirs(OUT, exist_ok=True); t0 = time.time()
    m32 = {}
    for seed in hb.SEEDS:
        c = dict(np.load(f"results/autoresearch_oct6/mixing_cells/learned_M32_seed{seed}.npz")); z_tr, z_te, x_tr, x_te, lab = c["z_tr"], c["z_te"], c["x_tr"], c["x_te"], c["labels"]
        torch.manual_seed(seed); h_tr, h_te, _ = fit_pcl(x_tr, x_te, 32, "cpu", 200)
        torch.manual_seed(seed); v_tr, v_te = fit_ivae_fixed(x_tr, x_te, lab, 32, "cpu")
        m32[seed] = dict(PCL=hb.strong_heldout(z_tr, h_tr, z_te, h_te), iVAEfix=hb.strong_heldout(z_tr, v_tr, z_te, v_te))
        print(f"M32 seed {seed}: PCL {m32[seed]['PCL']:.2f} iVAEfix {m32[seed]['iVAEfix']:.2f} [{time.time()-t0:.0f}s]", flush=True)
        np.save(f"{OUT}/m32.npy", m32)
    mod = {}
    for f in sorted(glob.glob("results/autoresearch_oct7/modulation_axis/cells/*.npz")):
        name = os.path.basename(f)[:-4]; cond, seed = name.rsplit("_seed", 1); kind = "alpha" if cond.startswith("alpha") else "rank"; val = float(cond[len(kind):]) if kind == "alpha" else int(cond[len(kind):])
        c = dict(np.load(f, allow_pickle=True)); torch.manual_seed(int(seed)); h_tr, h_te, _ = fit_pcl(c["x_tr"], c["x_te"], 4, "cpu", 200)
        mod[((kind, val), int(seed))] = hb.strong_heldout(c["z_tr"], h_tr, c["z_te"], h_te); np.save(f"{OUT}/modulation_pcl.npy", mod)
    for k in sorted({k[0] for k in mod}, key=str): print(f"{k}: PCL {np.mean([mod[(k, s)] for s in hb.SEEDS if (k, s) in mod]):.2f}")
