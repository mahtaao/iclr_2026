"""Appendix figure: is the generator's synthetic EEG EEG-like?

(a) normalised power spectra of real BCI IV-2a EEG (per subject) and of the
    generator's synthetic EEG Wz (per seed) for the paper's recipe and for the
    retrained recipe (generalised-teacher-forcing floor 0.2, hidden size 64);
(b) the corresponding latent spectra; (c) channel correlations, real against
    generated (one point per channel pair).  Thin lines: individual subjects or
    seeds; thick: median.
"""
import os, sys, numpy as np, torch
from scipy.signal import welch
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE); sys.path.insert(0, os.path.dirname(HERE)); sys.path.insert(0, os.path.dirname(os.path.dirname(HERE)))
from style import *
import shplrnn_axis_heldout as hb

FS = 250
X = torch.load("data/bci/data.pt").numpy(); subj = torch.load("data/bci/subjects.pt").numpy()
gens = hb.Generators("cpu", "/tmp"); W = gens.W(4)
hb.GEN_DIR = "trained_models/bci/bci/g_tf02_h64/001"; gens2 = hb.Generators("cpu", "/tmp"); gens2.GEN_DIR = hb.GEN_DIR
def psd(x):
    f, p = welch(x, fs=FS, nperseg=250, axis=0); p = p.mean(1); return f, p / p.sum()
def cov(x): c = np.corrcoef(x.T); return c[np.triu_indices(22, 1)]
CR, CP, CN = "#5a5a5a", C["TCL"], C["FastICA"]   # real, paper recipe, retrained recipe

fig, (a, b) = plt.subplots(1, 2, figsize=(4.6, 1.85), gridspec_kw=dict(wspace=0.38, left=0.11, right=0.99, top=0.92, bottom=0.22))
real_p, real_c = [], []
for s in np.unique(subj):
    xs = X[subj == s]; f, p = psd(np.concatenate(xs)); real_p.append(p); real_c.append(np.mean([cov(x) for x in xs[::20]], 0))
    a.plot(f, 10 * np.log10(p), color=CR, lw=0.5, alpha=0.35)
gen_p, gen_c, lat_p = [], [], []
for seed in range(5):
    z, _ = gens.pair(4, seed); x = z @ W; f, p = psd(x); gen_p.append(p); gen_c.append(cov(x)); fz, pz = psd(z); lat_p.append(pz)
    a.plot(f, 10 * np.log10(p), color=CP, lw=0.5, alpha=0.35); b.plot(fz, 10 * np.log10(pz), color=CP, lw=0.5, alpha=0.35)
gen2_p, gen2_c, lat2_p = [], [], []
for seed in range(5):
    z2, _ = gens2.pair(4, seed); x2 = z2 @ gens2.W(4); f, p = psd(x2); gen2_p.append(p); gen2_c.append(cov(x2)); fz, pz = psd(z2); lat2_p.append(pz)
    a.plot(f, 10 * np.log10(p), color=CN, lw=0.5, alpha=0.35); b.plot(fz, 10 * np.log10(pz), color=CN, lw=0.5, alpha=0.35)
for ps, col, lab in ((real_p, CR, "real EEG, 9 subjects"), (gen_p, CP, "generator, our recipe"), (gen2_p, CN, "generator, retrained recipe")):
    a.plot(f, 10 * np.log10(np.median(ps, 0)), color=col, lw=1.3, label=lab)
for ps, col in ((lat_p, CP), (lat2_p, CN)):
    b.plot(fz, 10 * np.log10(np.median(ps, 0)), color=col, lw=1.3)
for ax in (a, b):
    ax.set_xlim(0, 60); ax.set_xticks([0, 20, 40, 60]); ax.set_xlabel("frequency (Hz)"); tidy(ax)
a.set_ylabel("EEG power (dB, normalised)"); b.set_ylabel("latent power (dB, normalised)")
a.legend(loc="lower left", handlelength=1.5)
for ax, l in zip((a, b), "ab"): panel(ax, l)
save(fig, "figA_generator_realism")
