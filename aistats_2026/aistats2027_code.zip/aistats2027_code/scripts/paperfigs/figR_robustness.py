"""Appendix figure: robustness of the benchmark (ar_night E10-E14 and E11).

(a) per-segment demeaning restores TCL on the 1/f axis (solid: unfiltered,
    dashed: demeaned), the other methods are unchanged;
(b) TCL against trajectory length T at the stressed cells (20 segments; hollow:
    320 segments at T = 32000): the M-vs-D failure is a sample-size failure, the
    assumption failures are not;
(c) a nuisance component at -10...+10 dB relative to the signal (solid:
    segment-modulated, dashed: stationary);
(d) learned mixing against a sphere-model leadfield, one point per cell.
Means over 5 seeds, error bars bootstrap 95% CI.
"""
import os, sys, glob, numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from style import *

ROOT = "results/ar_night"; METHODS = ["PCA", "FastICA", "TCL", "iVAE"]; S5 = range(5)
ld = lambda p: np.load(p, allow_pickle=True).item() if os.path.exists(p) else {}
NULLV = ld("results/shplrnn_axis_heldout/null_levels.npy")

fig, axes = plt.subplots(2, 2, figsize=(COL * 1.6, 3.9), gridspec_kw=dict(hspace=0.45, wspace=0.42, left=0.10, right=0.99, top=0.90, bottom=0.09))
(a, b), (c, d) = axes

# (a) preprocessing
hp = ld(f"{ROOT}/highpass/segdemean.npy"); SNRS = [30, 15, 10, 5, 0]; x = np.arange(5, dtype=float)
a.fill_between(x, 0, [max(v[2] for v in NULLV["1f_snr"][s].values()) for s in SNRS], color=NULL, lw=0, zorder=0)
for m in METHODS:
    for key, ls in (("base", "-"), ("filtered", "--")):
        series(a, x, [[hp[("1f_snr", s, sd)][key][m] for sd in S5 if ("1f_snr", s, sd) in hp] for s in SNRS], C[m], MK[m], ls=ls)
a.set_xticks(x); a.set_xticklabels([str(s) for s in SNRS]); a.set_xlim(-0.3, 4.3); a.set_xlabel("SNR (dB)"); a.set_ylabel("held-out recovery"); ylim01(a)
a.legend(handles=[h_line(INK, None, "-", "unfiltered"), h_line(INK, None, "--", "per-segment demeaned")], loc="lower left", handlelength=1.8)

# (b) data quantity, TCL only: source-count cells in the TCL hue, failure cells in greys
dq = {}
for fn in glob.glob(f"{ROOT}/data_quantity/T*_S*/seed*/scores.npy"):
    setting = fn.split("/")[-3]
    for k, v in np.load(fn, allow_pickle=True).item().items(): dq.setdefault((setting, k[0], str(k[1])), []).append(v["heldout"]["TCL"])
CELLS = [("m_vs_d", "4", "$M$ = 4", "#EDB33A"), ("m_vs_d", "16", "$M$ = 16", "#C98700"), ("m_vs_d", "22", "$M$ = 22", "#8A5E00"),
         ("1f_snr", "5", "1/f, 5 dB", "#b5b5b5"), ("ns", "confounder_aligned", "shared gain", "#7a7a7a"), ("ns", "stationary", "stationary", "#3a3a3a")]
TS = [2000, 8000, 32000]
ends = []
for axn, cfg, lab, col in CELLS:
    v = [dq.get((f"T{T}_S20", axn, cfg), []) for T in TS]
    series(b, TS, v, col, MK["TCL"])
    v320 = dq.get(("T32000_S320", axn, cfg), [])
    if v320: b.plot([32000 * 1.5], [np.mean(v320)], ls="none", marker=MK["TCL"], ms=3.4, mfc="white", mec=col, mew=0.8, zorder=4)
    ends.append([np.mean(v320) if v320 else np.mean(v[-1]), lab, col])
ends.sort(key=lambda t: t[0])                      # direct labels at the line ends, pushed apart by a minimum gap
for k in range(1, len(ends)): ends[k][0] = max(ends[k][0], ends[k - 1][0] + 0.065)
for k in range(len(ends) - 1, -1, -1): ends[k][0] = min(ends[k][0], 0.98 - 0.065 * (len(ends) - 1 - k))
for y, lab, col in ends: b.annotate(lab, (32000 * 1.5, y), xytext=(5, 0), textcoords="offset points", fontsize=6, color=col, va="center", ha="left")
b.set_xscale("log"); b.set_xticks(TS); b.set_xticklabels(["2k", "8k", "32k"]); b.set_xlim(1500, 2.6e5); b.minorticks_off()
b.set_xlabel("samples $T$ (20 segments)"); b.set_ylabel("TCL held-out recovery"); ylim01(b)

# (c) nuisance component
nu = ld(f"{ROOT}/nuisance/scores.npy"); ratios = sorted({k[1] for k in nu}); x = np.arange(len(ratios) + 1, dtype=float)
for m in METHODS:
    base = [v["base"][m] for k, v in nu.items() if k[0] == "modulated" and k[1] == ratios[0]]
    for mode, ls in (("modulated", "-"), ("stationary", "--")):
        series(c, x, [base] + [[nu[(mode, r, s)]["score"][m] for s in S5 if (mode, r, s) in nu] for r in ratios], C[m], MK[m], ls=ls)
c.set_xticks(x); c.set_xticklabels(["none"] + [f"{r:+.0f}".replace("-", "−") for r in ratios]); c.set_xlim(-0.3, len(ratios) + 0.3)
c.set_xlabel("nuisance power vs signal (dB)"); c.set_ylabel("held-out recovery"); ylim01(c)
c.legend(handles=[h_line(INK, None, "-", "modulated nuisance"), h_line(INK, None, "--", "stationary nuisance")], loc="lower left", handlelength=1.8)

# (d) leadfield
lf = {}
for fn in glob.glob(f"{ROOT}/leadfield/seed*/scores.npy"):
    for k, v in np.load(fn, allow_pickle=True).item().items():
        for m in METHODS: lf.setdefault((k[0], str(k[1]), m), []).append((v["learned"]["heldout"][m], v["leadfield"]["heldout"][m]))
d.plot([0, 1], [0, 1], color=GRID, lw=0.6, ls="--", zorder=0)
for (axn, cfg, m), pairs in lf.items():
    p = np.nanmean(np.array(pairs, float), 0)
    d.scatter(p[0], p[1], color=C[m], marker=MK[m], s=12, lw=0.4, edgecolors="white", zorder=3)
d.set_xlim(0, 1); d.set_ylim(0, 1); d.set_xticks([0, 0.5, 1]); d.set_yticks([0, 0.5, 1]); d.set_aspect("equal")
d.set_xlabel("recovery, learned mixing $W$"); d.set_ylabel("recovery, sphere-model leadfield")

fig.legend(handles=[h_line(C[m], MK[m], label=m) for m in METHODS] + [h_patch(NULL, "chance band (95th pct.)"), h_marker(INK2, MK["TCL"], "TCL, 320 segments", hollow=True)],
           loc="upper center", bbox_to_anchor=(0.5, 1.0), ncol=6, handlelength=1.6, handletextpad=0.4, columnspacing=1.0)
for ax, l in zip((a, b, c, d), "abcd"): tidy(ax); panel(ax, l)
save(fig, "figR_robustness")
