#!/usr/bin/env bash
# Rebuild every paper figure into results/figures_paper (PDF + PNG preview).
set -euo pipefail
cd "$(dirname "$0")/../.."
export PATH="$PWD/.venv/bin:$PATH"
export FIGDIR="${FIGDIR:-results/figures_paper}"
mkdir -p "$FIGDIR"
python scripts/paperfigs/fig1_axes.py
REALISTIC=1 python scripts/paperfigs/fig1_axes.py
python scripts/paperfigs/fig2_diagnostics.py
python scripts/paperfigs/fig3_real_eeg.py
SINGLE=1 python scripts/paperfigs/fig3_real_eeg.py
python scripts/paperfigs/figR_robustness.py
python scripts/paperfigs/figA_realism.py
( cd "$FIGDIR" && pdflatex -interaction=nonstopmode -halt-on-error "$OLDPWD/scripts/paperfigs/fig0_concept.tex" > /dev/null \
  && rm -f fig0_concept.aux fig0_concept.log && pdftoppm -png -r 250 -singlefile fig0_concept.pdf fig0_concept && echo "saved $FIGDIR/fig0_concept.pdf" )
