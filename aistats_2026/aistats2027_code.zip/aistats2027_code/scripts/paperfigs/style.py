"""Shared style for the paper figures.

AISTATS two-column: text width 6.75 in (FULL), column width 3.25 in (COL).
Figures are drawn at the width they are printed, so every font size below is
the final size on the page: 7 pt body, 6.5 pt ticks and legends, 8 pt panel letters.
Font: Helvetica (sans), the common convention for ML conference figures; math
is set in the same face.  One colour and one marker per method in every figure
(Okabe-Ito); grey is reserved for references (PCA = subspace reference, chance
band, rotation reference).  Bootstrap 95% CIs are drawn as thin error bars.
"""
import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch

FULL, COL = 6.75, 3.25
plt.rcParams.update({
    "font.family": "Helvetica", "font.size": 7, "axes.labelsize": 7.5, "axes.titlesize": 7,
    "xtick.labelsize": 6.5, "ytick.labelsize": 6.5, "legend.fontsize": 6.5, "legend.title_fontsize": 6.5,
    "mathtext.fontset": "custom", "mathtext.rm": "Helvetica", "mathtext.it": "Helvetica:italic", "mathtext.bf": "Helvetica:bold",
    "pdf.fonttype": 42, "ps.fonttype": 42,
    "axes.spines.top": False, "axes.spines.right": False, "axes.linewidth": 0.5, "axes.edgecolor": "#333333",
    "xtick.color": "#333333", "ytick.color": "#333333", "axes.labelcolor": "#222222", "text.color": "#222222",
    "xtick.major.width": 0.5, "ytick.major.width": 0.5, "xtick.major.size": 2, "ytick.major.size": 2,
    "xtick.major.pad": 2, "ytick.major.pad": 2, "axes.labelpad": 2.5,
    "lines.linewidth": 1.0, "lines.markersize": 2.8,
    "legend.frameon": False, "legend.handlelength": 1.8, "legend.handletextpad": 0.5, "legend.columnspacing": 1.1,
    "legend.labelspacing": 0.3, "legend.borderpad": 0.2, "legend.borderaxespad": 0.3,
    "savefig.dpi": 300,
})

# Okabe-Ito; one colour and one marker per method across every figure of the paper
C = {"PCA": "#8a8a8a", "FastICA": "#0072B2", "TCL": "#E69F00", "iVAE": "#CC79A7", "PCL": "#009E73", "CEBRA": "#56B4E9", "CSP": "#111111"}
MK = {"PCA": "o", "FastICA": "s", "TCL": "^", "iVAE": "D", "PCL": "v", "CEBRA": "p", "CSP": "o"}
# stress axes (used only where points are coloured by axis)
AXC = {"1f_snr": "#D55E00", "nonlin": "#56B4E9", "coupling": "#009E73", "ns": "#CC79A7", "m_vs_d": "#0072B2"}
AXM = {"1f_snr": "o", "nonlin": "s", "coupling": "^", "ns": "D", "m_vs_d": "v"}
AXN = {"1f_snr": "1/f SNR", "nonlin": "nonlinearity", "coupling": "coupling", "ns": "nonstationarity", "m_vs_d": "sources vs channels"}
NULL, ROT, SPAN, INK, INK2, GRID = "#e3e3e3", "#555555", "#000000", "#222222", "#6a6a6a", "#d0d0d0"
ROT_LS = (0, (3, 2))
OUT = os.environ.get("FIGDIR", "results/figures_paper")


def boot_ci(v, n=2000, seed=0):
    v = np.asarray([x for x in v if x is not None and np.isfinite(x)], float)
    if len(v) == 0:
        return np.nan, np.nan, np.nan
    if len(v) == 1:
        return v[0], v[0], v[0]
    rng = np.random.default_rng(seed)
    m = rng.choice(v, (n, len(v))).mean(1)
    return float(v.mean()), float(np.percentile(m, 2.5)), float(np.percentile(m, 97.5))


def series(ax, x, vals, color, marker, ls="-", label=None, zorder=3, ms=2.8, lw=1.0, **kw):
    """Mean with bootstrap 95% CI as thin error bars; vals is a list (per x) of per-seed scores."""
    st = [boot_ci(v) for v in vals]
    m, lo, hi = map(np.array, zip(*st))
    ok = np.isfinite(m)
    if not ok.any():
        return None
    x = np.asarray(x, float)
    return ax.errorbar(x[ok], m[ok], yerr=[m[ok] - lo[ok], hi[ok] - m[ok]], color=color, marker=marker, ls=ls, lw=lw,
                       ms=ms, mew=0.5, mec="white", elinewidth=0.6, capsize=0, label=label, zorder=zorder, **kw)


def panel(ax, letter, dx=-1, dy=2, ha="right"):
    ax.annotate(f"({letter})", (0, 1), xycoords="axes fraction", xytext=(dx, dy), textcoords="offset points",
                ha=ha, va="bottom", fontsize=8, fontweight="bold", color=INK, annotation_clip=False)


def h_line(color, marker=None, ls="-", label="", lw=1.0, **kw):
    return Line2D([0], [0], color=color, marker=marker, ls=ls, lw=lw, ms=2.8, mew=0.5, mec="white", label=label, **kw)


def h_marker(color, marker, label, hollow=False, ms=3.2):
    return Line2D([0], [0], ls="none", marker=marker, ms=ms, mfc="white" if hollow else color, mec=color, mew=0.7, label=label)


def h_patch(color, label, alpha=1.0, edge=None):
    return Patch(facecolor=color, alpha=alpha, lw=0.4 if edge else 0, edgecolor=edge, label=label)


def ylim01(ax):
    ax.set_ylim(0, 1.02)
    ax.set_yticks([0, 0.5, 1])
    ax.set_yticklabels(["0", "0.5", "1"])


def tidy(ax):
    ax.tick_params(length=2, width=0.5)
    for s in ("left", "bottom"):
        ax.spines[s].set_linewidth(0.5)


def save(fig, name):
    os.makedirs(OUT, exist_ok=True)
    fig.savefig(f"{OUT}/{name}.pdf", bbox_inches="tight", pad_inches=0.01)
    fig.savefig(f"{OUT}/{name}.png", dpi=250, bbox_inches="tight", pad_inches=0.02)
    print("saved", f"{OUT}/{name}.pdf")
