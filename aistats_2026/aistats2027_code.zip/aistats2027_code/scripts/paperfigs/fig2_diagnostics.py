"""Figure 2: what a practitioner can compute without ground truth does not track recovery.

(a) Spearman correlation between each observational diagnostic of a fitted model
and its true held-out recovery, pooled over the 105 cells of Figure 1 and within
each stress axis.  (b)-(d) three of those diagnostics against true recovery, one
point per (axis, condition, seed) cell, coloured by axis: TCL's training segment
accuracy (anti-diagnostic), the iVAE ELBO (sign flips between axes), TCL's
run-to-run agreement (uninformative inside the nonstationarity axis).
"""
import os, sys, numpy as np
from scipy.stats import spearmanr
from matplotlib.colors import LinearSegmentedColormap
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from style import *

R = np.load("results/autoresearch_oct7/diagnostics/diagnostics.npy", allow_pickle=True).item(); KEYS = sorted(R, key=str)
AXES = ["1f_snr", "nonlin", "coupling", "ns", "m_vs_d"]
ROWS = [("TCL", "seg_acc_train", "segment acc. (train)"), ("TCL", "seg_acc_test", "segment acc. (test)"), ("TCL", "run2run", "run-to-run"),
        ("iVAE", "elbo", "ELBO (test)"), ("iVAE", "run2run", "run-to-run"),
        ("FastICA", "abs_kurtosis", "|kurtosis|"), ("FastICA", "run2run", "run-to-run"),
        ("PCA", "explained_share", "explained variance"), ("PCA", "splithalf", "split-half")]

def diag(k, m, d):
    v = R[k][m].get("nelbo_test", np.nan) if d == "elbo" else R[k][m].get(d, np.nan)
    return -v if d == "elbo" else v

def rho(m, d, axis=None):
    ks = [k for k in KEYS if axis is None or k[0] == axis]
    x = np.array([diag(k, m, d) for k in ks], float); y = np.array([R[k][m]["truth"] for k in ks], float); ok = np.isfinite(x) & np.isfinite(y)
    return spearmanr(x[ok], y[ok])[0] if ok.sum() > 3 else np.nan

M = np.array([[rho(m, d)] + [rho(m, d, a) for a in AXES] for m, d, _ in ROWS])

fig = plt.figure(figsize=(FULL, 2.3))
gs = fig.add_gridspec(1, 4, width_ratios=[1.45, 1, 1, 1], wspace=0.42, left=0.225, right=0.985, top=0.83, bottom=0.28)
ax = fig.add_subplot(gs[0])
cmap = LinearSegmentedColormap.from_list("div", ["#0072B2", "#ffffff", "#D55E00"])
ax.imshow(M, cmap=cmap, vmin=-1, vmax=1, aspect="auto", interpolation="nearest")
for r in range(M.shape[0]):
    for c in range(M.shape[1]):
        if np.isfinite(M[r, c]): ax.text(c, r, (f"{M[r, c]:+.2f}" if abs(M[r, c]) >= 0.005 else "0.00").replace("-", "−"), ha="center", va="center", fontsize=5.8, color=INK)
starts = [i for i in range(len(ROWS)) if i == 0 or ROWS[i][0] != ROWS[i - 1][0]]
for s in starts[1:]: ax.axhline(s - 0.5, color="white", lw=2.2)
ax.axvline(0.5, color="white", lw=2.2)
ax.set_xticks(range(6)); ax.set_xticklabels(["pooled", "1/f SNR", "nonlinearity", "coupling", "nonstationarity", "sources vs channels"], fontsize=6.3, rotation=35, ha="left", rotation_mode="anchor")
ax.xaxis.tick_top(); ax.tick_params(length=0, pad=1)
ax.set_yticks(range(len(ROWS))); ax.set_yticklabels([lab for _, _, lab in ROWS], fontsize=6.3)
for s, e in zip(starts, starts[1:] + [len(ROWS)]):
    ax.text(-0.80, (s + e - 1) / 2, ROWS[s][0], transform=ax.get_yaxis_transform(), ha="right", va="center", fontsize=6.8, fontweight="bold", color=INK)
for sp in ax.spines.values(): sp.set_visible(False)
fig.text(0.012, 0.955, "(a)", fontsize=8, fontweight="bold", color=INK, va="bottom")

EX = [("TCL", "seg_acc_train", "TCL segment acc. (train)", "b"), ("iVAE", "elbo", "iVAE ELBO (test)", "c"), ("TCL", "run2run", "TCL run-to-run", "d")]
for n, (m, d, xl, letter) in enumerate(EX):
    ax = fig.add_subplot(gs[n + 1])
    for a in AXES:
        ks = [k for k in KEYS if k[0] == a]
        ax.scatter([diag(k, m, d) for k in ks], [R[k][m]["truth"] for k in ks], s=7, color=AXC[a], alpha=0.8, lw=0, label=AXN[a], zorder=3)
    ax.set_title(f"$\\rho_s$ = {rho(m, d):+.2f}".replace("-", "−"), loc="right", fontsize=6.5, pad=2, color=INK2)
    ylim01(ax); tidy(ax); ax.set_xlabel(xl); panel(ax, letter)
    if d == "elbo":
        x = np.array([diag(k, m, d) for k in KEYS], float); ax.set_xscale("symlog", linthresh=10); ax.set_xlim(np.nanmin(x) * 1.1, 0)
        ax.set_xticks([-100, -10, 0]); ax.set_xticklabels(["−100", "−10", "0"])
    if n == 0: ax.set_ylabel("held-out recovery")
    if n == 1: ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.33), ncol=5, markerscale=1.6, handletextpad=0.1, columnspacing=1.0)
save(fig, "fig2_diagnostics")
