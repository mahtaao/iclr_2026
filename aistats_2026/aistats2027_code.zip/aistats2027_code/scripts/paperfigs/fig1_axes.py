"""Figure 1: held-out recovery along five EEG-relevant stress axes.

Two rows by score type: top, permutation MCC against the signed sources (PCA,
FastICA, fixed-scale iVAE, PCL) with the rotation reference (score of a method
that recovers the source subspace but not the sources); bottom, the linear-
invariant CCA-MCC against |s| (TCL, TCL with per-segment demeaning, CEBRA-Time).
Chance band in both rows.  Harder to the right in every panel.  Panel (d) is the
continuous modulation-diversity axis with the real-EEG range; panel (e) extends
to M = 32 > D.  Error bars: bootstrap 95% CI over seeds.

REALISTIC=1 draws the same figure for the EEG-like generators of D10 (5 seeds,
no demeaned TCL, no CEBRA, no M = 32, categorical nonstationarity panel).
"""
import os, sys, numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from style import *

REAL = os.environ.get("REALISTIC") == "1"
ld = lambda p: np.load(p, allow_pickle=True).item() if os.path.exists(p) else {}
R20 = ld("results/autoresearch_oct7/heldout_realistic/all_results.npy" if REAL else "results/ar_night/figures_heldout20/all_results.npy")
IVF, PCL, DEM = ld("results/ar_night/ivae_fix/beta0.1.npy"), ld("results/autoresearch_oct7/pcl/pcl.npy"), ld("results/ar_night/highpass/segdemean.npy")
MIX, MOD, F32, MODPCL = ld("results/autoresearch_oct6/mixing_control.npy"), ld("results/autoresearch_oct7/modulation_axis/results.npy"), ld("results/autoresearch_oct7/fill/m32.npy"), ld("results/autoresearch_oct7/fill/modulation_pcl.npy")
CEB = {} if REAL else ld("results/autoresearch_oct7/cebra/cebra.npy")
HD = "results/autoresearch_oct7/heldout_realistic" if REAL else "results/shplrnn_axis_heldout"
NULLV, ROTV = ld(f"{HD}/null_levels.npy"), ld(f"{HD}/rotation_reference.npy")
if REAL:
    PI = ld("results/autoresearch_oct7/heldout_realistic/pcl_ivaefix.npy")
    IVF = {k: {"score": v["iVAEfix"]} for k, v in PI.items()}; PCL = {k: {"perm_s": v["PCL"]} for k, v in PI.items()}
    DEM, MIX, MOD, F32, MODPCL = {}, {}, {}, {}, {}
S5 = range(5)
REAL_SPAN = (0.22, 0.76)   # one-pattern share of nine BCI IV-2a subjects, 1-40 Hz (results/real_eeg_placement)
ALPHAS = [1.0, 0.75, 0.5, 0.35, 0.2, 0.1, 0.0]

g_base = lambda m: (lambda ax, cfg: R20[ax][m][cfg])
g_key = lambda D, f: (lambda ax, cfg: [D[(ax, cfg, s)][f] for s in S5 if (ax, cfg, s) in D])
g_dem = lambda ax, cfg: [DEM[(ax, cfg, s)]["filtered"]["TCL"] for s in S5 if (ax, cfg, s) in DEM]
g_ceb = lambda f: (lambda ax, cfg: [CEB[(ax, cfg, s)][f] for s in range(3) if (ax, cfg, s) in CEB])
g_mod = lambda f: (lambda a: [MOD[(("alpha", a), s)][f] for s in S5 if (("alpha", a), s) in MOD])
g_modpcl = lambda a: [MODPCL[(("alpha", a), s)] for s in S5 if (("alpha", a), s) in MODPCL]
def m32(name):
    if name in ("PCA", "FastICA", "TCL"): return [MIX[("learned", 32, s)][name] for s in S5 if ("learned", 32, s) in MIX]
    if name in ("iVAEfix", "PCL"): return [F32[s][name] for s in F32]
    return []

# (label, method key for colour/marker, linestyle, getter(axis, cfg), M=32 key, modulation-axis getter)
ROW1 = [("PCA (subspace ref.)", "PCA", "-", g_base("PCA"), "PCA", g_mod("PCA")),
        ("FastICA", "FastICA", "-", g_base("FastICA"), "FastICA", g_mod("FastICA")),
        ("iVAE", "iVAE", "-", g_key(IVF, "score"), "iVAEfix", g_mod("iVAEfix")),
        ("PCL", "PCL", "-", g_key(PCL, "perm_s"), "PCL", g_modpcl)]
ROW2 = [("TCL", "TCL", "-", g_base("TCL"), "TCL", g_mod("TCL")),
        ("TCL, per-segment demeaned", "TCL", "--", g_dem, None, None),
        ("CEBRA-Time", "CEBRA", "-", g_ceb("time_cca_abs"), None, None)]
PANELS = [dict(key="1f_snr", xlabel="SNR (dB)", cfgs=[30, 15, 10, 5, 0], ticks=["30", "15", "10", "5", "0"]),
          dict(key="nonlin", xlabel="mixing", cfgs=["linear", "cube", "tanh"], ticks=["linear", "cube", "tanh"]),
          dict(key="coupling", xlabel="coupling $\\gamma$", cfgs=[0.0, 0.1, 0.3, 0.6, 0.9], ticks=["0", ".1", ".3", ".6", ".9"]),
          dict(key="ns", xlabel="modulation", cfgs=["source_aligned", "confounder_aligned", "stationary"], ticks=["source-\nspecific", "shared\ngain", "none"]) if REAL
          else dict(key="mod", xlabel="co-modulation fraction", cfgs=ALPHAS, ticks=None),
          dict(key="m_vs_d", xlabel="sources $M$ ($D$ = 22)", cfgs=[2, 4, 8, 16, 22] + ([] if REAL else [32]), ticks=["2", "4", "8", "16", "22"] + ([] if REAL else ["32"]))]

fig, axes = plt.subplots(2, 5, figsize=(FULL, 2.75), sharey=True, sharex="col",
                         gridspec_kw=dict(hspace=0.18, wspace=0.10, left=0.065, right=0.995, top=0.94, bottom=0.27))
for j, P in enumerate(PANELS):
    for i, row in enumerate((ROW1, ROW2)):
        ax = axes[i, j]
        if P["key"] == "mod":
            xs = np.array([np.mean(g_mod("obs_pc1_share")(a)) for a in ALPHAS]); order = np.argsort(xs)
            nul = np.array([np.mean(g_mod("null_strong" if i == 0 else "null_weak")(a)) for a in ALPHAS])
            ax.fill_between(xs[order], 0, nul[order], color=NULL, lw=0, zorder=0)
            ax.axvspan(*REAL_SPAN, color=SPAN, alpha=0.06, lw=0, zorder=0)
            if i == 0: ax.plot([xs.min(), xs.max()], [ROTV["ns"]["source_aligned"][0]] * 2, ls=ROT_LS, color=ROT, lw=0.7, zorder=1)
            for lab, m, ls, _, _, gm in row:
                if gm is None: continue
                vals = [gm(a) for a in ALPHAS]
                series(ax, xs[order], [vals[k] for k in order], C[m], MK[m], ls=ls)
            ax.set_xlim(0.36, 1.03); ax.set_xticks([0.4, 0.6, 0.8, 1.0]); ax.set_xticklabels(["0.4", "0.6", "0.8", "1"])
            continue
        key, cfgs = P["key"], P["cfgs"]; xs = np.arange(len(cfgs), dtype=float)
        nul = [max(v[2] for v in NULLV[key][c].values()) if c in NULLV[key] else np.nan for c in cfgs]
        if key == "m_vs_d" and not REAL: nul[-1] = nul[-2]
        ax.fill_between(xs, 0, nul, color=NULL, lw=0, zorder=0)
        if i == 0:
            rot = [ROTV[key][c][0] if c in ROTV[key] else np.nan for c in cfgs]
            ax.plot(xs, rot, ls=ROT_LS, color=ROT, lw=0.7, zorder=1)
        for lab, m, ls, get, k32, _ in row:
            vals = []
            for c in cfgs:
                if key == "m_vs_d" and c == 32: vals.append(m32(k32) if k32 else [])
                else:
                    try: vals.append(get(key, c))
                    except KeyError: vals.append([])
            series(ax, xs, vals, C[m], MK[m], ls=ls)
        ax.set_xticks(xs); ax.set_xticklabels(P["ticks"]); ax.set_xlim(-0.35, len(cfgs) - 0.65)
    for i in range(2):
        ylim01(axes[i, j]); tidy(axes[i, j])
    axes[1, j].set_xlabel(P["xlabel"])
    panel(axes[0, j], "abcde"[j])
axes[0, 0].set_ylabel("permutation MCC"); axes[1, 0].set_ylabel("CCA-MCC vs $|s|$")

H = [h_line(C[m], MK[m], ls, label=lab) for lab, m, ls, *_ in ROW1 + ROW2 if not (REAL and (lab.startswith("CEBRA") or "demeaned" in lab))]
H += [h_line(ROT, None, ROT_LS, label="rotation reference", lw=0.7), h_patch(NULL, "chance band (95th pct.)")]
if not REAL: H.append(h_patch("#f0f0f0", "real EEG range (9 subjects)", edge="#9a9a9a"))
fig.legend(handles=H, loc="lower center", bbox_to_anchor=(0.5, 0.0), ncol=5, handlelength=1.7, columnspacing=1.0, handletextpad=0.4)
save(fig, "fig1_axes_realistic" if REAL else "fig1_axes")
