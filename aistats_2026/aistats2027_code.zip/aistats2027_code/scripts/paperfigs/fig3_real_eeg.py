"""Figure 3: real scalp EEG against the benchmark.

(a) Held-out recovery against the magnitude of the segment-wise modulation (sd
    of the per-segment log-variance, dB; log axis) for the source-specific
    schedule (four methods) and for TCL under a single shared gain (dashed).
    Grey bands: the nine BCI IV-2a subjects' observed modulation magnitude when
    the recording is cut into 20, 200 or 2000 segments (2 min, 12 s, 1.2 s).
    Synthetic cells: results/autoresearch_oct7/modulation_scale (log-variance
    profiles scaled by 0.1, 0.25, 0.5) and modulation_axis (scale 1).
(b, c) Real BCI IV-2a, TCL components scored by the cue (decoding accuracy,
    run-to-run agreement) against TCL's segment length; the other methods do not
    use segments and are drawn as median reference lines.
    results/autoresearch_oct7/bci_cue (20 segments), bci_cue_seg/seg200, seg2000.

SINGLE=1 writes the one-pattern-share placement panel alone (fig3a_placement).
"""
import os, sys, numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from style import *

R = "results/autoresearch_oct7"; DB = 10 * np.log10(np.e); S5 = range(5)
ld = lambda p: np.load(p, allow_pickle=True).item()
SEGS = [20, 200, 2000]; SEG_LAB = ["2 min", "12 s", "1.2 s"]

# ---- real-EEG modulation magnitude per segment length (cached; recomputed from data/bci/A0*T.mat if the cache is absent)
MAG_CACHE = f"{R}/modulation_scale/realmag.npy"
def real_magnitude():
    if os.path.exists(MAG_CACHE): return ld(MAG_CACHE)
    import scipy.io as sio, warnings; warnings.filterwarnings("ignore")
    from scipy.signal import butter, sosfiltfilt
    from sklearn.decomposition import FastICA
    def real(sub, band=(1, 40)):
        runs = sio.loadmat(f"data/bci/A0{sub}T.mat", struct_as_record=False, squeeze_me=True)["data"]
        sos = butter(4, band, btype="band", fs=250, output="sos")
        return np.concatenate([sosfiltfilt(sos, r.X[:, :22] - r.X[:, :22].mean(0), axis=0) for r in runs if np.atleast_1d(r.trial).size > 0])
    def sd_db(x, n_seg):
        lab = np.minimum(np.arange(len(x)) * n_seg // len(x), n_seg - 1)
        L = 10 * np.log10(np.stack([np.mean(x[lab == k] ** 2, 0) for k in range(n_seg)])); return (L - L.mean(0)).std(), len(x) // n_seg
    rng = np.random.default_rng(0); out = {n: [] for n in SEGS}
    for s in range(1, 10):
        z = FastICA(4, random_state=0, max_iter=500).fit_transform(real(s))
        for n in SEGS:
            sd, npr = sd_db(z, n); floor = sd_db(rng.standard_normal((npr * n, 4)), n)[0]
            out[n].append(np.sqrt(max(sd ** 2 - floor ** 2, 0)))
    np.save(MAG_CACHE, out); return out

def magnitude_panel(ax):
    mag = real_magnitude()
    SC = [(0.1, f"{R}/modulation_scale/scale0.1"), (0.25, f"{R}/modulation_scale/scale0.25"), (0.5, f"{R}/modulation_scale/scale0.5"), (1.0, f"{R}/modulation_axis")]
    res = {sc: ld(f"{p}/results.npy") for sc, p in SC}; xs = np.array([sc * DB for sc, _ in SC])
    v = lambda sc, a, f: [res[sc][(("alpha", a), s)][f] for s in S5 if (("alpha", a), s) in res[sc]]
    null = np.mean([np.mean(v(sc, 1.0, "null_strong")) for sc, _ in SC]); ax.axhspan(0, null, color=NULL, lw=0, zorder=0)
    for n, shade, lab in zip(SEGS, ["#ececec", "#d6d6d6", "#bdbdbd"], SEG_LAB):
        ax.axvspan(min(mag[n]), max(mag[n]), color=shade, lw=0, zorder=0)
        ax.annotate(lab, (np.median(mag[n]), 1.0), xycoords=("data", "axes fraction"), xytext=(0, 2), textcoords="offset points", ha="center", va="bottom", fontsize=6, color=INK2)
    for m, f in [("PCA", "PCA"), ("FastICA", "FastICA"), ("iVAE", "iVAEfix"), ("TCL", "TCL")]:
        series(ax, xs, [v(sc, 1.0, f) for sc, _ in SC], C[m], MK[m])
    series(ax, xs, [v(sc, 0.0, "TCL") for sc, _ in SC], C["TCL"], MK["TCL"], ls="--")
    ax.set_xscale("log"); ax.set_xticks([0.5, 1, 2, 4]); ax.set_xticklabels(["0.5", "1", "2", "4"]); ax.minorticks_off(); ax.set_xlim(0.3, 5.2)
    ax.set_xlabel("modulation magnitude (dB)"); ax.set_ylabel("held-out recovery"); ylim01(ax); tidy(ax)
    ax.legend(handles=[h_line(C["TCL"], MK["TCL"], "--", "TCL, shared gain"), h_patch("#d6d6d6", "real EEG, by segment length", edge="#9a9a9a")],
              loc="lower right", handlelength=1.6)

B = {20: ld(f"{R}/bci_cue/per_subject.npy"), 200: ld(f"{R}/bci_cue_seg/seg200/per_subject.npy"), 2000: ld(f"{R}/bci_cue_seg/seg2000/per_subject.npy")}
SUBS = sorted({k[0] for k in B[20]}); rng = np.random.default_rng(0)
med = lambda n, m, M, f: np.median([B[n][(s, m, M)][f] for s in SUBS if (s, m, M) in B[n]])

def segment_panel(ax, field, ylabel):
    x = np.arange(3, dtype=float)
    for M, off, mfc, ls in ((4, -0.13, C["TCL"], "-"), (8, 0.13, "white", "--")):
        for i, n in enumerate(SEGS):
            vals = [B[n][(s, "TCL", M)][field] for s in SUBS]
            ax.plot(i + off + rng.uniform(-0.05, 0.05, len(vals)), vals, ls="none", marker="o", ms=2.4, mfc=mfc, mec=C["TCL"], mew=0.6, zorder=3)
        ax.plot(x + off, [med(n, "TCL", M, field) for n in SEGS], color=C["TCL"], lw=1.1, ls=ls, zorder=4)
    ax.set_xticks(x); ax.set_xticklabels([f"{l}\n({n})" for l, n in zip(SEG_LAB, SEGS)]); ax.set_xlim(-0.5, 2.5)
    ax.set_xlabel("TCL segment length (count)"); ax.set_ylabel(ylabel); tidy(ax)

def cue_panels(b, c):
    segment_panel(b, "decode_all", "cue decoding accuracy")
    csp = np.median([B[20][(s, "CSP")]["decode_all"] for s in SUBS if (s, "CSP") in B[20]])
    p95 = np.median([B[20][(s, m, 4)]["perm95"] for s in SUBS for m in ("PCA", "FastICA", "TCL", "PCL") if (s, m, 4) in B[20]])
    b.axhline(csp, color=C["CSP"], lw=0.7, ls=":", zorder=1); b.axhline(med(20, "PCL", 4, "decode_all"), color=C["PCL"], lw=0.7, ls=":", zorder=1)
    b.axhline(p95, color=INK2, lw=0.6, ls="--", zorder=1); b.set_ylim(0.1, 1.0); b.set_yticks([0.25, 0.5, 0.75, 1.0]); b.set_yticklabels(["0.25", "0.5", "0.75", "1"])
    segment_panel(c, "consistency", "run-to-run agreement"); ylim01(c)
    for m in ("PCL", "FastICA"): c.axhline(med(20, m, 4, "consistency"), color=C[m], lw=0.7, ls=":", zorder=1)

if os.environ.get("SINGLE") == "1":   # one-pattern-share placement, column width (companion of Table 2)
    MOD = ld(f"{R}/modulation_axis/results.npy"); MODPCL = ld(f"{R}/fill/modulation_pcl.npy") if os.path.exists(f"{R}/fill/modulation_pcl.npy") else {}
    REAL = {"1-40 Hz": [0.76, 0.39, 0.38, 0.47, 0.50, 0.32, 0.22, 0.44, 0.39], "8-30 Hz": [0.28, 0.39, 0.42, 0.38, 0.28, 0.32, 0.31, 0.35, 0.24]}
    ALPHAS = [1.0, 0.75, 0.5, 0.35, 0.2, 0.1, 0.0]
    def vals(key, f):
        if f == "PCL": return [MODPCL[(key, s)] for s in S5 if (key, s) in MODPCL]
        return [MOD[(key, s)][f] for s in S5 if (key, s) in MOD]
    fig, ax = plt.subplots(figsize=(COL, 2.3), gridspec_kw=dict(left=0.14, right=0.99, top=0.93, bottom=0.17))
    xs = np.array([np.mean(vals(("alpha", a), "obs_pc1_share")) for a in ALPHAS]); order = np.argsort(xs)
    ax.axhspan(0, np.mean([np.mean(vals(("alpha", a), "null_strong")) for a in ALPHAS]), color=NULL, lw=0, zorder=0)
    ax.axvspan(min(REAL["1-40 Hz"]), max(REAL["1-40 Hz"]), color=SPAN, alpha=0.06, lw=0, zorder=0)
    for m, f in [("PCA", "PCA"), ("FastICA", "FastICA"), ("iVAE", "iVAEfix"), ("PCL", "PCL"), ("TCL", "TCL")]:
        v = [vals(("alpha", a), f) for a in ALPHAS]; series(ax, xs[order], [v[k] for k in order], C[m], MK[m])
    for k, (band, v) in enumerate(REAL.items()):
        ax.plot(v, [0.045 + 0.045 * k] * len(v), ls="none", marker="|", ms=5, mew=0.9, color=INK if k == 0 else "#9a9a9a", zorder=5)
    ax.set_xlabel("co-modulation fraction"); ax.set_ylabel("held-out recovery"); ax.set_xlim(0.18, 1.02); ylim01(ax); tidy(ax)
    fig.legend(handles=[h_line(C[m], MK[m], label=m if m != "iVAE" else "iVAE") for m in ("PCA", "FastICA", "iVAE", "PCL", "TCL")], loc="upper center", bbox_to_anchor=(0.56, 1.0), ncol=5, columnspacing=0.9, handlelength=1.5)
    save(fig, "fig3a_placement")
else:
    fig = plt.figure(figsize=(FULL, 2.3))
    gs = fig.add_gridspec(1, 3, width_ratios=[1.55, 1, 1], wspace=0.42, left=0.065, right=0.995, top=0.78, bottom=0.22)
    a, b, c = (fig.add_subplot(gs[i]) for i in range(3))
    magnitude_panel(a); cue_panels(b, c)
    for ax, l in zip((a, b, c), "abc"): panel(ax, l, dy=9 if l == "a" else 2)
    H1 = [h_line(C[m], MK[m], label=lab) for m, lab in [("PCA", "PCA"), ("FastICA", "FastICA"), ("iVAE", "iVAE"), ("TCL", "TCL")]]
    H2 = [h_marker(C["TCL"], "o", "TCL, $M$ = 4", ms=2.6), h_marker(C["TCL"], "o", "TCL, $M$ = 8", hollow=True, ms=2.6),
          Line2D([0], [0], color=C["PCL"], lw=0.7, ls=":", label="PCL (median)"), Line2D([0], [0], color=C["FastICA"], lw=0.7, ls=":", label="FastICA (median)"),
          Line2D([0], [0], color=C["CSP"], lw=0.7, ls=":", label="CSP, supervised"), Line2D([0], [0], color=INK2, lw=0.6, ls="--", label="permutation 95th pct.")]
    L1 = fig.legend(handles=H1, loc="upper center", bbox_to_anchor=(0.5, 1.0), ncol=4, columnspacing=1.6, handlelength=1.8); fig.add_artist(L1)
    fig.legend(handles=H2, loc="upper center", bbox_to_anchor=(0.5, 0.925), ncol=6, columnspacing=1.2, handlelength=1.6)
    save(fig, "fig3_real_eeg")
