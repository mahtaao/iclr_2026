"""D4: real scalp EEG scored against the only reference that exists, the cue.

BCI IV-2a training sessions (A01T-A09T), 22 EEG channels, 250 Hz.  The 6
motor-imagery runs (48 trials each: left hand / right hand / feet / tongue, cue
at 2 s after trial onset) are split 3 + 3.  Preprocessing per run: 8-30 Hz
zero-phase Butterworth (order 4), downsample to 125 Hz, z-score with the fit-set
channel statistics.  Unsupervised methods fit on the continuous first 3 runs
(no labels): PCA, FastICA, TCL (20 contiguous segments of the fit set, the
paper's network, ~5000 Adam steps), PCL (same encoder, ~5000 steps), with
M in {4, 8} components.  Everything is then scored on the last 3 runs:
  decode_all   4-class LDA (shrinkage) on per-trial log-variance of all M
               components, window 0.5-4 s after the cue, 5-fold stratified CV,
               artifact trials removed (chance 0.25; label-permutation null, 20
               shuffles, reported as its 95th percentile)
  decode_best  the same with the single best component (CV-selected per fold)
  motor_share  for the component with the largest between-class F statistic,
               share of its Haufe pattern |cov(x, h_i)| on the central row
               C5 C3 C1 Cz C2 C4 C6 (7 of 22 electrodes; uniform = 0.32)
  consistency  the same method refit on the last 3 runs; agreement with the
               fit-set model on the last 3 runs (CCA-MCC for TCL/PCL,
               permutation MCC for PCA/FastICA): the observational diagnostic
  CSP          supervised one-vs-rest CSP (2 filters per class, fit inside each
               CV fold) + LDA on the same trials: the label-aware ceiling
Writes results/autoresearch_oct7/bci_cue/{per_subject.npy, summary.md}.
"""
import os, sys, time, argparse, warnings, numpy as np, torch, scipy.io
from scipy.signal import butter, sosfiltfilt, decimate
from scipy.stats import f_oneway
from sklearn.decomposition import PCA, FastICA
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis as LDA
from sklearn.model_selection import StratifiedKFold
warnings.filterwarnings("ignore")
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE); sys.path.insert(0, os.path.dirname(HERE))
import shplrnn_axis_heldout as hb, failure_axis_sweep as fas
from ar_pcl import PCLNet
torch.set_num_threads(2)
ap = argparse.ArgumentParser(); ap.add_argument("--subjects", nargs="*", default=[f"A{i:02d}" for i in range(1, 10)])
ap.add_argument("--Ms", type=int, nargs="*", default=[4, 8]); ap.add_argument("--steps", type=int, default=5000); ap.add_argument("--device", default="cpu")
ap.add_argument("--n_seg", type=int, default=20); ap.add_argument("--out", default="results/autoresearch_oct7/bci_cue")
args = ap.parse_args()
OUT = args.out; os.makedirs(OUT, exist_ok=True)
FS, DS, BAND, N_SEG = 250, 2, (8, 30), args.n_seg
CH = "Fz FC3 FC1 FCz FC2 FC4 C5 C3 C1 Cz C2 C4 C6 CP3 CP1 CPz CP2 CP4 P1 Pz P2 POz".split(); MOTOR = [CH.index(c) for c in "C5 C3 C1 Cz C2 C4 C6".split()]
WIN = (int(2.5 * FS / DS), int(6.0 * FS / DS))   # samples after trial onset at 125 Hz (cue at 2 s)

def load(subject):
    m = scipy.io.loadmat(f"data/bci/{subject}T.mat", squeeze_me=True, struct_as_record=False)
    sos = butter(4, BAND, btype="band", fs=FS, output="sos"); runs = []
    for r in m["data"]:
        if np.size(r.trial) == 0: continue
        x = sosfiltfilt(sos, r.X[:, :22].astype(np.float64), axis=0); x = decimate(x, DS, axis=0, zero_phase=True)
        onsets = (np.atleast_1d(r.trial).astype(int) // DS); y = np.atleast_1d(r.y).astype(int); art = np.atleast_1d(r.artifacts).astype(bool)
        runs.append((x.astype(np.float32), onsets[~art], y[~art]))
    return runs

def concat(runs):
    xs, ons, ys, off = [], [], [], 0
    for x, o, y in runs:
        xs.append(x); ons.append(o + off); ys.append(y); off += len(x)
    return np.concatenate(xs), np.concatenate(ons), np.concatenate(ys)

def steps_to_epochs(N): return max(1, int(np.ceil(args.steps * 256 / N)))

def fit_tcl(x, n):
    labels = fas.make_segment_labels(len(x), N_SEG)
    model, _, _, _ = hb.fit_tcl(x, x, labels, n, args.device, epochs=steps_to_epochs(len(x)))
    return lambda z: model(torch.tensor(z))[1].detach().numpy()

def fit_pcl(x, n):
    import ar_pcl
    X = torch.tensor(x); T = len(X); model = PCLNet(22, 64, n); opt = torch.optim.Adam(model.parameters(), lr=1e-3); lf = torch.nn.BCEWithLogitsLoss()
    g = torch.Generator().manual_seed(0)
    for _ in range(steps_to_epochs(T)):
        perm = torch.randperm(T - 1, generator=g) + 1
        for i in range(0, T - 1, 256):
            t = perm[i:i + 256]; ts = torch.randint(0, T, (len(t),), generator=g)
            h = model.feat(X[t]); lo = torch.cat([model.logit(h, model.feat(X[t - 1])), model.logit(h, model.feat(X[ts]))])
            loss = lf(lo, torch.cat([torch.ones(len(t)), torch.zeros(len(t))])); opt.zero_grad(); loss.backward(); opt.step()
    model.eval(); return lambda z: model.feat(torch.tensor(z)).detach().numpy()

def fit_method(name, x, n):
    if name == "PCA": p = PCA(n_components=n).fit(x); return p.transform
    if name == "FastICA": p = FastICA(n_components=n, max_iter=500, random_state=0).fit(x); return p.transform
    if name == "TCL": return fit_tcl(x, n)
    if name == "PCL": return fit_pcl(x, n)

def trial_feats(h, onsets):
    return np.stack([np.log(np.var(h[o + WIN[0]:o + WIN[1]], axis=0) + 1e-12) for o in onsets])

def cv_acc(F, y, rng=None, best_single=False):
    skf = StratifiedKFold(5, shuffle=True, random_state=0); acc = []
    for tr, te in skf.split(F, y):
        if best_single:
            inner = [np.mean([LDA(solver="lsqr", shrinkage="auto").fit(F[tr][a][:, [j]], y[tr][a]).score(F[tr][b][:, [j]], y[tr][b])
                              for a, b in StratifiedKFold(3, shuffle=True, random_state=1).split(F[tr], y[tr])]) for j in range(F.shape[1])]
            j = int(np.argmax(inner)); acc.append(LDA(solver="lsqr", shrinkage="auto").fit(F[tr][:, [j]], y[tr]).score(F[te][:, [j]], y[te]))
        else:
            acc.append(LDA(solver="lsqr", shrinkage="auto").fit(F[tr], y[tr]).score(F[te], y[te]))
    return float(np.mean(acc))

def csp_acc(x, onsets, y):
    trials = [x[o + WIN[0]:o + WIN[1]] for o in onsets]; covs = np.array([np.cov(t.T) for t in trials]); skf = StratifiedKFold(5, shuffle=True, random_state=0); acc = []
    for tr, te in skf.split(covs, y):
        W = []
        for c in np.unique(y):
            Cc = covs[tr][y[tr] == c].mean(0); Cr = covs[tr][y[tr] != c].mean(0)
            from scipy.linalg import eigh
            w, v = eigh(Cc, Cc + Cr); W.append(v[:, -2:])
        W = np.concatenate(W, 1); F = np.stack([np.log(np.var(t @ W, axis=0) + 1e-12) for t in trials])
        acc.append(LDA(solver="lsqr", shrinkage="auto").fit(F[tr], y[tr]).score(F[te], y[te]))
    return float(np.mean(acc))

path = f"{OUT}/per_subject.npy"; res = np.load(path, allow_pickle=True).item() if os.path.exists(path) else {}
t0 = time.time()
for subj in args.subjects:
    runs = load(subj); x_fit, _, _ = concat(runs[:3]); x_ev, on_ev, y_ev = concat(runs[3:])
    mu, sd = x_fit.mean(0), x_fit.std(0) + 1e-8; x_fit, x_ev = (x_fit - mu) / sd, (x_ev - mu) / sd
    if (subj, "CSP") not in res:
        res[(subj, "CSP")] = dict(decode_all=csp_acc(x_ev, on_ev, y_ev)); np.save(path, res)
    rng = np.random.default_rng(0)
    for M in args.Ms:
        for name in ["PCA", "FastICA", "TCL", "PCL"]:
            key = (subj, name, M)
            if key in res: continue
            torch.manual_seed(0); f = fit_method(name, x_fit, M); h_ev = f(x_ev)
            F = trial_feats(h_ev, on_ev)
            d = dict(decode_all=cv_acc(F, y_ev), decode_best=cv_acc(F, y_ev, best_single=True),
                     perm95=float(np.percentile([cv_acc(F, rng.permutation(y_ev)) for _ in range(20)], 95)))
            Fstat = np.array([f_oneway(*[F[y_ev == c, j] for c in np.unique(y_ev)])[0] for j in range(M)]); j = int(np.nanargmax(Fstat))
            pat = np.abs(np.cov(x_ev.T, h_ev[:, j])[:22, 22]); d["motor_share"] = float(pat[MOTOR].sum() / pat.sum()); d["F_best"] = float(Fstat[j])
            torch.manual_seed(1); f2 = fit_method(name, x_ev, M); h2 = f2(x_ev)
            d["consistency"] = hb.weak_heldout(h_ev, h2, h_ev, h2) if name in ("TCL", "PCL") else hb.strong_heldout(h_ev, h2, h_ev, h2)
            res[key] = d; np.save(path, res)
            print(f"{subj} {name:>7} M={M}: decode all {d['decode_all']:.2f} best {d['decode_best']:.2f} (perm95 {d['perm95']:.2f}) motor {d['motor_share']:.2f} consist {d['consistency']:.2f} | CSP {res[(subj,'CSP')]['decode_all']:.2f}  [{time.time()-t0:.0f}s]", flush=True)
lines = ["# D4: real BCI IV-2a, unsupervised components scored by the cue (median [min-max] over subjects)", "| method | M | decode all comps | decode best comp | perm null 95% | motor share of best comp (uniform 0.32) | run-to-run consistency |", "|---|---|---|---|---|---|---|"]
subs = sorted({k[0] for k in res})
q = lambda v: f"{np.median(v):.2f} [{np.min(v):.2f}-{np.max(v):.2f}]"
for M in args.Ms:
    for name in ["PCA", "FastICA", "TCL", "PCL"]:
        rows = [res[(s, name, M)] for s in subs if (s, name, M) in res]
        if rows: lines.append(f"| {name} | {M} | {q([r['decode_all'] for r in rows])} | {q([r['decode_best'] for r in rows])} | {q([r['perm95'] for r in rows])} | {q([r['motor_share'] for r in rows])} | {q([r['consistency'] for r in rows])} |")
lines.append(f"| CSP (supervised) | 8 | {q([res[(s,'CSP')]['decode_all'] for s in subs if (s,'CSP') in res])} | | | | |")
open(f"{OUT}/summary.md", "w").write("\n".join(lines) + "\n"); print("\n".join(lines))
