"""E12: does more data rescue the stressed cells?

Same held-out protocol, generators, methods and scoring as
shplrnn_axis_heldout, with longer trajectories (--T) and optionally more
segments (--n_seg); segment length is T / n_seg.  T and N_SEG are module
constants of shplrnn_axis_heldout and are overridden before the generators are
built.  TCL / iVAE keep 200 epochs, so gradient steps grow with T.  Default
cells: the clean M = 4 control and the stressed M = 16 / 22, 5 / 0 dB pink-noise,
stationary and global-scale (confounder_aligned) cells.  (T, n_seg) = (2000, 20)
is the main protocol and the paired baseline (regenerated here on the same
hardware).  Generators run on CPU; the networks on --device.

    python scripts/ar_data_quantity.py --T 32000 --n_seg 20 --seeds 0 --device cuda
"""
import os
import sys
import time
import argparse
import numpy as np
import torch

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.dirname(HERE))
import shplrnn_axis_heldout as hb

CELLS = ["m_vs_d:4", "m_vs_d:16", "m_vs_d:22", "1f_snr:5", "1f_snr:0", "ns:stationary", "ns:confounder_aligned"]


def parse_cell(s):
    ax, cfg = s.split(":")
    for cast in (int, float):
        try:
            return ax, cast(cfg)
        except ValueError:
            pass
    return ax, cfg


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--T", type=int, default=2000)
    ap.add_argument("--n_seg", type=int, default=20)
    ap.add_argument("--seeds", type=int, nargs="*", default=hb.SEEDS)
    ap.add_argument("--cells", nargs="*", default=CELLS)
    ap.add_argument("--out", default="results/ar_night/data_quantity")
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--limit", type=int, default=0)
    args = ap.parse_args()
    hb.T, hb.N_SEG = args.T, args.n_seg          # module globals read by make_pair / Generators.pair
    for seed in args.seeds:
        outdir = f"{args.out}/T{args.T}_S{args.n_seg}/seed{seed}"
        os.makedirs(outdir, exist_ok=True)
        path = f"{outdir}/scores.npy"
        res = np.load(path, allow_pickle=True).item() if os.path.exists(path) else {}
        gens = hb.Generators("cpu", outdir)
        n = 0
        for cs in args.cells:
            ax, cfg = parse_cell(cs)
            key = (ax, cfg, seed)
            if key in res or (args.limit and n >= args.limit):
                continue
            t1 = time.time()
            torch.manual_seed(seed)
            z_tr, z_te, x_tr, x_te, labels = hb.make_data(ax, cfg, seed, gens)
            assert len(z_tr) == args.T and int(labels.max()) + 1 == args.n_seg, (z_tr.shape, labels.max())
            c, _, _ = hb.run_methods(z_tr, z_te, x_tr, x_te, labels, args.device)
            ho, ins = hb.score_cell(c)
            res[key] = dict(heldout=ho, insample=ins, tcl_acc=float(c["TCL_acc_te"]), T=args.T,
                            n_seg=args.n_seg, seconds=time.time() - t1)
            np.save(path, res)
            n += 1
            print(f"T={args.T} S={args.n_seg} seed={seed} {ax}={cfg}: "
                  + " | ".join(f"{m}={ho[m]:.3f}({ins[m]:.2f})" for m in hb.METHODS)
                  + f"  TCL acc={res[key]['tcl_acc']:.2f}  [{time.time() - t1:.0f}s]", flush=True)


if __name__ == "__main__":
    main()
