"""Simulate a trained shPLRNN generator: free-run its latent dynamics and decode
to synthetic observations. Provides the shared primitive for (a) the generator-
driven sweep condition and (b) validate_generator.py.

The sources are the shPLRNN's own recurrent trajectories (what §4 of the paper
claims), not synthetic AR sources.

The deterministic free-run (process_noise=None) of the trained BCI generator
contracts to a fixed point within ~10-50 steps for every subject, so it carries
no source signal beyond a short transient. `calibrate_process_noise` returns the
per-dimension std of the generator's one-step prediction residual on its real
training EEG; passing that as `process_noise` simulates the stochastic PLRNN
z_t = f(z_{t-1}) + eps_t, eps_t ~ N(0, diag(sigma^2)), which is the standard
PLRNN generative model with a moment-matched noise scale.

Example:
  python scripts/simulate_generator.py \
      --model_path trained_models/bci/bci/linear_M4/001 \
      --data_path data/bci/data.pt --n_trials 20 --T 2000 --process_noise 1.0
"""
import os
import sys
import argparse
from argparse import Namespace
import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from main import get_dataset
from model import shallowPLRNN
from bptt import read_hypers, load_from_path


def load_generator(model_path, data_path, device="cpu"):
    """Reconstruct a trained shPLRNN from its checkpoint dir + hypers.txt."""
    args = Namespace(model_path=model_path, data_path=data_path, eval_data_path=None,
                     use_gpu=(device != "cpu"), device=device, finetune=False,
                     num_workers=0, compile=False, run=None, experiment=None, name=None)
    margs = read_hypers(args)
    margs.device = device
    margs.data_path = data_path
    margs.num_workers = 0
    margs.compile = False
    dataset = get_dataset(margs)
    model = shallowPLRNN(margs, dataset)
    load_from_path(model, args)
    model.eval()
    return model


@torch.no_grad()
def calibrate_process_noise(model, data_path, device="cpu", stride=50):
    """Per-latent-dimension std of the one-step prediction residual
    z_{t+1} - f_subject(z_t) on the real training data (z = encode(x)), median over
    every `stride`-th subject. Returns a (dz,) tensor."""
    X = torch.load(data_path).float().to(device)
    res = []
    for s in range(0, min(X.shape[0], model.num_subjects), stride):
        zg = model.encode(X[s])                                     # (T, dz)
        n = len(zg) - 1
        A, W1, W2, h1, h2 = model.hierarchisation_scheme.get_parameters(s)
        zp = model.latent_step(zg[:-1], A.expand(n, -1), W1.expand(n, -1, -1),
                               W2.expand(n, -1, -1), h1.expand(n, -1), h2.expand(n, -1))
        res.append((zg[1:] - zp).std(0))
    return torch.stack(res).median(0).values


@torch.no_grad()
def free_run_noisy(model, init, T, subject, sigma, gen):
    """Stochastic free-run from an observation frame `init` (dx,):
    z_t = f_subject(z_{t-1}) + sigma * eps_t. Returns latents (T, dz)."""
    A, W1, W2, h1, h2 = model.hierarchisation_scheme.get_parameters(subject)
    z = model.encode(init.unsqueeze(0))                             # (1, dz)
    out = torch.zeros(T, model.dz, device=z.device)
    out[0] = z[0]
    for t in range(1, T):
        eps = torch.randn(1, model.dz, generator=gen) * sigma.cpu()
        z = model.latent_step(z, A, W1, W2, h1, h2) + eps.to(z.device)
        out[t] = z[0]
    return out


@torch.no_grad()
def simulate(model, data_path, n_trials, T, device="cpu", seed=0,
             process_noise=None, burn_in=0):
    """Return z (n_trials, T, dz) latent sources and x (n_trials, T, dx) synthetic
    observations. Each trajectory is free-run from a real data frame as init.
    process_noise: (dz,) tensor of per-dimension noise std (see
    calibrate_process_noise), or None for the deterministic free-run.
    burn_in: leading steps simulated and discarded."""
    rng = np.random.default_rng(seed)
    gen = torch.Generator().manual_seed(seed)
    X = torch.load(data_path)                       # (N, Tdata, dx)
    N = X.shape[0]
    zs, xs = [], []
    for i in range(n_trials):
        subj = int(rng.integers(0, min(N, model.num_subjects)))
        init = X[subj, 0].to(device).float()        # (dx,) real observation frame
        if process_noise is None:
            traj = model.generate_free_trajectory(init, T + burn_in, subj)   # (1, T, dx)
            z = model.encode(traj[0])               # (T, dz) exact inverse of linear obs
        else:
            z = free_run_noisy(model, init, T + burn_in, subj, process_noise, gen)
        z = z[burn_in:]
        x = model.decode(z)                         # (T, dx) synthetic observations
        zs.append(z.cpu().numpy()); xs.append(x.cpu().numpy())
    return np.stack(zs), np.stack(xs)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--model_path", required=True)
    ap.add_argument("--data_path", required=True)
    ap.add_argument("--n_trials", type=int, default=20)
    ap.add_argument("--T", type=int, default=2000)
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--process_noise", type=float, default=0.0,
                    help="multiple of the calibrated one-step-residual std; 0 = deterministic")
    ap.add_argument("--burn_in", type=int, default=0)
    args = ap.parse_args()

    model = load_generator(args.model_path, args.data_path, args.device)
    print(f"Loaded generator: dz={model.dz} dx={model.dx} num_subjects={model.num_subjects}")
    sigma = None
    if args.process_noise > 0:
        sigma = calibrate_process_noise(model, args.data_path, args.device) * args.process_noise
        print(f"process-noise std per dim: {np.round(sigma.cpu().numpy(), 4)}")
    z, x = simulate(model, args.data_path, args.n_trials, args.T, args.device,
                    process_noise=sigma, burn_in=args.burn_in)
    print(f"z {z.shape}  x {x.shape}")
    print(f"z finite: {np.isfinite(z).all()}  x finite: {np.isfinite(x).all()}")
    print(f"z per-dim std: {np.round(z.std(axis=(0,1)), 3)}")
    print(f"z per-dim std, last 10% of each trial: {np.round(z[:, -z.shape[1]//10:].std(axis=(0,1)), 3)}")
    print(f"x std: {x.std():.4g}  (real data std ~1 after standardization)")
