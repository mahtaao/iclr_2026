"""E14: nonstationary nuisance component (REVIEW_TODO 1.3, independent-confounder cell).

Adds to the clean M = 4 cell (20 dB Gaussian noise, linear mixing; saved held-out
cells nonlin_linear_seed*) one signal that is not among the M sources: white
Gaussian with a segment-wise Exp(1) variance (the sources' own modulation law,
same 20 segments; "modulated") or constant variance ("stationary" control),
projected onto a random unit-norm spatial pattern over the 22 channels and
scaled to --ratios_db relative to the clean observed signal power.  Train and
test trajectories get independent nuisance draws with the same pattern and
segment gains.  Methods keep n = 4 components and are scored against the 4 true
sources exactly as in shplrnn_axis_heldout; the saved cell is the paired
baseline.  Also records each method's largest |corr| with the nuisance signal
on the test trajectory (leakage).

    python scripts/ar_nuisance.py --device cuda
"""
import os
import sys
import time
import argparse
import numpy as np
import torch

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.dirname(HERE))
import shplrnn_axis_heldout as hb


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cells", default="results/shplrnn_axis_heldout/cells")
    ap.add_argument("--out", default="results/ar_night/nuisance")
    ap.add_argument("--ratios_db", type=float, nargs="*", default=[-10, -5, 0, 5, 10])
    ap.add_argument("--seeds", type=int, nargs="*", default=hb.SEEDS)
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--limit", type=int, default=0)
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)
    path = f"{args.out}/scores.npy"
    res = np.load(path, allow_pickle=True).item() if os.path.exists(path) else {}
    t0, n = time.time(), 0
    for mode in ("modulated", "stationary"):
        for ratio in args.ratios_db:
            for seed in args.seeds:
                key = (mode, ratio, seed)
                if key in res or (args.limit and n >= args.limit):
                    continue
                c = dict(np.load(f"{args.cells}/nonlin_linear_seed{seed}.npz"))
                z_tr, z_te, x_tr, x_te, labels = c["z_tr"], c["z_te"], c["x_tr"], c["x_te"], c["labels"]
                T, D = x_tr.shape
                n_seg = int(labels.max()) + 1
                rng = np.random.default_rng(1_000_000 + seed)
                p = rng.standard_normal(D)
                p /= np.linalg.norm(p)
                gains = np.sqrt(rng.exponential(1.0, n_seg)) if mode == "modulated" else np.ones(n_seg)
                n_tr = rng.standard_normal(T) * gains[labels]
                n_te = rng.standard_normal(T) * gains[labels]
                a = np.sqrt(np.mean(x_tr ** 2) * 10 ** (ratio / 10.0) * D / np.mean(n_tr ** 2))
                xn_tr = (x_tr + a * n_tr[:, None] * p[None, :]).astype(np.float32)
                xn_te = (x_te + a * n_te[:, None] * p[None, :]).astype(np.float32)
                torch.manual_seed(seed)
                c2, _, _ = hb.run_methods(z_tr, z_te, xn_tr, xn_te, labels, args.device)
                ho, ins = hb.score_cell(c2)
                base, _ = hb.score_cell(c)
                leak = {m: float(np.nanmax(np.abs([np.corrcoef(c2[f"{m}_te"][:, i], n_te)[0, 1]
                                                   for i in range(c2[f"{m}_te"].shape[1])])))
                        for m in hb.METHODS}
                leak["TCL_abs"] = float(np.nanmax(np.abs([np.corrcoef(c2["TCL_te"][:, i], np.abs(n_te))[0, 1]
                                                          for i in range(c2["TCL_te"].shape[1])])))
                res[key] = dict(base=base, score=ho, insample=ins, leak=leak, tcl_acc_base=float(c["TCL_acc_te"]),
                                tcl_acc=float(c2["TCL_acc_te"]), nuisance_power_ratio_db=ratio)
                np.save(path, res)
                n += 1
            done = [res[(mode, ratio, s)] for s in args.seeds if (mode, ratio, s) in res]
            if done:
                print(f"{mode:>10} {ratio:+5.0f} dB: " + " | ".join(
                    f"{m} {np.nanmean([d['base'][m] for d in done]):.2f}->{np.nanmean([d['score'][m] for d in done]):.2f}"
                    f" (leak {np.nanmean([d['leak'][m] for d in done]):.2f})" for m in hb.METHODS)
                    + f"  TCL acc {np.mean([d['tcl_acc'] for d in done]):.2f}  [{time.time() - t0:.0f}s]", flush=True)
    lines = ["# E14: one nuisance component added to the clean M = 4 cell; held-out score baseline -> with nuisance "
             "(largest |corr| of any recovered component with the nuisance, TCL also vs |nuisance|)",
             "| nuisance | power vs signal (dB) | " + " | ".join(hb.METHODS) + " | TCL seg. acc |",
             "|---|---|" + "---|" * (len(hb.METHODS) + 1)]
    for mode in ("modulated", "stationary"):
        for ratio in args.ratios_db:
            done = [res[(mode, ratio, s)] for s in args.seeds if (mode, ratio, s) in res]
            if not done:
                continue
            cells = [f"{np.nanmean([d['base'][m] for d in done]):.2f} -> {np.nanmean([d['score'][m] for d in done]):.2f}"
                     f" (leak {np.nanmean([d['leak'][m] for d in done]):.2f}"
                     + (f", vs abs {np.nanmean([d['leak']['TCL_abs'] for d in done]):.2f}" if m == "TCL" else "") + ")"
                     for m in hb.METHODS]
            lines.append(f"| {mode} | {ratio:+.0f} | " + " | ".join(cells)
                         + f" | {np.mean([d['tcl_acc_base'] for d in done]):.2f} -> {np.mean([d['tcl_acc'] for d in done]):.2f} |")
    with open(f"{args.out}/nuisance.md", "w") as f:
        f.write("\n".join(lines) + "\n")


if __name__ == "__main__":
    main()
