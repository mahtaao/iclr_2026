"""shPLRNN-source failure-axis sweep with held-out evaluation.

Repairs two protocol issues of shplrnn_axis_sweep.py (results/shplrnn_axis/)
in one coordinated rerun, same condition grid (5 axes, 21 configurations),
same 5 seeds, same generators, same W per M, same methods and architectures:

1. Process-noise calibration over every trial of every subject.  The
   hierarchical model's "subjects" are the 2592 BCI IV-2a trials (9 subjects x
   288); the old call used stride=50 (52 trials).  Here stride=1; each real
   subject's median and the overall median actually used are saved to
   process_noise_calibration.json.
2. Held-out scoring.  For every cell two trajectories are drawn from the same
   generator, the same subject parameters and initial frame, the same
   segment-wise modulation gains, the same AR(1) coupling matrix, the same W,
   the same noise type and noise power (set from the training trajectory):
   only the process-noise and observation-noise realisations differ (test
   generator seed = seed + 50_000).  Every method is fit on the training
   trajectory and applied to the test trajectory: PCA / FastICA transform,
   TCL features, iVAE posterior mean.  Source standardisation uses training
   mean / std.  Scores on the test trajectory: for PCA / FastICA / iVAE the
   permutation (Hungarian on the training |corr| matrix) is fixed on the
   training pair and the mean |corr| is read on the test pair; for TCL the CCA
   is fit on the training pair (features vs |s|) and the mean |canonical
   correlation| is read on the test pair.  In-sample scores of the same fits
   (fas.mcc / fas.weak_mcc on the training pair) are kept in
   results_insample.npy for comparison.

Nulls are recomputed with the held-out procedure (independent trajectory and
circular time shift, 20 repeats, matching / CCA fit on a training pair, read
on a test pair) in the null_levels.npy format of plot_failure_sweep.py.  A
rotation reference (Haar-random orthogonal R, s = z R, same held-out
permutation MCC) is saved per condition in rotation_reference.npy; it is the
score of a method that recovers the source subspace but not the sources, and
is specific to each M and source correlation structure.

Every cell's data and method outputs (train and test) are saved to cells/ with
the TCL and iVAE state_dicts; --score_only rescans them.

Usage:
    python scripts/shplrnn_axis_heldout.py --device cpu
    python scripts/shplrnn_axis_heldout.py --axes nonlin --seeds 0      # smoke
    SWEEP_RESULTS=results/shplrnn_axis_heldout/all_results.npy \
    NULL_LEVELS=results/shplrnn_axis_heldout/null_levels.npy \
    FIG_OUTDIR=results/figures_shplrnn_heldout python scripts/plot_failure_sweep.py
"""
import os
import sys
import json
import time
import argparse
import numpy as np
import torch
import torch.nn as nn
from scipy.optimize import linear_sum_assignment
from sklearn.cross_decomposition import CCA
from sklearn.decomposition import PCA, FastICA

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
sys.path.insert(0, HERE)
import failure_axis_sweep as fas
import shplrnn_axis_sweep as sas
from simulate_generator import load_generator, free_run_noisy

METHODS, SEEDS, AXES = fas.METHODS, fas.SEEDS, sas.AXES
T, D, N_SEG, BURN_IN, DATA, GEN_DIR = sas.T, sas.D, sas.N_SEG, sas.BURN_IN, sas.DATA, sas.GEN_DIR
N_NULL, NULL_SEED, TEST_OFFSET = sas.N_NULL, sas.NULL_SEED, 50_000
SUBJECTS = "data/bci/subjects.pt"


# ── generators, calibrated over all trials, train/test trajectory pairs ──────

class Generators:
    def __init__(self, device, out):
        self.device, self.out = device, out
        self.models, self.sigmas, self.cache = {}, {}, {}
        self.X = torch.load(DATA).float()
        self.subj = torch.load(SUBJECTS).numpy() if os.path.exists(SUBJECTS) else None

    @torch.no_grad()
    def calibrate(self, model, M):
        """Per-trial one-step-residual std (n_trials, M); per-subject and overall medians."""
        res = []
        for s in range(min(self.X.shape[0], model.num_subjects)):
            zg = model.encode(self.X[s].to(self.device))
            n = len(zg) - 1
            A, W1, W2, h1, h2 = model.hierarchisation_scheme.get_parameters(s)
            zp = model.latent_step(zg[:-1], A.expand(n, -1), W1.expand(n, -1, -1),
                                   W2.expand(n, -1, -1), h1.expand(n, -1), h2.expand(n, -1))
            res.append((zg[1:] - zp).std(0).cpu().numpy())
        res = np.stack(res)
        sigma = np.median(res, 0)
        entry = dict(M=M, n_trials=int(len(res)), aggregate="median over all trials",
                     sigma=sigma.tolist(),
                     sigma_stride50_old=np.median(res[::50], 0).tolist())
        if self.subj is not None and len(self.subj) == len(res):
            entry["per_subject_median"] = {str(int(u)): np.median(res[self.subj == u], 0).tolist()
                                           for u in np.unique(self.subj)}
        path = f"{self.out}/process_noise_calibration.json"
        allc = json.load(open(path)) if os.path.exists(path) else {}
        allc[str(M)] = entry
        with open(path, "w") as f:
            json.dump(allc, f, indent=1)
        return torch.tensor(sigma, dtype=torch.float32)

    def load(self, M):
        if M not in self.models:
            model = load_generator(GEN_DIR.format(M=M), DATA, self.device)
            assert model.dz == M and model.dx == D, (model.dz, model.dx)
            self.models[M] = model
            self.sigmas[M] = self.calibrate(model, M)
            print(f"[gen M={M}] process-noise std (median over all trials): "
                  f"{np.round(self.sigmas[M].numpy(), 3)}")
        return self.models[M]

    def W(self, M):
        return self.load(M).obs_matrix.detach().cpu().numpy().astype(np.float32)

    def pair(self, M, seed):
        """(z_train, z_test): same subject, init frame and process noise std; the
        training trajectory is exactly shplrnn_axis_sweep's (generator seed = seed),
        the test trajectory uses generator seed + TEST_OFFSET.  Both standardised
        with the training mean / std."""
        key = (M, seed)
        if key not in self.cache:
            model = self.load(M)
            subj = int(np.random.default_rng(seed).integers(0, min(self.X.shape[0], model.num_subjects)))
            init = self.X[subj, 0].to(self.device)
            zs = []
            for gseed in (seed, seed + TEST_OFFSET):
                gen = torch.Generator().manual_seed(gseed)
                z = free_run_noisy(model, init, T + BURN_IN, subj, self.sigmas[M], gen)
                zs.append(z[BURN_IN:].cpu().numpy().astype(np.float64))
            mu, sd = zs[0].mean(0), zs[0].std(0)
            self.cache[key] = tuple(((z - mu) / sd).astype(np.float32) for z in zs)
        return self.cache[key]


def make_pair(gens, M, seed, coupling=0.0, ns_mode="source_aligned"):
    """Source pair with one draw of the condition randomness (modulation gains,
    coupling matrix) applied to both trajectories."""
    rng = np.random.default_rng(seed)
    z_tr, z_te = gens.pair(M, seed)
    gains = np.ones((N_SEG, M), np.float32)
    if ns_mode == "source_aligned":
        gains = np.sqrt(rng.exponential(1.0, (N_SEG, M))).astype(np.float32)
    elif ns_mode == "confounder_aligned":
        gains = np.repeat(rng.exponential(1.0, (N_SEG, 1)), M, 1).astype(np.float32)
    elif ns_mode != "stationary":
        raise ValueError(ns_mode)
    A = None
    if coupling > 0:
        A = rng.standard_normal((M, M)).astype(np.float32)
        A /= (np.linalg.norm(A, 2) + 1e-6)
    labels = fas.make_segment_labels(T, N_SEG)
    out = []
    for z in (z_tr, z_te):
        z = z * gains[labels]
        if A is not None:
            z = z.copy()
            for t in range(1, T):
                z[t] = (1 - coupling) * z[t] + coupling * (A @ z[t - 1])
        out.append(z)
    return out[0], out[1], labels, rng


def add_noise_pow(x, noise_pow, kind, rng):
    if kind == "pink":
        n = fas.pink_noise(x.shape, rng)
        n = n * np.sqrt(noise_pow / (np.mean(n ** 2) + 1e-12))
    else:
        n = rng.standard_normal(x.shape) * np.sqrt(noise_pow)
    return (x + n).astype(np.float32)


def make_data(axis, cfg, seed, gens):
    """z_tr, z_te, x_tr, x_te, labels: condition as shplrnn_axis_sweep.make_data,
    noise power fixed from the training trajectory, test noise from its own rng."""
    M, coupling, ns_mode = 4, 0.0, "source_aligned"
    nonlin, snr, kind = "linear", 20, "gaussian"
    if axis == "1f_snr":
        snr, kind = cfg, "pink"
    elif axis == "nonlin":
        nonlin = cfg
    elif axis == "coupling":
        coupling = cfg
    elif axis == "ns":
        ns_mode, snr, kind = cfg, 15, "pink"
    elif axis == "m_vs_d":
        M = cfg
    else:
        raise ValueError(axis)
    z_tr, z_te, labels, rng = make_pair(gens, M, seed, coupling, ns_mode)
    W = gens.W(M)
    xc_tr, xc_te = fas.mix(z_tr, W, nonlin), fas.mix(z_te, W, nonlin)
    noise_pow = float(np.mean(xc_tr ** 2)) * 10 ** (-snr / 10.0)
    x_tr = add_noise_pow(xc_tr, noise_pow, kind, rng)
    x_te = add_noise_pow(xc_te, noise_pow, kind, np.random.default_rng(seed + TEST_OFFSET))
    return z_tr, z_te, x_tr, x_te, labels


# ── methods returning train and test outputs ─────────────────────────────────

def fit_tcl(x_tr, x_te, labels, latent_dim, device, epochs=200, lr=1e-3, hidden=64):
    """fas.fit_tcl (default architecture) trained on x_tr, features on both."""
    n_seg = int(labels.max()) + 1
    X = torch.tensor(x_tr, dtype=torch.float32, device=device)
    Y = torch.tensor(labels, dtype=torch.long, device=device)
    model = fas.TCLNet(x_tr.shape[1], hidden, latent_dim, n_seg).to(device)
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.CrossEntropyLoss()
    model.train()
    for _ in range(epochs):
        perm = torch.randperm(len(X), device=device)
        for i in range(0, len(X), 256):
            idx = perm[i:i + 256]
            logits, _ = model(X[idx])
            loss = loss_fn(logits, Y[idx])
            opt.zero_grad()
            loss.backward()
            opt.step()
    model.eval()
    with torch.no_grad():
        h_tr = model(X)[1].cpu().numpy()
        logits_te, h_te = model(torch.tensor(x_te, dtype=torch.float32, device=device))
        acc_te = float((logits_te.argmax(1).cpu().numpy() == labels).mean())
    return model, h_tr, h_te.cpu().numpy(), acc_te


def fit_ivae(x_tr, x_te, labels, latent_dim, device, epochs=200, lr=1e-3, hidden=64):
    """fas.fit_ivae trained on x_tr, posterior means on both."""
    n_seg = int(labels.max()) + 1
    X = torch.tensor(x_tr, dtype=torch.float32, device=device)
    u = torch.zeros(len(x_tr), n_seg, device=device)
    u[torch.arange(len(x_tr)), torch.tensor(labels, device=device)] = 1.0
    model = fas.iVAENet(x_tr.shape[1], latent_dim, n_seg, hidden).to(device)
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    for _ in range(epochs):
        perm = torch.randperm(len(X), device=device)
        for i in range(0, len(X), 256):
            idx = perm[i:i + 256]
            x_hat, z, z_mu, z_lv, p_mu, p_lv = model(X[idx], u[idx])
            recon = ((x_hat - X[idx]) ** 2).mean()
            kl = -0.5 * (1 + z_lv - p_lv - (z_mu - p_mu).pow(2) / p_lv.exp()
                         - z_lv.exp() / p_lv.exp()).sum(dim=-1).mean()
            loss = recon + kl
            opt.zero_grad()
            loss.backward()
            opt.step()
    model.eval()
    with torch.no_grad():
        z_tr = model(X, u)[2].cpu().numpy()
        z_te = model(torch.tensor(x_te, dtype=torch.float32, device=device), u)[2].cpu().numpy()
    return model, z_tr, z_te


# ── held-out scores ──────────────────────────────────────────────────────────

def strong_heldout(z_tr, s_tr, z_te, s_te):
    """Permutation MCC: matching fit on the training pair, mean |corr| on the test pair."""
    M_ = z_tr.shape[1]
    C_tr = np.abs(np.corrcoef(z_tr.T, s_tr.T)[:M_, M_:])
    row, col = linear_sum_assignment(-np.nan_to_num(C_tr))
    C_te = np.abs(np.corrcoef(z_te.T, s_te.T)[:M_, M_:])
    return float(np.nanmean(C_te[row, col]))


def weak_heldout(z_tr, s_tr, z_te, s_te):
    """Linear-invariant MCC: CCA fit on the training pair, mean |canonical corr| on the test pair."""
    n = min(z_tr.shape[1], s_tr.shape[1])
    try:
        cca = CCA(n_components=n, max_iter=2000).fit(s_tr, z_tr)
        a, b = cca.transform(s_te, z_te)
        return float(np.nanmean([abs(np.corrcoef(a[:, i], b[:, i])[0, 1]) for i in range(n)]))
    except Exception:
        return np.nan


def score_cell(c):
    z_tr, z_te = c["z_tr"], c["z_te"]
    out, ins = {}, {}
    for m in ("PCA", "FastICA", "iVAE"):
        out[m] = strong_heldout(z_tr, c[f"{m}_tr"], z_te, c[f"{m}_te"])
        ins[m] = fas.mcc(z_tr, c[f"{m}_tr"])
    out["TCL"] = weak_heldout(np.abs(z_tr), c["TCL_tr"], np.abs(z_te), c["TCL_te"])
    ins["TCL"] = fas.weak_mcc(np.abs(z_tr), c["TCL_tr"])
    return out, ins


def run_methods(z_tr, z_te, x_tr, x_te, labels, device):
    n = z_tr.shape[1]
    c = dict(z_tr=z_tr, z_te=z_te, x_tr=x_tr, x_te=x_te, labels=labels)
    pca = PCA(n_components=n).fit(x_tr)
    c["PCA_tr"], c["PCA_te"] = pca.transform(x_tr), pca.transform(x_te)
    try:
        ica = FastICA(n_components=n, max_iter=500, random_state=0).fit(x_tr)
        c["FastICA_tr"], c["FastICA_te"] = ica.transform(x_tr), ica.transform(x_te)
    except Exception:
        c["FastICA_tr"] = c["FastICA_te"] = np.full_like(z_tr, np.nan)
    tcl, c["TCL_tr"], c["TCL_te"], c["TCL_acc_te"] = fit_tcl(x_tr, x_te, labels, n, device)
    ivae, c["iVAE_tr"], c["iVAE_te"] = fit_ivae(x_tr, x_te, labels, n, device)
    return c, tcl, ivae


# ── nulls and rotation reference (held-out procedure) ────────────────────────

def null_cell(gens, M, coupling, ns_mode):
    keys = ("strong_independent", "strong_timeshift", "weak_independent", "weak_timeshift")
    out = {k: [] for k in keys}
    rot = []
    for r in range(N_NULL):
        z_tr, z_te, _, _ = make_pair(gens, M, NULL_SEED + r, coupling, ns_mode)
        i_tr, i_te, _, _ = make_pair(gens, M, NULL_SEED + 500 + r, coupling, ns_mode)
        sh_tr, sh_te = (np.roll(z, T // 3 + 7 * r, axis=0) for z in (z_tr, z_te))
        out["strong_independent"].append(strong_heldout(z_tr, i_tr, z_te, i_te))
        out["strong_timeshift"].append(strong_heldout(z_tr, sh_tr, z_te, sh_te))
        out["weak_independent"].append(weak_heldout(np.abs(z_tr), i_tr, np.abs(z_te), i_te))
        out["weak_timeshift"].append(weak_heldout(np.abs(z_tr), sh_tr, np.abs(z_te), sh_te))
        R = np.linalg.qr(np.random.default_rng(NULL_SEED + r).standard_normal((M, M)))[0]
        rot.append(strong_heldout(z_tr, z_tr @ R, z_te, z_te @ R))
    stat = lambda v: (float(np.nanmean(v)), float(np.nanstd(v)), float(np.nanpercentile(v, 95)))
    return {k: stat(v) for k, v in out.items()}, stat(rot)


# ── main ─────────────────────────────────────────────────────────────────────

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--out", default="results/shplrnn_axis_heldout")
    ap.add_argument("--axes", nargs="*", default=list(AXES))
    ap.add_argument("--seeds", type=int, nargs="*", default=SEEDS)
    ap.add_argument("--skip_null", action="store_true")
    ap.add_argument("--score_only", action="store_true")
    args = ap.parse_args()
    out = args.out
    os.makedirs(f"{out}/cells", exist_ok=True)
    with open(f"{out}/config.json", "w") as f:
        json.dump(dict(T=T, D=D, n_seg=N_SEG, burn_in=BURN_IN, seeds=args.seeds, axes=AXES,
                       test_offset=TEST_OFFSET, n_null=N_NULL, null_seed=NULL_SEED,
                       calibration="median one-step residual std over all trials (stride 1)",
                       scoring="held-out: PCA/FastICA/iVAE permutation MCC vs s (matching fit on "
                               "train), TCL CCA MCC vs |s| (CCA fit on train)",
                       tcl=dict(hidden=64, epochs=200, lr=1e-3, batch=256),
                       ivae=dict(hidden=64, epochs=200, lr=1e-3, batch=256)), f, indent=1)
    gens = Generators(args.device, out)
    print(f"held-out shPLRNN sweep: axes={args.axes} seeds={args.seeds} device={args.device}")

    results = {}
    insample = {}
    t0 = time.time()
    n_fit = 0
    for axis in args.axes:
        cfgs = AXES[axis]
        results[axis] = {m: {c: [] for c in cfgs} for m in METHODS}
        insample[axis] = {m: {c: [] for c in cfgs} for m in METHODS}
        print(f"\n{'=' * 60}\nAxis: {axis}")
        for cfg in cfgs:
            for seed in args.seeds:
                path = f"{out}/cells/{axis}_{cfg}_seed{seed}"
                if os.path.exists(path + ".npz"):
                    c = dict(np.load(path + ".npz"))
                else:
                    assert not args.score_only, f"--score_only but {path}.npz is missing"
                    torch.manual_seed(seed)
                    z_tr, z_te, x_tr, x_te, labels = make_data(axis, cfg, seed, gens)
                    c, tcl, ivae = run_methods(z_tr, z_te, x_tr, x_te, labels, args.device)
                    np.savez(path + ".npz", **c)
                    torch.save(dict(tcl=tcl.state_dict(), ivae=ivae.state_dict()), path + ".pt")
                    n_fit += 1
                ho, ins = score_cell(c)
                for m in METHODS:
                    results[axis][m][cfg].append(ho[m])
                    insample[axis][m][cfg].append(ins[m])
            line = " | ".join(f"{m}={np.nanmean(results[axis][m][cfg]):.3f}"
                              f"({np.nanmean(insample[axis][m][cfg]):.2f})" for m in METHODS)
            print(f"  {axis}={cfg}: {line}   [{time.time() - t0:.0f}s]")
        np.save(f"{out}/all_results.npy", results)
        np.save(f"{out}/results_insample.npy", insample)

    if not args.skip_null:
        nulls, rots = {}, {}
        print(f"\n{'=' * 60}\nHeld-out null levels and rotation reference, {N_NULL} repeats per cell")
        for axis in args.axes:
            nulls[axis], rots[axis] = {}, {}
            for cfg in AXES[axis]:
                nulls[axis][cfg], rots[axis][cfg] = null_cell(gens, **sas.null_kwargs(axis, cfg))
                s = nulls[axis][cfg]
                print(f"  {axis:>8} {str(cfg):>18}  strong {s['strong_independent'][0]:.3f}/"
                      f"{s['strong_timeshift'][0]:.3f}  weak {s['weak_independent'][0]:.3f}/"
                      f"{s['weak_timeshift'][0]:.3f}  rotation {rots[axis][cfg][0]:.3f}")
        np.save(f"{out}/null_levels.npy", nulls)
        np.save(f"{out}/rotation_reference.npy", rots)

    lines = [f"shPLRNN-source failure-axis sweep, HELD-OUT scores (mean +- std over {len(args.seeds)} seeds); "
             "in-sample score of the same fit in brackets",
             f"{'axis':<10}{'config':<20}" + "".join(f"{m:>22}" for m in METHODS)]
    for axis in args.axes:
        for cfg in AXES[axis]:
            row = "".join(f"{np.nanmean(results[axis][m][cfg]):>9.3f}+-"
                          f"{np.nanstd(results[axis][m][cfg]):<5.3f}"
                          f"[{np.nanmean(insample[axis][m][cfg]):.2f}]" for m in METHODS)
            lines.append(f"{axis:<10}{str(cfg):<20}{row}")
    summary = "\n".join(lines)
    print("\n" + summary)
    with open(f"{out}/summary.txt", "w") as f:
        f.write(summary + "\n")
    print(f"\n{n_fit} cells fit this run; saved to {out}/  ({time.time() - t0:.0f}s)")


if __name__ == "__main__":
    main()
