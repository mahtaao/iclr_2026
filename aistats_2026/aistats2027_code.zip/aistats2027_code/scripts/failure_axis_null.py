"""Per-condition chance-level null for the failure-axis figure.

The dashed reference line in the failure-axis figure was a hard-coded MCC = 0.25.
That number is a guess, not a null: both MCC variants used in the sweep are
maximised over an assignment (strong MCC) or over a linear map (CCA-based weak
MCC), so the score an *uninformative* estimator attains is not 0 and depends on
the number of sources M and on the metric.

This script measures it. For every (axis, configuration) cell we draw the true
sources z exactly as the sweep does, then draw surrogate components that carry no
information about z but share its marginal and temporal statistics, and score the
pair with the same metric the figure applies to that method:

  strong MCC (permutation + sign matched |corr|)  -> PCA, FastICA, iVAE
  weak MCC (CCA, scored against |z|)              -> TCL

Two surrogate constructions are reported as a robustness check:

  independent  an independent draw from the same generator (different seed)
  timeshift    a circular time shift of z itself, which preserves each source's
               autocorrelation exactly and destroys only the alignment

Writes results/failure_axis_final/null_levels.npy.

Run: python scripts/failure_axis_null.py
"""

import numpy as np

from failure_axis_sweep import M, N_SEG, T, make_sources, mcc, weak_mcc

N_REP = 20          # surrogate repeats per cell (the sweep uses 5 seeds; the null
                    # is cheap, so average over more for a stable reference)
SURROGATE_SEED = 10_000
OUT = "results/failure_axis_final/null_levels.npy"

# (axis, config) -> kwargs for make_sources. Only coupling, ns_mode and M change
# the sources; the SNR and nonlinearity axes act on the mixing and the noise, so
# their source distribution -- and therefore their null -- is the axis default.
AXES = {
    "1f_snr": {c: dict(m=M, coupling=0.0, ns_mode="source_aligned") for c in [30, 15, 10, 5, 0]},
    "nonlin": {c: dict(m=M, coupling=0.0, ns_mode="source_aligned") for c in ["linear", "cube", "tanh"]},
    "coupling": {c: dict(m=M, coupling=c, ns_mode="source_aligned") for c in [0.0, 0.1, 0.3, 0.6, 0.9]},
    "ns": {c: dict(m=M, coupling=0.0, ns_mode=c) for c in ["stationary", "source_aligned", "confounder_aligned"]},
    "m_vs_d": {c: dict(m=c, coupling=0.0, ns_mode="source_aligned") for c in [2, 4, 8, 16, 22]},
}


def sources(m, coupling, ns_mode, seed):
    return make_sources(T, m, N_SEG, coupling=coupling,
                        ns_mode=ns_mode, rng=np.random.default_rng(seed))


def null_cell(m, coupling, ns_mode):
    """Strong- and weak-metric null MCC for one condition, both surrogates."""
    out = {k: [] for k in ("strong_independent", "strong_timeshift",
                           "weak_independent", "weak_timeshift")}
    for r in range(N_REP):
        z = sources(m, coupling, ns_mode, SURROGATE_SEED + r)
        indep = sources(m, coupling, ns_mode, SURROGATE_SEED + 500 + r)
        # Shift by a large, non-trivial fraction of the record so no segment
        # boundary lines up with its original position.
        shift = T // 3 + 7 * r
        shifted = np.roll(z, shift, axis=0)

        out["strong_independent"].append(mcc(z, indep))
        out["strong_timeshift"].append(mcc(z, shifted))
        out["weak_independent"].append(weak_mcc(np.abs(z), indep))
        out["weak_timeshift"].append(weak_mcc(np.abs(z), shifted))
    return {k: (float(np.nanmean(v)), float(np.nanstd(v)),
                float(np.nanpercentile(v, 95))) for k, v in out.items()}


def main():
    nulls = {}
    for axis, configs in AXES.items():
        nulls[axis] = {}
        print(f"\n=== {axis} ===")
        for cfg, kw in configs.items():
            nulls[axis][cfg] = null_cell(**kw)
            s = nulls[axis][cfg]
            print(f"  {str(cfg):>18}  M={kw['m']:<2}  "
                  f"strong {s['strong_independent'][0]:.3f}/{s['strong_timeshift'][0]:.3f}  "
                  f"weak(CCA) {s['weak_independent'][0]:.3f}/{s['weak_timeshift'][0]:.3f}   "
                  f"(indep/timeshift, mean over {N_REP})")
    np.save(OUT, nulls)
    print(f"\nSaved {OUT}")


if __name__ == "__main__":
    main()
