"""E11: iVAE baseline at a fixed observation scale.

Refits iVAE on every saved held-out cell with x standardised per channel
(training mean / std applied to train and test).  The shipped baseline is
loss = per-element MSE + KL on raw x, whose scale is set by the learned W and
the condition (results/autoresearch_oct6, E7/E8).  Variants:
  beta<b>   loss = per-element MSE + b * KL  (b = 2/D = 0.09 is the unit-variance
            Gaussian negative ELBO up to the factor D/2)
  learnvar  Gaussian likelihood with a learned per-channel log-std:
            loss = sum_d [(x_d - xhat_d)^2 / (2 sigma_d^2) + log sigma_d] + KL
Per cell: held-out permutation MCC (matching fit on train), in-sample MCC, and
the test negative ELBO at sigma = 1 (comparable across beta, needs no sources).

    python scripts/ar_ivae_fix.py --variant beta0.1 --device cuda
"""
import os
import sys
import time
import argparse
import numpy as np
import torch

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.dirname(HERE))
import shplrnn_axis_heldout as hb
import failure_axis_sweep as fas


def fit(x_tr, x_te, labels, latent_dim, device, beta=1.0, learn_var=False, epochs=200, lr=1e-3, hidden=64):
    n_seg = int(labels.max()) + 1
    X = torch.tensor(x_tr, dtype=torch.float32, device=device)
    Xte = torch.tensor(x_te, dtype=torch.float32, device=device)
    u = torch.zeros(len(x_tr), n_seg, device=device)
    u[torch.arange(len(x_tr)), torch.tensor(labels, device=device)] = 1.0
    model = fas.iVAENet(x_tr.shape[1], latent_dim, n_seg, hidden).to(device)
    log_sig = torch.zeros(x_tr.shape[1], device=device, requires_grad=learn_var)
    opt = torch.optim.Adam(list(model.parameters()) + ([log_sig] if learn_var else []), lr=lr)

    def terms(xb, ub):
        x_hat, z, z_mu, z_lv, p_mu, p_lv = model(xb, ub)
        kl = -0.5 * (1 + z_lv - p_lv - (z_mu - p_mu).pow(2) / p_lv.exp() - z_lv.exp() / p_lv.exp()).sum(-1)
        return (x_hat - xb) ** 2, kl, z_mu

    def own_loss(se, kl):
        if learn_var:
            return ((0.5 * se / (2 * log_sig).exp() + log_sig).sum(-1) + kl).mean()
        return se.mean() + beta * kl.mean()

    for _ in range(epochs):
        perm = torch.randperm(len(X), device=device)
        for i in range(0, len(X), 256):
            idx = perm[i:i + 256]
            se, kl, _ = terms(X[idx], u[idx])
            loss = own_loss(se, kl)
            opt.zero_grad()
            loss.backward()
            opt.step()
    model.eval()
    with torch.no_grad():
        _, _, z_tr = terms(X, u)
        se, kl, z_te = terms(Xte, u)
        nelbo_unit = float((0.5 * se.sum(-1) + kl).mean())
        nelbo_own = float(own_loss(se, kl))
    return z_tr.cpu().numpy(), z_te.cpu().numpy(), nelbo_unit, nelbo_own, float(log_sig.detach().exp().mean())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cells", default="results/shplrnn_axis_heldout/cells")
    ap.add_argument("--out", default="results/ar_night/ivae_fix")
    ap.add_argument("--variant", default="beta0.1", help="beta<float> or learnvar")
    ap.add_argument("--seeds", type=int, nargs="*", default=hb.SEEDS)
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--limit", type=int, default=0)
    args = ap.parse_args()
    learn_var = args.variant == "learnvar"
    beta = 1.0 if learn_var else float(args.variant[len("beta"):])
    os.makedirs(args.out, exist_ok=True)
    path = f"{args.out}/{args.variant}.npy"
    res = np.load(path, allow_pickle=True).item() if os.path.exists(path) else {}
    t0, n = time.time(), 0
    for ax, cfgs in hb.AXES.items():
        for cfg in cfgs:
            for seed in args.seeds:
                key = (ax, cfg, seed)
                if key in res or (args.limit and n >= args.limit):
                    continue
                c = dict(np.load(f"{args.cells}/{ax}_{cfg}_seed{seed}.npz"))
                z_tr, z_te, x_tr, x_te = c["z_tr"], c["z_te"], c["x_tr"], c["x_te"]
                mu, sd = x_tr.mean(0), x_tr.std(0) + 1e-8
                xs_tr, xs_te = ((x_tr - mu) / sd).astype(np.float32), ((x_te - mu) / sd).astype(np.float32)
                torch.manual_seed(seed)
                v_tr, v_te, nelbo_unit, nelbo_own, sigma = fit(xs_tr, xs_te, c["labels"], z_tr.shape[1],
                                                               args.device, beta, learn_var)
                res[key] = dict(default=hb.strong_heldout(z_tr, c["iVAE_tr"], z_te, c["iVAE_te"]),
                                score=hb.strong_heldout(z_tr, v_tr, z_te, v_te), insample=fas.mcc(z_tr, v_tr),
                                nelbo_unit=nelbo_unit, nelbo_own=nelbo_own, sigma=sigma, x_std=float(x_tr.std()))
                np.save(path, res)
                n += 1
            done = [res[(ax, cfg, s)] for s in args.seeds if (ax, cfg, s) in res]
            if done:
                g = lambda k: np.nanmean([d[k] for d in done])
                print(f"{args.variant:>9} {ax:>7} {str(cfg):>18}: default {g('default'):.3f}  fixed-scale "
                      f"{g('score'):.3f} [{g('insample'):.2f}]  test nELBO(sigma=1) {g('nelbo_unit'):7.2f}"
                      f"  sigma {g('sigma'):.2f}  [{time.time() - t0:.0f}s]", flush=True)
    lines = [f"# iVAE {args.variant} on standardised x: held-out MCC, mean over seeds",
             "| axis | cfg | shipped iVAE | fixed-scale iVAE | in-sample | test nELBO (sigma=1) | raw x std |",
             "|---|---|---|---|---|---|---|"]
    for ax, cfgs in hb.AXES.items():
        for cfg in cfgs:
            done = [res[(ax, cfg, s)] for s in args.seeds if (ax, cfg, s) in res]
            if not done:
                continue
            g = lambda k: np.nanmean([d[k] for d in done])
            lines.append(f"| {ax} | {cfg} | {g('default'):.2f} | {g('score'):.2f} | {g('insample'):.2f} | "
                         f"{g('nelbo_unit'):.2f} | {g('x_std'):.2f} |")
    with open(f"{args.out}/{args.variant}.md", "w") as f:
        f.write("\n".join(lines) + "\n")


if __name__ == "__main__":
    main()
