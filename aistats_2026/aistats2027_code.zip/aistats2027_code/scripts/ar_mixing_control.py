"""E3/E4: matched mixing control for the m_vs_d axis.

Same sources and protocol as shplrnn_axis_heldout (held-out, 5 seeds), but the
mixing W is swapped: 'learned' (the generator's own W, = the existing cell),
'rownorm' (random Gaussian rows normalised to unit norm, as the synthetic sweep),
'orth' (random W with orthonormal rows, condition number 1).  --Ms adds extra M
(e.g. 32, needing trained_models/bci/bci/linear_M32/001).  Cells cached in
results/autoresearch_oct6/mixing_cells.  Also records cond(W).
"""
import os, sys, time, argparse, numpy as np, torch
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE); sys.path.insert(0, os.path.dirname(HERE))
import shplrnn_axis_heldout as hb, failure_axis_sweep as fas
OUT = "results/autoresearch_oct6"; CELLS = f"{OUT}/mixing_cells"; os.makedirs(CELLS, exist_ok=True)
ap = argparse.ArgumentParser(); ap.add_argument("--device", default="cpu")
ap.add_argument("--Ms", type=int, nargs="*", default=[2, 4, 8, 16, 22])
ap.add_argument("--kinds", nargs="*", default=["learned", "rownorm", "orth"])
ap.add_argument("--seeds", type=int, nargs="*", default=hb.SEEDS)
args = ap.parse_args()
import model as _model
def _encode(self, x):  # M > D: right-inverse Gram is singular, use the pseudo-inverse
    if self.dx == self.dz and not self.obs_matrix.requires_grad:
        return x
    return x @ torch.linalg.pinv(self.obs_matrix)
_model.shallowPLRNN.encode = _encode
gens = hb.Generators(args.device, OUT)
# M > D: PCA/FastICA capped at D components (scores average over the D matched pairs)
from sklearn.decomposition import PCA as _PCA, FastICA as _ICA
def _run_methods(z_tr, z_te, x_tr, x_te, labels, device):
    n, d = z_tr.shape[1], x_tr.shape[1]
    c = dict(z_tr=z_tr, z_te=z_te, x_tr=x_tr, x_te=x_te, labels=labels)
    pca = _PCA(n_components=min(n, d)).fit(x_tr); c["PCA_tr"], c["PCA_te"] = pca.transform(x_tr), pca.transform(x_te)
    ica = _ICA(n_components=min(n, d), max_iter=500, random_state=0).fit(x_tr); c["FastICA_tr"], c["FastICA_te"] = ica.transform(x_tr), ica.transform(x_te)
    tcl, c["TCL_tr"], c["TCL_te"], c["TCL_acc_te"] = hb.fit_tcl(x_tr, x_te, labels, n, device)
    ivae, c["iVAE_tr"], c["iVAE_te"] = hb.fit_ivae(x_tr, x_te, labels, n, device)
    return c, tcl, ivae
hb.run_methods = _run_methods

def make_W(kind, M, seed):
    if kind == "learned":
        return gens.W(M)
    rng = np.random.default_rng(1000 + seed)
    W = rng.standard_normal((M, hb.D)).astype(np.float32)
    if kind == "rownorm":
        return W / np.linalg.norm(W, axis=1, keepdims=True)
    if kind == "rownorm_scaled":  # random directions, rows scaled to the learned W's mean row norm
        return W / np.linalg.norm(W, axis=1, keepdims=True) * np.linalg.norm(gens.W(M), axis=1).mean()
    if kind == "orth_scaled":
        Q = make_W("orth", M, seed)
        return (Q * np.linalg.norm(gens.W(M), axis=1).mean()).astype(np.float32)
    if kind == "orth":  # orthonormal rows (M<=D) or orthonormal columns (M>D)
        Q = np.linalg.qr(W.T if M <= hb.D else W)[0]
        return (Q.T if M <= hb.D else Q).astype(np.float32)
    raise ValueError(kind)

path = f"{OUT}/mixing_control.npy"
res = np.load(path, allow_pickle=True).item() if os.path.exists(path) else {}
t0 = time.time()
for M in args.Ms:
    for kind in args.kinds:
        for seed in args.seeds:
            key = (kind, M, seed)
            if key in res: continue
            cp = f"{CELLS}/{kind}_M{M}_seed{seed}.npz"
            if os.path.exists(cp):
                c = dict(np.load(cp))
            else:
                torch.manual_seed(seed)
                z_tr, z_te, labels, rng = hb.make_pair(gens, M, seed)
                W = make_W(kind, M, seed)
                xc_tr, xc_te = fas.mix(z_tr, W, "linear"), fas.mix(z_te, W, "linear")
                npow = float(np.mean(xc_tr ** 2)) * 10 ** (-20 / 10.0)
                x_tr = hb.add_noise_pow(xc_tr, npow, "gaussian", rng)
                x_te = hb.add_noise_pow(xc_te, npow, "gaussian", np.random.default_rng(seed + hb.TEST_OFFSET))
                c, _, _ = hb.run_methods(z_tr, z_te, x_tr, x_te, labels, args.device)
                c["W"] = W; np.savez(cp, **c)
            ho, ins = hb.score_cell(c)
            ho["condW"] = float(np.linalg.cond(c["W"])); ho["insample"] = ins
            res[key] = ho
            np.save(path, res)
        line = " | ".join(f"{m}={np.mean([res[(kind, M, s)][m] for s in args.seeds]):.3f}" for m in hb.METHODS)
        print(f"M={M:>2} W={kind:<8} cond={np.mean([res[(kind, M, s)]['condW'] for s in args.seeds]):6.2f}  {line}  [{time.time()-t0:.0f}s]", flush=True)
