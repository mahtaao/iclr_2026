# Code for "Latent-Source Identifiability from Observational Neural Recordings Is Not Confirmable"

Anonymized code for the AISTATS 2027 submission.

The shPLRNN generator code (`main.py`, `model.py`, `bptt.py`, `dataset.py`, `evaluator.py`, `saving.py`, `ubermain.py`, `multitasking.py`, `plotter.py`, `main_eval.py`, `schemes/`, `eval/`) is the public implementation of Brenner et al., "Learning Interpretable Hierarchical Dynamical Systems Models from Time Series Data" (ICLR 2025), distributed under GPL-3.0 (`LICENSE`). Everything under `scripts/` is ours.

## Setup

Python 3.11.

```
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```

## Data

- **BCI Competition IV-2a** (public, nine subjects, 22 EEG channels): `python scripts/prepare_bci_data.py` downloads it from https://bnci-horizon-2020.eu/database/data-sets/001-2014/ and writes `data/bci/`.
- `scripts/prepare_generator_data.py` builds generator training data from a folder of preprocessed EEG arrays; set `--npy_dir` to your local copy.

Raw data are not included.

## Contents

- `trained_models/bci/bci/<name>/001/`: trained shPLRNN generators (`hypers.txt` and checkpoints). `linear_M{2,4,8,16,22,32}` are the generators of the main benchmark; `g_tf02_h64_M*` and `g_tf02_h64` are the realistic-spectrum generators (Appendix).
- `results/`: the aggregated result arrays (`.npy`, `.json`) that every paper figure and table reads. Figures can be rebuilt from these without rerunning any experiment.
- `scripts/paperfigs/`: one script per paper figure; `bash scripts/paperfigs/build_all.sh` rebuilds all of them into `results/figures_paper/`.

## Figures

| Paper | Script | Main inputs |
|---|---|---|
| Fig. 1 (concept) | `scripts/paperfigs/fig0_concept.tex` | none |
| Fig. 2 (stress axes, known sources) | `scripts/paperfigs/fig1_axes.py` | `results/ar_night/{figures_heldout20,ivae_fix,highpass}`, `results/autoresearch_oct6/mixing_control.npy`, `results/autoresearch_oct7/{pcl,cebra,fill,modulation_axis}`, `results/real_eeg_placement`, `results/shplrnn_axis_heldout` |
| Fig. 3 (blind diagnostics) | `scripts/paperfigs/fig2_diagnostics.py` | `results/autoresearch_oct7/diagnostics` |
| Fig. 4 (real EEG) | `scripts/paperfigs/fig3_real_eeg.py` | `results/autoresearch_oct7/{bci_cue,modulation_scale}` |
| Appendix robustness | `scripts/paperfigs/figR_robustness.py` | `results/ar_night/{data_quantity,leadfield}`, `results/shplrnn_axis_heldout/null_levels.npy` |
| Appendix generator realism | `scripts/paperfigs/figA_realism.py` | `trained_models/bci/bci/g_tf02_h64` |
| Appendix realistic generator | `REALISTIC=1 python scripts/paperfigs/fig1_axes.py` | `results/autoresearch_oct7/heldout_realistic` |

## Rerunning experiments

1. Train generators: `python main.py` with the hyperparameters in each `hypers.txt`.
2. Benchmark with known sources (main sweep, 20 seeds): `scripts/shplrnn_axis_heldout.py` (`--seeds`). Realistic-spectrum generators: `scripts/ar_realistic_sweep.py`.
3. Controls and robustness: `scripts/ar_ivae_fix.py`, `scripts/ar_highpass.py`, `scripts/ar_data_quantity.py`, `scripts/ar_leadfield.py`, `scripts/ar_nuisance.py`, `scripts/ar_tcl_capacity.py`, `scripts/ar_pcl.py`, `scripts/ar_cebra.py`, `scripts/ar_modulation_axis.py`, `scripts/ar_mixing_control.py`.
4. Blind diagnostics: `scripts/ar_diagnostics.py`.
5. Real EEG: `scripts/ar_bci_cue.py` (cue decoding, label-permutation null, CSP ceiling) and `scripts/real_eeg_modulation_placement.py`.

Scripts with command-line options list them with `--help`; output folders default to the `results/` paths above.
